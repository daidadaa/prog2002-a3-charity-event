/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * the one place that knows where the Express API lives.
 *
 * @file environments/environment.ts
 * @file environments/environment.ts
 */

export const environment = {
  /** Base URL of the Express API, with no trailing slash. */
  apiBaseUrl: 'http://localhost:3000',

  /** Set to false in the deployed build to silence the extra console logging. */
  production: false,
};
