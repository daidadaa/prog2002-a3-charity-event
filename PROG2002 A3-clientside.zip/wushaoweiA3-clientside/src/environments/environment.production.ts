/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * the DEPLOYED settings.
 *
 * @file environments/environment.production.ts
 * @file environments/environment.production.ts
 */

export const environment = {
  /**
   * Base URL of the Express API on the SCU cPanel, with no trailing slash - the
   * service appends `/api/...` itself.
   *
   * @example 'https://24832850.it.scu.edu.au/a3api'
   */
  apiBaseUrl: 'https://24832850.it.scu.edu.au/a3api',

  /** True in the deployed build; silences the extra development logging. */
  production: true,
};
