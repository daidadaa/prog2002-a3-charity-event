/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * the entry point of the client website.
 *
 * @file main.ts
 * @file main.ts
 */

import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { App } from './app/app';

/**
 * Starts the single-page application.
 *
 * @param App - The root component; `app.html` draws the shell around every page.
 * @param appConfig - The application-wide providers (HttpClient, the router and
 * the global error listeners).
 * @returns A promise that resolves once the application has been bootstrapped;
 * a rejected promise is reported rather than left unhandled.
 *
 * @example
 */
bootstrapApplication(App, appConfig)
  .catch((err) => console.error(err));
