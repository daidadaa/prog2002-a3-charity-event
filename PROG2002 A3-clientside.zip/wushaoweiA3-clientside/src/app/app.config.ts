/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * the application-wide providers.
 *
 * @file app/app.config.ts
 * @file app/app.config.ts
 */

import { provideHttpClient } from '@angular/common/http';
import { ApplicationConfig, provideBrowserGlobalErrorListeners } from '@angular/core';
import { provideRouter, withInMemoryScrolling } from '@angular/router';
import { routes } from './app.routes';

/**
 * The providers that are active for the whole application, passed to
 * `bootstrapApplication` by `main.ts`.
 *
 * @remarks
 * Three groups are registered here:
 *  - global error listeners, so an uncaught error is reported by the browser;
 *  - `provideHttpClient()`, so every service in the app can inject `HttpClient`;
 *  - the router, with in-memory scrolling so each navigation lands at the top of
 *    the new page.
 */
export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),

    // Enables HttpClient for the whole application. EventApiService is the only
    // class that uses it, but it is provided application-wide so the service can
    // inject it from anywhere.
    provideHttpClient(),

    provideRouter(
      routes,
      // Every navigation lands at the top of the new page (and a back/forward
      // navigation restores the old position), which is what a multi-page site
      // is expected to do.
      withInMemoryScrolling({ scrollPositionRestoration: 'enabled', anchorScrolling: 'enabled' }),
    ),
  ],
};
