/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * the four client-side pages.
 *
 * @file app/app.routes.ts
 * @file app/app.routes.ts
 */

import { Routes } from '@angular/router';

/**
 * The route table of the client website.
 *
 * @remarks
 * The four pages are:
 *
 *
 * `:id` is the route parameter the detail and registration pages read with
 * `ActivatedRoute`. It is a plain string here; the pages pass it straight to the
 * API, which validates it (a non-numeric id gets a 400, which the pages show as
 * "this event could not be found").
 *
 * Each page is lazy-loaded with `loadComponent()`, so the browser downloads the
 * JavaScript for a page only when it is opened. The build turns that into one
 * small chunk per page.
 *
 * The wildcard route is last on purpose: it must not shadow the four routes
 * above it.
 */
export const routes: Routes = [
  {
    path: '',
    title: 'Kind | Home',
    loadComponent: () => import('./pages/home/home').then((m) => m.HomePage),
  },
  {
    path: 'search',
    title: 'Kind | Search events',
    loadComponent: () => import('./pages/search/search').then((m) => m.SearchPage),
  },
  {
    path: 'event/:id',
    title: 'Kind | Event details',
    loadComponent: () => import('./pages/event-detail/event-detail').then((m) => m.EventDetailPage),
  },
  {
    path: 'register/:id',
    title: 'Kind | Register',
    loadComponent: () => import('./pages/register/register').then((m) => m.RegisterPage),
  },
  // Wildcard last: it must not shadow the routes above it.
  { path: '**', redirectTo: '' },
];
