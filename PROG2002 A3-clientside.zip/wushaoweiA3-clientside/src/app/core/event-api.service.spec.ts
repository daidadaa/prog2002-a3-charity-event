/**
 * PROG2002 Web Development II - Assessment 3
 * WU Shao Wei
 * core/event-api.service.spec.ts
 *
 * @remarks
 * Checks the one thing the service is responsible for: sending the right HTTP
 * request. No server and no database are involved - HttpTestingController
 * intercepts the call and lets the test inspect the URL, the query strings and
 * the request body before answering with whatever the test wants.
 *
 * @see EventApiService - the service under test.
 */

import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { EventApiService } from './event-api.service';

/** Base URL of the API the service is configured to call. */
const BASE = 'http://localhost:3000';

/**
 * Verifies the HTTP contract of the service: URL, method, query string and body.
 *
 * @remarks
 * `httpMock.verify()` runs after every test, so a request that was expected but
 * never made - or made twice - fails the test instead of passing silently.
 */
describe('EventApiService', () => {
  let service: EventApiService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()],
    });
    service = TestBed.inject(EventApiService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  // Fail the test if a request was expected and never made, or made twice.
  afterEach(() => httpMock.verify());

  it('calls the home endpoint', () => {
    service.getHomeEvents().subscribe();
    httpMock.expectOne(`${BASE}/api/events/home`).flush([]);
  });

  it('calls the detail endpoint with the id in the path', () => {
    service.getEvent(7).subscribe();
    httpMock.expectOne(`${BASE}/api/events/7`).flush({ event: {}, registrations: [], summary: {} });
  });

  it('calls the lookups the search form needs', () => {
    service.getCategories().subscribe();
    httpMock.expectOne(`${BASE}/api/categories`).flush([]);

    service.getEventDates().subscribe();
    httpMock.expectOne(`${BASE}/api/event-dates`).flush([]);
  });

  /**
   * Covers the query string `searchEvents` builds.
   *
   * @remarks
   * To the server an absent parameter means "no filter", so these tests check
   * both what is sent and what is deliberately left out.
   */
  describe('searchEvents', () => {
    it('sends every criterion that was chosen', () => {
      service
        .searchEvents({ status: 'upcoming', date: '2026-10-27', location: 'Lismore', category: 1 })
        .subscribe();

      const request = httpMock.expectOne((req) => req.url === `${BASE}/api/events`);
      expect(request.request.method).toBe('GET');
      expect(request.request.params.get('status')).toBe('upcoming');
      expect(request.request.params.get('date')).toBe('2026-10-27');
      expect(request.request.params.get('location')).toBe('Lismore');
      expect(request.request.params.get('category')).toBe('1');
      request.flush([]);
    });

    it('omits the criteria that were left empty, which is what lets one, two or all three combine', () => {
      service.searchEvents({ status: 'upcoming', date: '', location: '   ', category: '' }).subscribe();

      const request = httpMock.expectOne((req) => req.url === `${BASE}/api/events`);
      expect(request.request.params.has('date')).toBe(false);
      // Whitespace-only text is treated as "not chosen" rather than searched for.
      expect(request.request.params.has('location')).toBe(false);
      expect(request.request.params.has('category')).toBe(false);
      expect(request.request.params.get('status')).toBe('upcoming');
      request.flush([]);
    });

    it('trims the location and lets HttpParams encode it', () => {
      service.searchEvents({ location: '  Lismore Makers Hall  ' }).subscribe();

      const request = httpMock.expectOne((req) => req.url === `${BASE}/api/events`);
      expect(request.request.params.get('location')).toBe('Lismore Makers Hall');
      // The space is percent-encoded on the wire.
      expect(request.request.urlWithParams).toContain('location=Lismore%20Makers%20Hall');
      request.flush([]);
    });
  });

  it('POSTs a new registration to the nested resource, without a total_amount', () => {
    service
      .createRegistration(3, {
        first_name: 'Amelia',
        last_name: 'Nguyen',
        email: 'amelia.nguyen@example.com',
        phone: '0400 111 201',
        tickets: 2,
        notes: 'optional',
      })
      .subscribe();

    const request = httpMock.expectOne(`${BASE}/api/events/3/registrations`);
    expect(request.request.method).toBe('POST');
    expect(request.request.body.tickets).toBe(2);
    // The price is the server's business: the browser must not send it.
    expect(request.request.body.total_amount).toBeUndefined();
    request.flush({ message: 'ok', registration: { registration_id: 9 } });
  });

  it('calls the weather endpoint for the event', () => {
    service.getWeather(1).subscribe();
    httpMock.expectOne(`${BASE}/api/weather/1`).flush({ days: [] });
  });
});
