/**
 * PROG2002 Web Development II - Assessment 3
 * WU Shao Wei
 * core/format.spec.ts
 *
 * @remarks
 * The formatting helpers are pure functions, so they can be tested without
 * Angular at all. The two cases that matter most are covered explicitly:
 *   1. a MySQL DECIMAL arriving as the string "7450.00" still adds up, and
 *   2. a date is formatted by slicing, so an event never shifts by a day.
 *
 * @see format.ts - the module under test.
 */

import {
  formatEventDate,
  formatEventDateTime,
  formatEventTime,
  formatMoney,
  formatRegistrationDate,
  formatShortDate,
  formatTemperature,
  toNumber,
} from './format';

/**
 * Covers every exported formatter in `format.ts`.
 *
 * @remarks
 * The nested `describe` blocks group the cases by function, so a failure names
 * the formatter that broke.
 */
describe('format helpers', () => {
  describe('toNumber', () => {
    it('turns the DECIMAL strings the API sends into real numbers', () => {
      expect(toNumber('7450.00')).toBe(7450);
      expect(toNumber('11')).toBe(11);
    });

    it('accepts real numbers as well, so the code works either way', () => {
      expect(toNumber(25)).toBe(25);
      expect(toNumber(20.3)).toBe(20.3);
    });

    it('folds null, undefined and nonsense to 0 instead of NaN', () => {
      // Without this the progress percentage on the detail page would be NaN.
      expect(toNumber(null)).toBe(0);
      expect(toNumber(undefined)).toBe(0);
      expect(toNumber('')).toBe(0);
      expect(toNumber('not a number')).toBe(0);
    });
  });

  describe('formatMoney', () => {
    it('always shows two decimals and a thousands separator', () => {
      expect(formatMoney('7450.00')).toBe('$7,450.00');
      expect(formatMoney(25)).toBe('$25.00');
      expect(formatMoney('18000.00')).toBe('$18,000.00');
      expect(formatMoney(0)).toBe('$0.00');
    });
  });

  describe('formatEventDate / formatEventTime', () => {
    it('formats "YYYY-MM-DD HH:mm:ss" without parsing it as a Date', () => {
      expect(formatEventDate('2026-10-27 06:30:00')).toBe('Tue 27 Oct 2026');
      expect(formatEventTime('2026-10-27 06:30:00')).toBe('6:30 am');
      expect(formatEventDateTime('2026-10-27 06:30:00')).toBe('Tue 27 Oct 2026, 6:30 am');
    });

    it('handles midnight, noon and the afternoon correctly', () => {
      expect(formatEventTime('2026-10-27 00:15:00')).toBe('12:15 am');
      expect(formatEventTime('2026-10-27 12:00:00')).toBe('12:00 pm');
      expect(formatEventTime('2026-10-27 18:22:40')).toBe('6:22 pm');
    });

    it('does not shift the day for an evening event (the new Date() trap)', () => {
      // new Date('2026-11-09 23:30:00') is parsed differently in different
      // browsers; slicing can never move the event to another day.
      expect(formatEventDate('2026-11-09 23:30:00')).toBe('Mon 9 Nov 2026');
    });

    it('returns an empty string for missing or malformed input', () => {
      expect(formatEventDate(null)).toBe('');
      expect(formatEventDate('')).toBe('');
      expect(formatEventDate('27/10/2026')).toBe('');
      expect(formatEventTime('2026-10-27')).toBe('');
      expect(formatEventDateTime('2026-10-27')).toBe('Tue 27 Oct 2026');
    });
  });

  describe('formatRegistrationDate / formatShortDate', () => {
    it('formats a registration timestamp and a weather day', () => {
      expect(formatRegistrationDate('2026-10-12 18:22:40')).toBe('12 Oct 2026, 6:22 pm');
      expect(formatShortDate('2026-10-14')).toBe('Wed 14 Oct');
    });
  });

  describe('formatTemperature', () => {
    it('shows one decimal place and trims a pointless ".0"', () => {
      expect(formatTemperature(20.3)).toBe('20.3°C');
      expect(formatTemperature(16)).toBe('16°C');
    });

    it('shows a dash when the forecast has no value', () => {
      expect(formatTemperature(null)).toBe('–');
      expect(formatTemperature(undefined)).toBe('–');
    });
  });
});
