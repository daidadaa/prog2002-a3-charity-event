/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * the only class in the application that talks HTTP.
 *
 * @file app/core/event-api.service.ts
 * @file app/core/event-api.service.ts
 */

import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, timeout } from 'rxjs';
import { environment } from '../../environments/environment';
import type {
  Category,
  CharityEvent,
  CreateRegistrationRequest,
  CreateRegistrationResponse,
  EventDetailResponse,
  EventSearchFilters,
  WeatherForecast,
} from './models';

/**
 * The single HTTP client of the client website: every page asks this service for
 * its data and receives a typed `Observable`.
 *
 * @remarks
 * The data flow, one component at a time:
 *
 *
 * Why a service and not `HttpClient` in each component:
 * 1. The base URL lives in `environment.ts`, so it is written once.
 * 2. Every response is typed (`Observable<CharityEvent[]>`), so a wrong property
 *    name fails the build instead of showing an empty box in the demonstration.
 * 3. The query string is assembled in one place, which is why the search page
 *    can offer one, two or all three criteria with a single method call.
 */
@Injectable({ providedIn: 'root' })
export class EventApiService {
  // `inject()` instead of a constructor parameter: the modern Angular style that
  // works in field initialisers and keeps the class free of a constructor.
  private readonly http = inject(HttpClient);

  /** e.g. "http://localhost:3000" - no trailing slash, so paths stay readable. */
  private readonly baseUrl = environment.apiBaseUrl;

  /**
   * How long a browser request may wait before the page reports it, in ms.
   *
   * @remarks
   * `HttpClient` has no default timeout, exactly like the Node `fetch` used by the
   * weather proxy. If the API accepted the connection and then stopped answering,
   * every spinner on the page would turn forever. Wrapping every call through
   * {@link EventApiService.withTimeout} bounds that wait; the resulting RxJS
   * `TimeoutError` is turned into a friendly message by `toApiError` so the page
   * shows "took too long to respond" instead of loading forever.
   */
  private static readonly REQUEST_TIMEOUT_MS = 10000;

  /**
   * Applies the shared request timeout to one call.
   *
   * @param source - The `HttpClient` observable to guard.
   * @returns The same observable, but it errors with a `TimeoutError` if nothing
   * arrives within {@link EventApiService.REQUEST_TIMEOUT_MS}.
   */
  private withTimeout<T>(source: Observable<T>): Observable<T> {
    return source.pipe(timeout(EventApiService.REQUEST_TIMEOUT_MS));
  }

  /**
   * GET /api/events/home - the dynamic half of the home page.
   *
   * @returns An observable of the active events from today onwards, ordered by
   * date ascending.
   *
   * @throws An `HttpErrorResponse` through the observable's error channel when
   * the API is unreachable or answers with an error; the page turns it into a
   * visible message with `toApiError`.
   *
   * @remarks
   * The server does the ordering and the filtering, so the client does no
   * sorting at all.
   *
   * @see HomePage - the only caller.
   */
  getHomeEvents(): Observable<CharityEvent[]> {
    return this.withTimeout(this.http.get<CharityEvent[]>(`${this.baseUrl}/api/events/home`));
  }

  /**
   * GET /api/events?status=&date=&location=&category= - the search endpoint.
   *
   * @param filters - The criteria the visitor filled in; any field may be empty.
   * @returns An observable of the matching events.
   *
   * @throws An `HttpErrorResponse` through the observable's error channel, e.g.
   * a 400 `{ error: "Please pick a valid date." }` when a criterion is invalid.
   *
   * @remarks
   * Only the criteria the visitor actually filled in are sent, because the server
   * treats an absent parameter as "no filter" and combines whatever is present
   * with AND. That single detail is what makes "one, several or all three
   * criteria" work without any special casing here.
   *
   * `HttpParams` URL-encodes the values, so a place name with a space
   * ("Lismore Makers Hall") becomes `?location=Lismore%20Makers%20Hall` safely.
   *
   * @example
   *
   * @see SearchPage - the only caller.
   */
  searchEvents(filters: EventSearchFilters): Observable<CharityEvent[]> {
    let params = new HttpParams();

    // status: upcoming (server default) | past | all
    if (filters.status) {
      params = params.set('status', filters.status);
    }
    if (filters.date) {
      params = params.set('date', filters.date);
    }
    if (filters.location && filters.location.trim().length > 0) {
      params = params.set('location', filters.location.trim());
    }
    if (filters.category !== undefined && filters.category !== null && filters.category !== '') {
      params = params.set('category', String(filters.category));
    }

    return this.withTimeout(this.http.get<CharityEvent[]>(`${this.baseUrl}/api/events`, { params }));
  }

  /**
   * GET /api/events/:id - everything the detail page and the register page need.
   *
   * @param id - The event id read from the route (`/event/:id`). Sent as it
   * arrived; the API validates it and answers 400 when it is not a number.
   * @returns An observable of the event, its registrations (newest first) and the
   * summary totals.
   *
   * @throws An `HttpErrorResponse` through the observable's error channel: 404
   * for a missing or suspended event, 400 for a non-numeric id, 500 for a server
   * fault.
   *
   * @remarks
   * One request gives the page three things. The API deliberately returns the
   * event, its registrations and the totals together so the detail page does not
   * need three calls.
   *
   * @see EventDetailPage
   * @see RegisterPage
   */
  getEvent(id: number | string): Observable<EventDetailResponse> {
    return this.withTimeout(this.http.get<EventDetailResponse>(`${this.baseUrl}/api/events/${id}`));
  }

  /**
   * GET /api/categories - fills the category `<select>` on the search page.
   *
   * @returns An observable of every category the API knows about.
   *
   * @throws An `HttpErrorResponse` through the observable's error channel; the
   * search page shows a warning and still lets the form be submitted.
   */
  getCategories(): Observable<Category[]> {
    return this.withTimeout(this.http.get<Category[]>(`${this.baseUrl}/api/categories`));
  }

  /**
   * GET /api/event-dates - fills the date `<select>` on the search page.
   *
   * @returns An observable of "YYYY-MM-DD" strings - exactly the shape an
   * `<option>` list needs, so no mapping is required.
   *
   * @throws An `HttpErrorResponse` through the observable's error channel.
   */
  getEventDates(): Observable<string[]> {
    return this.withTimeout(this.http.get<string[]>(`${this.baseUrl}/api/event-dates`));
  }

  /**
   * GET /api/weather/:eventId - the 5-day Open-Meteo forecast.
   *
   * @param id - The event id; the API owns the coordinates that belong to it.
   * @returns An observable of the forecast, already translated into words by the
   * API.
   *
   * @throws An `HttpErrorResponse` through the observable's error channel. Two
   * statuses are expected and handled: 422 (the event has no coordinates yet) and
   * 502 (Open-Meteo could not be reached).
   *
   * @remarks
   * The browser never calls Open-Meteo directly: the API holds the coordinates
   * from the database and converts the raw `weather_code` numbers into words, so
   * the client only has to print the five days. The detail page treats both
   * expected failures as "weather is unavailable" and keeps the rest of the page
   * working.
   *
   * @see EventDetailPage
   */
  getWeather(id: number | string): Observable<WeatherForecast> {
    return this.withTimeout(this.http.get<WeatherForecast>(`${this.baseUrl}/api/weather/${id}`));
  }

  /**
   * POST /api/events/:id/registrations - create one registration.
   *
   * @param id - The event id from the `/register/:id` route.
   * @param registration - The attendee's details. Note what is NOT sent:
   * `total_amount`. The price calculation belongs to the server, so a visitor
   * cannot post a total of their own choosing.
   * @returns An observable of the 201 body: a message plus the stored
   * registration, including the total the server worked out.
   *
   * @throws An `HttpErrorResponse` through the observable's error channel: 400
   * (with a per-field `fields` map), 404 (no such event), 409 (already
   * registered, suspended or past) or 500.
   *
   * @example
   *
   * @see RegisterPage - where the 400 `fields` map is rendered under the inputs.
   */
  createRegistration(
    id: number | string,
    registration: CreateRegistrationRequest,
  ): Observable<CreateRegistrationResponse> {
    return this.withTimeout(
      this.http.post<CreateRegistrationResponse>(
        `${this.baseUrl}/api/events/${id}/registrations`,
        registration,
      ),
    );
  }
}
