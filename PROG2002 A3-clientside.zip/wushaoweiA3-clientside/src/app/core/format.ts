/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * the small pure functions the templates use to turn raw API values into
 * something a person can read.
 *
 * @file app/core/format.ts
 * @file app/core/format.ts
 */

import type { Money } from './models';

/** Abbreviated month names, indexed by month number minus one. */
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/** Abbreviated weekday names, indexed by `Date.getUTCDay()` (Sunday is 0). */
const WEEKDAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

/**
 * Turn a DECIMAL-ish value into a real number.
 *
 * @param value - The raw value from the API: a number, a numeric string, or
 * `null` / `undefined`.
 * @returns The value as a finite number; `0` when it cannot be interpreted.
 *
 * @remarks
 * Needed because the API sends `"25.00"` (string) for MySQL DECIMAL columns and
 * `"11"` for the SUM() in `summary.tickets_sold`, while the contract documents
 * them as numbers. `Number("")` is 0 and `Number("abc")` is NaN, so both are
 * folded to 0 as well. Without this, `raised / goal` would be NaN on the page.
 *
 * @example
 */
export function toNumber(value: Money | null | undefined): number {
  const n = Number(value);
  return Number.isFinite(n) ? n : 0;
}

/**
 * Format a money value the way the site displays it.
 *
 * @param value - The raw money value (`"25.00"`, `25`, `null`, ...).
 * @returns A string such as `"$7,450.00"`; values that cannot be parsed become
 * `"$0.00"` because `toNumber` folds them to zero.
 *
 * @remarks
 * `en-AU` grouping gives the thousand separators; the dollar sign is added by
 * hand so the result is the same in every browser locale.
 *
 * @example
 *
 * @see toNumber - the normaliser this function is built on.
 */
export function formatMoney(value: Money | null | undefined): string {
  const amount = toNumber(value);
  return '$' + amount.toLocaleString('en-AU', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

/**
 * Format a forecast temperature for the weather strip.
 *
 * @param value - The temperature in degrees Celsius, or `null` / `undefined`
 * when the forecast has no value for that day.
 * @returns A string such as `"20.3°C"`, or an en dash when the value is missing.
 *
 * @example
 */
export function formatTemperature(value: number | null | undefined): string {
  if (value === null || value === undefined) {
    return '–';
  }
  // one decimal place, but "16.0" is shown as "16" because that reads better
  return (Math.round(value * 10) / 10).toString() + '°C';
}

/**
 * Split an API date string into its known pieces, without parsing it as a Date.
 *
 * @param value - A `"YYYY-MM-DD HH:mm:ss"` string, or `null` / `undefined`.
 * @returns The date, its numeric year/month/day and the `"HH:mm"` time, or
 * `null` when the value does not start with a valid `YYYY-MM-DD` date.
 *
 * @remarks
 * The contract is explicit about this: `event_date` is a plain
 * "YYYY-MM-DD HH:mm:ss" string with no timezone. `new Date("2026-10-27 06:30:00")`
 * is parsed as *local time* by some browsers and as *invalid* by others, which
 * would shift an event by a day. Slicing the known positions is exact.
 */
function parts(value: string | null | undefined): { date: string; year: number; month: number; day: number; time: string } | null {
  const text = (value ?? '').trim();
  const date = text.slice(0, 10);
  if (/^\d{4}-\d{2}-\d{2}$/.test(date) === false) {
    return null;
  }
  return {
    date,
    year: Number(date.slice(0, 4)),
    month: Number(date.slice(5, 7)),
    day: Number(date.slice(8, 10)),
    // "06:30:00" when present, otherwise an empty string
    time: /^\d{2}:\d{2}/.test(text.slice(11, 16)) ? text.slice(11, 16) : '',
  };
}

/**
 * Work out the weekday name for a date.
 *
 * @param year - The four-digit year.
 * @param month - The month number, 1-12.
 * @param day - The day of the month.
 * @returns The abbreviated weekday, e.g. `"Tue"`.
 *
 * @remarks
 * The weekday is computed from the numbers only - never from parsing text - and
 * `Date.UTC` keeps the calculation in UTC so the local timezone cannot shift it.
 */
function weekdayName(year: number, month: number, day: number): string {
  return WEEKDAYS[new Date(Date.UTC(year, month - 1, day)).getUTCDay()];
}

/**
 * Format the date part of an API timestamp.
 *
 * @param value - A `"YYYY-MM-DD HH:mm:ss"` string.
 * @returns A string such as `"Tue 27 Oct 2026"`, or an empty string when the
 * value is missing or malformed.
 *
 * @example
 */
export function formatEventDate(value: string | null | undefined): string {
  const p = parts(value);
  if (p === null) {
    return '';
  }
  return `${weekdayName(p.year, p.month, p.day)} ${p.day} ${MONTHS[p.month - 1]} ${p.year}`;
}

/**
 * Format the time part of an API timestamp as a 12-hour clock time.
 *
 * @param value - A `"YYYY-MM-DD HH:mm:ss"` string.
 * @returns A string such as `"6:30 am"`, or an empty string when there is no
 * time part or the value is malformed.
 *
 * @example
 */
export function formatEventTime(value: string | null | undefined): string {
  const p = parts(value);
  if (p === null || p.time === '') {
    return '';
  }
  const hour24 = Number(p.time.slice(0, 2));
  const minutes = p.time.slice(3, 5);
  const suffix = hour24 < 12 ? 'am' : 'pm';
  const hour12 = hour24 % 12 === 0 ? 12 : hour24 % 12;
  return `${hour12}:${minutes} ${suffix}`;
}

/**
 * Format an API timestamp as the date and time together.
 *
 * @param value - A `"YYYY-MM-DD HH:mm:ss"` string.
 * @returns A string such as `"Tue 27 Oct 2026, 6:30 am"`; when there is no time
 * part the date is returned on its own. Empty string for malformed input.
 *
 * @example
 *
 * @see formatEventDate
 * @see formatEventTime
 */
export function formatEventDateTime(value: string | null | undefined): string {
  const date = formatEventDate(value);
  const time = formatEventTime(value);
  return time === '' ? date : `${date}, ${time}`;
}

/**
 * Format a registration timestamp for the registration list.
 *
 * @param value - The registration's `registration_date`, a
 * `"YYYY-MM-DD HH:mm:ss"` string.
 * @returns A string such as `"12 Oct 2026, 6:22 pm"`, or an empty string when
 * the value is malformed.
 *
 * @remarks
 * Used in the registration list, where the year matters less than the day the
 * tickets were bought, so only the month is abbreviated.
 *
 * @example
 */
export function formatRegistrationDate(value: string | null | undefined): string {
  const p = parts(value);
  if (p === null) {
    return '';
  }
  const time = formatEventTime(value);
  const day = `${p.day} ${MONTHS[p.month - 1]} ${p.year}`;
  return time === '' ? day : `${day}, ${time}`;
}

/**
 * Format a forecast date, which carries no time part.
 *
 * @param value - A `"YYYY-MM-DD"` string from the weather forecast.
 * @returns A string such as `"Wed 14 Oct"`, or an empty string when the value is
 * malformed.
 *
 * @example
 */
export function formatShortDate(value: string | null | undefined): string {
  const p = parts(value);
  if (p === null) {
    return '';
  }
  return `${weekdayName(p.year, p.month, p.day)} ${p.day} ${MONTHS[p.month - 1]}`;
}
