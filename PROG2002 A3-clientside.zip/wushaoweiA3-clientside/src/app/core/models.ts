/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * the TypeScript shape of every JSON payload the API returns.
 *
 * @file app/core/models.ts
 * @file app/core/models.ts
 */

/**
 * A money value exactly as it arrives from the API.
 *
 * @remarks
 * The API contract writes `ticket_price` as the number 25.00, but MySQL DECIMAL
 * columns are handed to `res.json()` by mysql2 as the *string* "25.00" (the pool
 * does not enable the `decimalNumbers` option). The live API was checked while
 * building this page and returns strings, so this type accepts both and
 * `format.ts` normalises them through `toNumber()` before any arithmetic.
 * Accepting both keeps the code correct whether or not the server is later
 * configured to send real numbers.
 *
 * @see toNumber
 */
export type Money = number | string;

/** Same idea as Money, for the latitude/longitude coordinate columns. */
export type Decimal = number | string;

/**
 * The three states the server computes for an event.
 *
 * @remarks
 * `display_status` is worked out by MySQL (`event_date < NOW()`), which is why
 * the client never has to compare dates itself. The public endpoints only ever
 * publish `active` or `past`; a `suspended` event is filtered out server-side.
 */
export type DisplayStatus = 'active' | 'past' | 'suspended';

/** The stored status column - "past" is never stored, it is derived. */
export type EventStatus = 'active' | 'suspended';

/**
 * A charity event, exactly as returned by /api/events, /api/events/home and
 * /api/events/:id.
 *
 * @remarks
 * Every list and detail endpoint returns this same shape, including the joined
 * category and organisation columns. It is named `CharityEvent` rather than
 * `Event` on purpose: `Event` is a built-in DOM type, and shadowing it would
 * break `(submit)="onSearch($event)"` handlers where the parameter really is a
 * DOM Event.
 */
export interface CharityEvent {
  /** Primary key of the event. */
  event_id: number;
  /** The event's public title, e.g. "Coastal Sunrise Fun Run". */
  name: string;
  /** Plain string "YYYY-MM-DD HH:mm:ss" - deliberately NOT parsed by the app. */
  event_date: string;
  /** The place the event is held, e.g. "Lismore Riverside Park". */
  location: string;
  /** Latitude of the venue, as a DECIMAL string; used by the API for the forecast. */
  latitude: Decimal;
  /** Longitude of the venue, as a DECIMAL string. */
  longitude: Decimal;
  /** One sentence explaining what the money is raised for. */
  purpose: string;
  /** The longer description shown on the detail page. */
  description: string;
  /** Price of one ticket, formatted by `formatMoney`. */
  ticket_price: Money;
  /** The fundraising target for this event. */
  fundraising_goal: Money;
  /** How much has been raised so far, including registration fees. */
  amount_raised: Money;
  /** The stored column: `active` or `suspended`. */
  status: EventStatus;
  /** Already a web path such as "assets/images/coastal-sunrise-fun-run.jpg". */
  image_url: string;
  /** Foreign key of the organisation that runs the event. */
  organisation_id: number;
  /** Foreign key of the event's category. */
  category_id: number;
  /** Joined category name, e.g. "Fun Run". */
  category_name: string;
  /** Joined organisation name, e.g. "Kind". */
  organisation_name: string;
  /** Joined organisation mission statement, used by the home page. */
  organisation_mission: string;
  /** Joined organisation contact email. */
  organisation_email: string;
  /** Joined organisation contact phone number. */
  organisation_phone: string;
  /** The state the server computed for the badge: `active`, `past` or `suspended`. */
  display_status: DisplayStatus;
}

/**
 * One registration for an event.
 *
 * @remarks
 * On the public endpoints the server masks the personal columns before sending
 * them (email "e***i@example.com", phone "hidden") because anyone can read
 * /api/events/:id. The admin website talks to /api/admin/events/:id, which is
 * not masked. The client therefore shows the attendee name, the ticket count
 * and the date, and never pretends the masked values are the real ones.
 */
export interface Registration {
  /** Primary key of the registration. */
  registration_id: number;
  /** Attendee's first name. */
  first_name: string;
  /** Attendee's last name. */
  last_name: string;
  /** Attendee's email address, masked by the API on public endpoints. */
  email: string;
  /** Attendee's phone number, masked by the API on public endpoints. */
  phone: string;
  /** How many tickets this registration bought. */
  tickets: number;
  /** When the tickets were bought: "YYYY-MM-DD HH:mm:ss". */
  registration_date: string;
  /** Ticket price x tickets, calculated by the server. */
  total_amount: Money;
  /** The attendee's optional note, or null when none was given. */
  notes: string | null;
}

/**
 * The totals shown above the registration list.
 *
 * @remarks
 * `tickets_sold` and `amount_registered` are SQL SUM() results, so they arrive
 * as strings too. `latest_registration` is null when an event has no
 * registrations yet.
 */
export interface RegistrationSummary {
  /** How many registrations the event has. */
  registration_count: number;
  /** Total tickets sold - a SQL SUM(), so it may arrive as a string. */
  tickets_sold: number | string;
  /** Total money registered - a SQL SUM(), normalised by `formatMoney`. */
  amount_registered: Money;
  /** Timestamp of the newest registration, or null when there are none. */
  latest_registration: string | null;
}

/** One row of GET /api/categories - used to fill the category <select>. */
export interface Category {
  /** Primary key, sent as the value of the category option. */
  category_id: number;
  /** The category's display name, e.g. "Fun Run". */
  name: string;
  /** A short explanation of the category. */
  description: string;
}

/** GET /api/events/:id - one call gives the page everything it renders. */
export interface EventDetailResponse {
  /** The event itself. */
  event: CharityEvent;
  /** The event's registrations, newest first, as ordered by the SQL. */
  registrations: Registration[];
  /** The totals shown above the registration list. */
  summary: RegistrationSummary;
}

/** One day of the 5-day Open-Meteo forecast, already translated by the server. */
export interface WeatherDay {
  /** The forecast day, "YYYY-MM-DD". */
  date: string;
  /** The raw Open-Meteo weather code. */
  weather_code: number;
  /** The code translated into words by the API, e.g. "Light rain". */
  description: string;
  /** True when the day is suitable for an outdoor event. */
  good_weather: boolean;
  /** Forecast maximum temperature in degrees Celsius, or null. */
  temperature_max: number | null;
  /** Forecast minimum temperature in degrees Celsius, or null. */
  temperature_min: number | null;
  /** Chance of rain as a percentage, or null. */
  rain_chance: number | null;
}

/** GET /api/weather/:eventId */
export interface WeatherForecast {
  /** The event this forecast belongs to. */
  event_id: number;
  /** The event's name, repeated so the panel can label itself. */
  event_name: string;
  /** The venue the forecast is for. */
  location: string;
  /** Latitude the API asked Open-Meteo about. */
  latitude: number;
  /** Longitude the API asked Open-Meteo about. */
  longitude: number;
  /** The timezone Open-Meteo returned the forecast in. */
  timezone: string;
  /** The name of the provider, e.g. "Open-Meteo". */
  source: string;
  /** The next five days, oldest first. */
  days: WeatherDay[];
}

/**
 * The body of POST /api/events/:id/registrations.
 *
 * @remarks
 * `total_amount` is deliberately absent: the price is the server's business, so
 * a visitor cannot post a total of their own choosing.
 */
export interface CreateRegistrationRequest {
  /** Attendee's first name. */
  first_name: string;
  /** Attendee's last name. */
  last_name: string;
  /** Attendee's email address; the server enforces one registration per email. */
  email: string;
  /** Attendee's contact number. */
  phone: string;
  /** Number of tickets, 1-10. */
  tickets: number;
  /** Optional note for the organiser. */
  notes?: string;
}

/** The 201 body of POST /api/events/:id/registrations. */
export interface CreateRegistrationResponse {
  /** The API's own confirmation sentence. */
  message: string;
  /** The stored registration, as the database now holds it. */
  registration: {
    /** Primary key of the new registration. */
    registration_id: number;
    /** The event it belongs to. */
    event_id: number;
    /** The event's name, so the receipt can name it. */
    event_name: string;
    /** Number of tickets bought. */
    tickets: number;
    /** The total the SERVER calculated. */
    total_amount: Money;
  };
}

/**
 * The query string of GET /api/events.
 *
 * @remarks
 * Every field is optional and the server combines whichever ones are present
 * with AND - that is what lets the search page search on one, two or all three
 * criteria at once.
 */
export interface EventSearchFilters {
  /** `upcoming` (server default) | `past` | `all` */
  status?: string;
  /** "YYYY-MM-DD" */
  date?: string;
  /** Partial place text; the server matches it case-insensitively. */
  location?: string;
  /** category_id */
  category?: string | number;
}

/**
 * The per-field messages the API sends with a 400.
 *
 * @remarks
 * The named optional properties are the six registration inputs; the index
 * signature means a message for any other field the server may add is still
 * accepted (and reachable with `errors['some_field']`, because the project
 * enables `noPropertyAccessFromIndexSignature`).
 */
export interface RegistrationFieldErrors {
  /** Message for the first name input. */
  first_name?: string;
  /** Message for the last name input. */
  last_name?: string;
  /** Message for the email input. */
  email?: string;
  /** Message for the phone input. */
  phone?: string;
  /** Message for the ticket count input. */
  tickets?: string;
  /** Message for the optional note input. */
  notes?: string;
  /** Any further field the server decides to report on. */
  [field: string]: string | undefined;
}

/** The JSON body of every error response: 400, 404, 409, 422 and 502. */
export interface ApiErrorBody {
  /** The sentence the API wants the visitor to read. */
  error?: string;
  /** Per-field messages, present on a 400. */
  fields?: RegistrationFieldErrors;
}
