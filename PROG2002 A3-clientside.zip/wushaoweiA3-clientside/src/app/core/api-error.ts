/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * one place that turns an RxJS/HttpClient failure into a message that can be put
 * on the screen.
 *
 * @file app/core/api-error.ts
 * @file app/core/api-error.ts
 */

import { HttpErrorResponse } from '@angular/common/http';
import { TimeoutError } from 'rxjs';
import { environment } from '../../environments/environment';
import type { ApiErrorBody, RegistrationFieldErrors } from './models';

/** The friendly version of a failed request. */
export interface ApiError {
  /** The HTTP status, or 0 when the API could not be reached at all. */
  status: number;
  /** A sentence safe to show to a visitor. */
  message: string;
  /** Per-field messages from a 400, empty for every other status. */
  fields: RegistrationFieldErrors;
}

/**
 * Decide whether a failure means "there is nothing here to show".
 *
 * @param error - The normalised API error.
 * @returns `true` when the status means "this event is not there (or not public)".
 *
 * @remarks
 * The API answers 404 for a missing or suspended event and 400 for an id in the
 * URL that is not a positive whole number ("/event/abc"). To the visitor both
 * mean exactly the same thing, so they share one page state.
 */
export function isNotFound(error: ApiError): boolean {
  return error.status === 404 || error.status === 400;
}

/**
 * Normalise anything thrown by HttpClient into an `ApiError`.
 *
 * @param error - Whatever the `subscribe({ error })` callback received: usually
 * an `HttpErrorResponse`, but it may be any thrown value.
 * @returns A status, a sentence that is safe to show and, for a 400, the
 * per-field messages.
 *
 * @remarks
 * Three cases are worth naming:
 *  - status 0 means the request never arrived (API not started, or CORS), which
 *    is easy to hit during a demonstration, so it gets its own sentence;
 *  - the body may be a string if a proxy or the server answered with HTML;
 *  - a `fields` key is only trusted when it is genuinely an object.
 *
 * @example
 */
export function toApiError(error: unknown): ApiError {
  if (error instanceof HttpErrorResponse) {
    const body: unknown = error.error;
    let message = '';

    if (body !== null && typeof body === 'object' && typeof (body as ApiErrorBody).error === 'string') {
      message = (body as ApiErrorBody).error as string;
    } else if (typeof body === 'string' && body.trim().length > 0) {
      message = body.trim();
    } else if (error.status === 0) {
      // Read the address from the environment instead of writing it out here:
      // after deployment the site talks to the cPanel API, and a message telling
      // the visitor to check localhost:3000 would simply be wrong.
      message =
        'The event service could not be reached. Please check that the API is running at ' +
        environment.apiBaseUrl +
        '.';
    } else if (error.status === 500) {
      message = 'The event service had a problem. Please try again in a moment.';
    } else {
      message = `The event service returned an unexpected error (HTTP ${error.status}).`;
    }

    // The 400 body is `{ error, fields }`; keep the map only when it is real.
    const rawFields = body !== null && typeof body === 'object' ? (body as ApiErrorBody).fields : undefined;
    const fields: RegistrationFieldErrors =
      rawFields !== null && typeof rawFields === 'object' ? (rawFields as RegistrationFieldErrors) : {};

    return { status: error.status, message, fields };
  }

  // The request was made, but nothing arrived in time. `EventApiService` wraps
  // every call with `timeout(...)`, and this is that operator's error, so the
  // visitor gets a sentence about the wait instead of a frozen spinner. It is
  // treated as status 0 because, like a refused connection, no HTTP response ever
  // came back.
  if (error instanceof TimeoutError) {
    return {
      status: 0,
      message: 'The event service is taking too long to respond. Please try again.',
      fields: {},
    };
  }

  // A non-HTTP failure (a bug in the component, for example) still has to give
  // the user something to read rather than an empty page.
  return {
    status: 0,
    message: 'An unexpected error occurred while loading this page.',
    fields: {},
  };
}
