/**
 * PROG2002 Web Development II - Assessment 3
 * WU Shao Wei
 * app.spec.ts - the application shell.
 *
 * The shell is what makes the Header, Nav and Footer appear on EVERY page (they
 * sit outside `<router-outlet />`), so that is what this test checks, along with
 * the footer's contact details that the brief asks for on the home page.
 *
 * @remarks
 * `App` itself no longer owns any of that markup: when the pages were split into
 * the four segments, the header, nav and footer moved into their own components
 * under `shared/layout/`. These tests are what proves the shell still renders
 * exactly ONE of each - the "created once and common across all pages" claim -
 * and that the classes which used to be tested here are still reachable through
 * the composed DOM.
 *
 * @see App - the shell under test.
 * @see SiteHeaderComponent
 * @see SiteNavComponent
 * @see SiteFooterComponent
 */

import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { App } from './app';

/**
 * Creates the shell and renders one change-detection pass.
 *
 * @returns The rendered fixture and its native element.
 *
 * @remarks
 * An empty route table is enough: the shell only needs the router directives to
 * be available, not any particular page.
 */
function render() {
  const fixture = TestBed.createComponent(App);
  fixture.detectChanges();
  return { fixture, native: fixture.nativeElement as HTMLElement };
}

describe('App shell', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [App],
      providers: [provideRouter([])],
    }).compileComponents();
  });

  it('creates the shell', () => {
    const { fixture } = render();
    expect(fixture.componentInstance).toBeTruthy();
  });

  it('composes the four shared segments in the order Header, Nav, Body, Footer', () => {
    const { native } = render();

    const segments = Array.from(
      native.querySelectorAll('app-site-header, app-site-nav, main, app-site-footer'),
    ).map((element) => element.tagName.toLowerCase());

    expect(segments).toEqual(['app-site-header', 'app-site-nav', 'main', 'app-site-footer']);
  });

  it('renders exactly one <header>, one <nav>, one <footer> and one <main> landmark', () => {
    const { native } = render();

    // The whole point of the refactor: the shared segments are created once, so
    // there is never a second copy of a landmark anywhere in the app.
    expect(native.querySelectorAll('header').length).toBe(1);
    expect(native.querySelectorAll('nav').length).toBe(1);
    expect(native.querySelectorAll('footer').length).toBe(1);
    expect(native.querySelectorAll('main').length).toBe(1);
    // ... and the skip link has exactly one place to jump to.
    expect(native.querySelector('main#main')).not.toBeNull();
  });

  it('offers a keyboard skip link that targets the Body segment', () => {
    const { native } = render();
    const skip = native.querySelector('a.skip-link');

    expect(skip).not.toBeNull();
    expect(skip?.getAttribute('href')).toBe('#main');
    expect(skip?.textContent).toContain('Skip to the main content');
  });

  it('puts the navigation menu in the shell, so it is on every page', () => {
    const { native } = render();
    const links = Array.from(native.querySelectorAll('nav a'));

    expect(links.length).toBe(2);
    expect(links[0].textContent).toContain('Home');
    expect(links[0].getAttribute('href')).toBe('/');
    expect(links[1].textContent).toContain('Search events');
    // routerLink rendered a real href, so the link is followable and crawlable.
    expect(links[1].getAttribute('href')).toBe('/search');
  });

  it('shows the brand and the router outlet', () => {
    const { native } = render();

    expect(native.querySelector('.brand')?.textContent).toContain('Kind');
    expect(native.querySelector('router-outlet')).not.toBeNull();
  });

  it('shows the organisation contact details in the footer, as plain text', () => {
    const { native } = render();
    const text = native.textContent ?? '';

    expect(text).toContain('hello@kind.org');
    expect(text).toContain('(02) 6600 2000');
    // The details must not be clickable: the footer contains no anchors at all,
    // so nothing in it is underlined while the rest of the text is plain.
    expect(native.querySelectorAll('footer a').length).toBe(0);
    expect(native.innerHTML).not.toContain('mailto:');
  });
});
