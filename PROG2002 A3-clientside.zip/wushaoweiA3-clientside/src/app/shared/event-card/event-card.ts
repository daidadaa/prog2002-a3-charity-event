/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * one event, drawn as a card.
 *
 * @file app/shared/event-card/event-card.ts
 * @file app/shared/event-card/event-card.ts
 */

import { Component, computed, input } from '@angular/core';
import { TitleCasePipe } from '@angular/common';
import { RouterLink } from '@angular/router';
import { formatEventDateTime, formatMoney } from '../../core/format';
import type { CharityEvent } from '../../core/models';

/**
 * One event, drawn as a card on the home page and on the search results page.
 *
 * @remarks
 * Why it is a component: the home page and the search results page show exactly
 * the same card. Making it a component means the layout, the date formatting and
 * the image binding are written once; if the card changes, both pages change
 * together.
 *
 * It is a "presentational" component: it makes no HTTP calls and holds no state
 * of its own. It receives the event through a signal input and renders it, which
 * is why the parent owns the data flow - the parent took the event from
 * `EventApiService` and passes it down.
 *
 * @see HomePage - shows the card for the upcoming events.
 * @see SearchPage - shows the card with the Active / Past badge.
 */
@Component({
  selector: 'app-event-card',
  // TitleCasePipe so the badge reads "Active"/"Past" rather than "active"/"past"
  imports: [RouterLink, TitleCasePipe],
  templateUrl: './event-card.html',
  styleUrl: './event-card.css',
})
export class EventCardComponent {
  /**
   * `input.required<CharityEvent>()` is the signal-based alternative to the old
   * `@Input()` decorator. The parent binds it with `[event]="someSignal()"` and
   * reading it inside the component means calling `event()`. Because it is a
   * signal, a new value automatically re-renders the card.
   */
  readonly event = input.required<CharityEvent>();

  /**
   * Whether to show the Active / Past badge. The home page only lists upcoming
   * events, so it hides the badge; the search page can return past events too,
   * so it shows it. A default keeps the parent template short.
   */
  readonly showStatus = input(false);

  /**
   * The photograph for the event.
   *
   * @remarks
   * Reads `image_url` from the API and uses it exactly as it arrives.
   *
   * The API already stores a web path ("assets/images/coastal-sunrise-fun-run.jpg")
   * and the image files are in `public/assets/images/`, which the Angular build
   * copies to the root of `dist`. No path building is needed in the client, and
   * doing any would be wrong.
   */
  readonly imageUrl = computed(() => this.event().image_url);

  /**
   * The ticket price.
   *
   * @returns "$25.00" - `event.ticket_price` may arrive as the string "25.00".
   *
   * @see formatMoney
   */
  readonly price = computed(() => formatMoney(this.event().ticket_price));

  /**
   * The date and time the event starts.
   *
   * @returns "Tue 27 Oct 2026, 6:30 am" - built by slicing, never by
   * `new Date(text)`.
   *
   * @see formatEventDateTime
   */
  readonly when = computed(() => formatEventDateTime(this.event().event_date));

  /**
   * The sentence under the title.
   *
   * @returns `event.purpose`, kept short so the cards stay even.
   */
  readonly summary = computed(() => this.event().purpose);

  /**
   * A CSS class for the status badge.
   *
   * @returns `"badge badge-active"` or `"badge badge-past"`, so "past" gets a
   * grey badge.
   */
  readonly statusClass = computed(() => 'badge badge-' + this.event().display_status);
}
