/**
 * PROG2002 Web Development II - Assessment 3
 * WU Shao Wei
 * shared/layout/site-header/site-header.spec.ts
 *
 * The Header is one of the four shared page segments, so it has to render its
 * own content (the "Kind" brand) and it has to expose a real `<header>` landmark
 * on every page. That is what this spec checks.
 *
 * @see SiteHeaderComponent
 */

import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { SiteHeaderComponent } from './site-header';

/**
 * Creates the Header segment on its own.
 *
 * @returns The rendered fixture and its native element.
 *
 * @remarks
 * `provideRouter([])` is required even though this component navigates nowhere:
 * the template uses the `routerLink` directive, which needs a Router to inject.
 * An empty route table is enough - the Home link is a real URL, so no route has
 * to exist for the markup to be correct.
 */
function render() {
  const fixture = TestBed.createComponent(SiteHeaderComponent);
  fixture.detectChanges();
  return { fixture, native: fixture.nativeElement as HTMLElement };
}

describe('SiteHeaderComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SiteHeaderComponent],
      providers: [provideRouter([])],
    }).compileComponents();
  });

  it('renders the brand as a link back to the home page', () => {
    const { native } = render();
    const brand = native.querySelector('.brand');

    expect(brand).not.toBeNull();
    expect(brand?.textContent).toContain('Kind');
    // routerLink rendered a real href, so the link is followable and crawlable.
    expect(brand?.getAttribute('href')).toBe('/');
  });

  it('exposes a real <header> landmark with an accessible label on the brand', () => {
    const { native } = render();

    expect(native.querySelector('header.site-header')).not.toBeNull();
    expect(native.querySelector('.brand')?.getAttribute('aria-label')).toBe(
      'Kind - go to the home page',
    );
  });

  it('does not render the navigation or the footer, which are their own segments', () => {
    const { native } = render();

    expect(native.querySelector('nav')).toBeNull();
    expect(native.querySelector('footer')).toBeNull();
  });
});
