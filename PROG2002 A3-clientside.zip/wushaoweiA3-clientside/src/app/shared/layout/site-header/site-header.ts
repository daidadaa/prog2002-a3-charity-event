/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * ONE OF THE FOUR SHARED PAGE SEGMENTS: the **Header**.
 *
 * @file app/shared/layout/site-header/site-header.ts
 * @file app/shared/layout/site-header/site-header.ts
 */

import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

/**
 * The Header segment: the "Kind" brand, which doubles as a link home.
 *
 * One of the four shared page segments (Header, Nav, Body, Footer). It is
 * created once, here under `shared/layout/`, and the shell renders it on every
 * route.
 *
 * @remarks
 * The markup lives in `site-header.html` and the styles in `site-header.css`.
 * The `<header>` element is a real landmark, and it is the element that sticks
 * to the top of the viewport while a long page is scrolled; the sticky rule is
 * declared on `:host` (see the stylesheet) because a `position: sticky` element
 * can only travel inside its containing block.
 */
@Component({
  selector: 'app-site-header',
  imports: [RouterLink],
  templateUrl: './site-header.html',
  styleUrl: './site-header.css',
})
export class SiteHeaderComponent {}
