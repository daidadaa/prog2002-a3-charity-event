/**
 * PROG2002 Web Development II - Assessment 3
 * WU Shao Wei
 * shared/layout/site-nav/site-nav.spec.ts
 *
 * The Nav is one of the four shared page segments. The brief's point is that the
 * menu is created once and appears on all four pages, so this spec checks that
 * the component renders exactly the two links, that they point at the right
 * routes, and that the `<nav>` landmark is named for assistive technology.
 *
 * @see SiteNavComponent
 */

import { TestBed } from '@angular/core/testing';
import { Router, provideRouter } from '@angular/router';
import { SiteNavComponent } from './site-nav';

/**
 * The smallest route table that lets `routerLinkActive` decide which link is
 * open. Both entries are empty children, so no page component is needed just to
 * activate a menu item.
 */
const ROUTES = [
  { path: '', children: [] },
  { path: 'search', children: [] },
];

/**
 * Creates the Nav segment on its own.
 *
 * @returns The rendered fixture, its native element, and the two links.
 *
 * @remarks
 * `provideRouter(ROUTES)` gives `routerLink` and `routerLinkActive` the Router
 * they inject, and it is also what turns the directives into real `href`
 * attributes.
 */
function render() {
  const fixture = TestBed.createComponent(SiteNavComponent);
  fixture.detectChanges();
  const native = fixture.nativeElement as HTMLElement;
  return { fixture, native, links: Array.from(native.querySelectorAll('nav a')) };
}

describe('SiteNavComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SiteNavComponent],
      providers: [provideRouter(ROUTES)],
    }).compileComponents();
  });

  it('renders the Home and Search events links that every page shares', () => {
    const { links } = render();

    expect(links.length).toBe(2);
    expect(links[0].textContent).toContain('Home');
    expect(links[0].getAttribute('href')).toBe('/');
    expect(links[1].textContent).toContain('Search events');
    // routerLink rendered a real href, so the link is followable and crawlable.
    expect(links[1].getAttribute('href')).toBe('/search');
  });

  it('names the <nav> landmark and marks the open page with routerLinkActive', async () => {
    const router = TestBed.inject(Router);
    const { fixture, native } = render();
    const nav = native.querySelector('nav');

    expect(nav).not.toBeNull();
    expect(nav?.getAttribute('aria-label')).toBe('Main navigation');

    await router.navigateByUrl('/');
    fixture.detectChanges();

    const active = Array.from(native.querySelectorAll('nav a.active'));
    expect(active.length).toBe(1);
    expect(active[0].textContent).toContain('Home');
  });

  it('marks only the Search link active on "/search" (exact match on Home)', async () => {
    const router = TestBed.inject(Router);
    const fixture = TestBed.createComponent(SiteNavComponent);
    fixture.detectChanges();

    await router.navigateByUrl('/search');
    fixture.detectChanges();

    const native = fixture.nativeElement as HTMLElement;
    const active = Array.from(native.querySelectorAll('nav a.active'));

    // Without `[routerLinkActiveOptions]="{ exact: true }"` on the Home link the
    // prefix "/" would also match "/search" and TWO items would be highlighted.
    expect(active.length).toBe(1);
    expect(active[0].textContent).toContain('Search events');
  });
});
