/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * ONE OF THE FOUR SHARED PAGE SEGMENTS: the **Nav** (navigation menu).
 *
 * @file app/shared/layout/site-nav/site-nav.ts
 * @file app/shared/layout/site-nav/site-nav.ts
 */

import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';

/**
 * The Nav segment: the main navigation menu, shared by all four pages.
 *
 * One of the four shared page segments (Header, Nav, Body, Footer). It is
 * created once, here under `shared/layout/`, and the shell renders it on every
 * route.
 *
 * @remarks
 * The markup lives in `site-nav.html` and the styles in `site-nav.css`. The
 * `<nav>` element is a real landmark and carries `aria-label="Main navigation"`
 * so a screen-reader user can tell it apart from any other navigation on a page.
 *
 * The `:host` rule is deliberately unusual: the shell renders this segment as a
 * sibling of the header (as the four-segment brief requires), so the stylesheet
 * pulls the host up into the header's 72px band with a negative margin and keeps
 * it sticky, which reproduces the original single sticky header bar exactly.
 */
@Component({
  selector: 'app-site-nav',
  imports: [RouterLink, RouterLinkActive],
  templateUrl: './site-nav.html',
  styleUrl: './site-nav.css',
})
export class SiteNavComponent {}
