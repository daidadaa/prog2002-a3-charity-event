/**
 * PROG2002 Web Development II - Assessment 3
 * WU Shao Wei
 * shared/layout/site-footer/site-footer.spec.ts
 *
 * The Footer is one of the four shared page segments. This spec checks the two
 * things the brief asks the footer to show on every page: the organisation's
 * contact details and the copyright line - and that the contact details are plain
 * text rather than mailto: / tel: links, so nothing in the footer is underlined
 * and the two halves of it look like one design.
 *
 * @see SiteFooterComponent
 */

import { TestBed } from '@angular/core/testing';
import { SiteFooterComponent } from './site-footer';

/**
 * Creates the Footer segment on its own.
 *
 * @returns The rendered fixture and its native element.
 *
 * @remarks
 * No HTTP providers are needed here: unlike the pages, this component calls no
 * API and holds its values in local signals, so it renders synchronously.
 */
function render() {
  const fixture = TestBed.createComponent(SiteFooterComponent);
  fixture.detectChanges();
  return { fixture, native: fixture.nativeElement as HTMLElement };
}

describe('SiteFooterComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SiteFooterComponent],
    }).compileComponents();
  });

  it('shows the organisation contact details as plain text, not links', () => {
    const { native } = render();

    expect(native.textContent).toContain('hello@kind.org');
    expect(native.textContent).toContain('(02) 6600 2000');

    // Neither the email nor the phone may be clickable. No anchor at all should
    // exist in the footer: an anchor is what used to underline only the right
    // column and make the two halves look inconsistent.
    expect(native.querySelectorAll('a').length).toBe(0);
    expect(native.innerHTML).not.toContain('mailto:');
    expect(native.innerHTML).not.toContain('tel:');
  });

  it('shows the copyright line with the current year', () => {
    const { native } = render();
    const note = native.querySelector('.site-footer-note');

    expect(note).not.toBeNull();
    expect(note?.textContent).toContain(String(new Date().getFullYear()));
    expect(note?.textContent).toContain('Kind');
    expect(note?.textContent).toContain('PROG2002 Assessment 3');
    // the wording no longer calls the site a "demonstration site"
    expect(note?.textContent).not.toContain('demonstration');
  });

  it('exposes a real <footer> landmark', () => {
    const { native } = render();

    expect(native.querySelector('footer.site-footer')).not.toBeNull();
  });
});
