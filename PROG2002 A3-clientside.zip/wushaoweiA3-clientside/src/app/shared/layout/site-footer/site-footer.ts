/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * ONE OF THE FOUR SHARED PAGE SEGMENTS: the **Footer**.
 *
 * @file app/shared/layout/site-footer/site-footer.ts
 * @file app/shared/layout/site-footer/site-footer.ts
 */

import { Component, signal } from '@angular/core';

/**
 * The Footer segment: contact details and the copyright line.
 *
 * One of the four shared page segments (Header, Nav, Body, Footer). It is
 * created once, here under `shared/layout/`, and the shell renders it on every
 * route.
 *
 * @remarks
 * The markup lives in `site-footer.html` and the styles in `site-footer.css`.
 * The `<footer>` element is a real landmark, so a screen-reader user can jump
 * straight to it.
 */
@Component({
  selector: 'app-site-footer',
  templateUrl: './site-footer.html',
  styleUrl: './site-footer.css',
})
export class SiteFooterComponent {
  /**
   * The year shown in the copyright line.
   *
   * A signal rather than a constant so the value is read at run time (and it
   * recomputes if it is ever refreshed in place).
   */
  protected readonly currentYear = signal(new Date().getFullYear());

  /** The organisation's public contact email, shown in the footer. */
  protected readonly contactEmail = signal('hello@kind.org');

  /** The organisation's public contact phone number, shown in the footer. */
  protected readonly contactPhone = signal('(02) 6600 2000');
}
