/**
 * PROG2002 Web Development II - Assessment 3
 * WU Shao Wei
 * pages/register/register.spec.ts
 *
 * @remarks
 * The registration page carries the most marking weight, so its tests map one to
 * one onto the brief:
 *   * the event being registered for is shown,
 *   * the total is ticket price x tickets and updates as the count changes,
 *   * client-side validation stops a bad submission before it is sent,
 *   * 201 shows the registration id and the total,
 *   * a 400 puts the server's `fields` map next to the input AND its `error` in
 *     the form-level alert,
 *   * a 409 shows the server's message.
 *
 * @see RegisterPage - the page under test.
 */

import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { ActivatedRoute, convertToParamMap, provideRouter } from '@angular/router';
import type { CharityEvent } from '../../core/models';
import { RegisterPage } from './register';

/** Base URL of the API the page's service is configured to call. */
const BASE = 'http://localhost:3000';

/** GET /api/events/1 - the event being registered for. */
const EVENT_URL = `${BASE}/api/events/1`;

/** POST /api/events/1/registrations - where the form submits. */
const POST_URL = `${BASE}/api/events/1/registrations`;

/** One event in exactly the shape the live API returns it (DECIMALs as strings). */
const EVENT: CharityEvent = {
  event_id: 1,
  name: 'Coastal Sunrise Fun Run',
  event_date: '2026-10-27 06:30:00',
  location: 'Lismore Riverside Park',
  latitude: '-28.813500',
  longitude: '153.277300',
  purpose: 'Fund youth mental health outreach.',
  description: 'Choose a 5 km or 10 km riverside course.',
  ticket_price: '25.00',
  fundraising_goal: '18000.00',
  amount_raised: '7450.00',
  status: 'active',
  image_url: 'assets/images/coastal-sunrise-fun-run.jpg',
  organisation_id: 1,
  category_id: 1,
  category_name: 'Fun Run',
  organisation_name: 'Kind',
  organisation_mission: 'We bring neighbours together.',
  organisation_email: 'hello@kind.org',
  organisation_phone: '(02) 6600 2000',
  display_status: 'active',
};

/**
 * Covers the whole registration journey: the loaded event, the running total,
 * client-side validation, and the 201 / 400 / 409 answers of the POST.
 *
 * @see RegisterPage
 */
describe('RegisterPage', () => {
  let httpMock: HttpTestingController;

  /**
   * The route parameter for the next component that is created. The component
   * reads `route.snapshot.paramMap` while it is being constructed, so changing
   * this before `createComponent` is enough to simulate a different URL such as
   * "/register/abc" - without rebuilding the whole TestBed mid-test.
   */
  let routeId = '1';

  beforeEach(async () => {
    routeId = '1';
    await TestBed.configureTestingModule({
      imports: [RegisterPage],
      providers: [
        provideRouter([]),
        provideHttpClient(),
        provideHttpClientTesting(),
        {
          provide: ActivatedRoute,
          useValue: {
            get snapshot() {
              return { paramMap: convertToParamMap({ id: routeId }) };
            },
          },
        },
      ],
    }).compileComponents();

    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => httpMock.verify());

  /**
   * Renders the page with the event already loaded.
   *
   * @returns The rendered fixture, its native element and the component instance.
   */
  function render() {
    const fixture = TestBed.createComponent(RegisterPage);
    fixture.detectChanges(); // ngOnInit -> GET /api/events/1
    httpMock.expectOne(EVENT_URL).flush({
      event: EVENT,
      registrations: [],
      summary: { registration_count: 0, tickets_sold: 0, amount_registered: '0.00', latest_registration: null },
    });
    fixture.detectChanges();
    return {
      fixture,
      native: fixture.nativeElement as HTMLElement,
      component: fixture.componentInstance,
    };
  }

  /**
   * Fills in a valid form so that the next submit passes client-side validation.
   *
   * @param native - The rendered page element that contains the form.
   *
   * @remarks
   * The nested `set` helper also dispatches the `input` event, because the page
   * reads the values straight out of the DOM events rather than from ngModel.
   */
  function fillValidForm(native: HTMLElement) {
    const set = (selector: string, value: string) => {
      const input = native.querySelector(selector) as HTMLInputElement;
      input.value = value;
      input.dispatchEvent(new Event('input'));
      return input;
    };
    set('#first_name', 'Amelia');
    set('#last_name', 'Nguyen');
    set('#email', 'amelia.nguyen@example.com');
    set('#phone', '0400 111 201');
    set('#tickets', '2');
  }

  /**
   * Presses the form's submit button the way a browser would.
   *
   * @param native - The rendered page element that contains the form.
   */
  function submit(native: HTMLElement): void {
    native.querySelector('form')!.dispatchEvent(new Event('submit'));
  }

  it('shows the event the visitor is registering for', () => {
    const { native } = render();
    const text = native.textContent ?? '';

    expect(text).toContain('Coastal Sunrise Fun Run');
    expect(text).toContain('Tue 27 Oct 2026, 6:30 am');
    expect(text).toContain('Lismore Riverside Park');
    expect(text).toContain('$25.00'); // the ticket price in the summary panel
    const image = native.querySelector('.aside-event img') as HTMLImageElement;
    expect(image.getAttribute('src')).toBe('assets/images/coastal-sunrise-fun-run.jpg');
  });

  it('shows the computed total and updates it as the ticket count changes', () => {
    const { fixture, native, component } = render();

    // One ticket by default: $25.00.
    expect(component.ticketCount()).toBe(1);
    expect(component.totalLabel()).toBe('$25.00');
    expect(native.textContent).toContain('$25.00');
    expect(native.textContent).toContain('1 ticket x $25.00 ticket price');

    // Three tickets -> $75.00, with no server round trip.
    const tickets = native.querySelector('#tickets') as HTMLInputElement;
    tickets.value = '3';
    tickets.dispatchEvent(new Event('input'));

    expect(component.total()).toBe(75);
    expect(component.totalLabel()).toBe('$75.00');
    fixture.detectChanges();
    expect(native.textContent).toContain('3 tickets x $25.00 ticket price');
  });

  it('validates on the client first and never sends a bad form', () => {
    const { fixture, native } = render();

    // Submit the empty form.
    submit(native);
    // The validation messages are signals, so one render pass shows them.
    fixture.detectChanges();

    // No POST was made. (afterEach's httpMock.verify() would also fail if one had been.)
    expect(native.textContent).toContain('Please correct the highlighted fields.');
    expect(native.querySelector('#first_name-error')?.textContent).toContain('Your first name is required.');
    expect(native.querySelector('#last_name-error')?.textContent).toContain('Your last name is required.');
    expect(native.querySelector('#email-error')?.textContent).toContain('Your email address is required.');
    expect(native.querySelector('#phone-error')?.textContent).toContain('A contact number is required.');
  });

  it('rejects an invalid email and an out-of-range ticket count', () => {
    const { native, component } = render();
    fillValidForm(native);

    const email = native.querySelector('#email') as HTMLInputElement;
    email.value = 'not-an-email';
    email.dispatchEvent(new Event('input'));

    const tickets = native.querySelector('#tickets') as HTMLInputElement;
    tickets.value = '11';
    tickets.dispatchEvent(new Event('input'));

    submit(native);

    expect(component.fieldErrors().email).toContain('valid email');
    expect(component.fieldErrors().tickets).toContain('between 1 and 10');
  });

  it('POSTs a valid registration and shows the confirmation with the id and total', () => {
    const { fixture, native } = render();
    fillValidForm(native);
    submit(native);

    const request = httpMock.expectOne(POST_URL);
    expect(request.request.method).toBe('POST');
    expect(request.request.body).toEqual({
      first_name: 'Amelia',
      last_name: 'Nguyen',
      email: 'amelia.nguyen@example.com',
      phone: '0400 111 201',
      tickets: 2,
      notes: '',
    });
    // The browser must never dictate the price.
    expect(request.request.body.total_amount).toBeUndefined();

    request.flush(
      {
        message: 'Thank you, your registration has been received.',
        registration: {
          registration_id: 42,
          event_id: 1,
          event_name: 'Coastal Sunrise Fun Run',
          tickets: 2,
          total_amount: '50.00',
        },
      },
      { status: 201, statusText: 'Created' },
    );
    // The 201 switches the page to the receipt state, so render it.
    fixture.detectChanges();
    const text = native.textContent ?? '';

    expect(text).toContain('Registration confirmed');
    expect(text).toContain('Thank you, your registration has been received.');
    expect(text).toContain('#42');
    expect(text).toContain('$50.00');
    expect(native.querySelector('.confirmation')).not.toBeNull();
    // The visitor can get back to the event or home.
    expect(native.querySelector('a[href="/event/1"]')).not.toBeNull();
    expect(native.querySelector('a[href="/"]')).not.toBeNull();
  });

  it('shows the 400 `fields` map next to the input and the `error` at form level', () => {
    const { fixture, native } = render();
    fillValidForm(native);
    submit(native);

    httpMock.expectOne(POST_URL).flush(
      {
        error: 'Please correct the highlighted fields.',
        fields: { email: 'That email address is already in use for this event.' },
      },
      { status: 400, statusText: 'Bad Request' },
    );
    // The error signals were written by the subscribe callback; render them.
    fixture.detectChanges();
    const text = native.textContent ?? '';

    // Form-level: the server's `error`.
    expect(native.querySelector('.alert-error')?.textContent).toContain(
      'Please correct the highlighted fields.',
    );
    // Per-field: the server's message, not the client's, is what is shown.
    expect(native.querySelector('#email-error')?.textContent).toContain(
      'That email address is already in use for this event.',
    );
    expect(text).toContain('That email address is already in use for this event.');
  });

  it('shows the 409 message when the email has already registered', () => {
    const { fixture, native, component } = render();
    fillValidForm(native);
    submit(native);

    httpMock
      .expectOne(POST_URL)
      .flush(
        { error: 'This email address has already registered for this event.' },
        { status: 409, statusText: 'Conflict' },
      );
    fixture.detectChanges();

    expect(native.querySelector('.alert-error')?.textContent).toContain(
      'This email address has already registered for this event.',
    );
    // It is a form-level problem, not a field-level one.
    expect(component.fieldErrors().email).toBeUndefined();
  });

  it('shows the 409 message when the event has already taken place', () => {
    const { fixture, native } = render();
    fillValidForm(native);
    submit(native);

    httpMock
      .expectOne(POST_URL)
      .flush({ error: 'This event has already taken place.' }, { status: 409, statusText: 'Conflict' });
    fixture.detectChanges();

    expect(native.querySelector('.alert-error')?.textContent).toContain(
      'This event has already taken place.',
    );
  });

  it('clears the server message for a field once the visitor edits it', () => {
    const { native, component } = render();
    fillValidForm(native);
    submit(native);

    httpMock
      .expectOne(POST_URL)
      .flush({ error: 'Nope.', fields: { email: 'That email is taken.' } }, { status: 400, statusText: 'Bad Request' });
    expect(component.fieldErrors().email).toBe('That email is taken.');

    const email = native.querySelector('#email') as HTMLInputElement;
    email.value = 'someone.else@example.com';
    email.dispatchEvent(new Event('input'));

    // The stale warning disappears with the correction.
    expect(component.fieldErrors().email).toBeUndefined();
  });

  it('shows the friendly not-found state for an invalid event id without requesting it', () => {
    routeId = 'abc';

    const fixture = TestBed.createComponent(RegisterPage);
    fixture.detectChanges();

    const native = fixture.nativeElement as HTMLElement;
    expect(native.textContent).toContain('This event could not be found');
    // No request was made: "/register/abc" can never be a valid event, so there
    // is nothing worth asking the API. `afterEach` verifies that.
    httpMock.expectNone(() => true);
  });

  it('shows the friendly not-found state when the API answers 404', () => {
    const fixture = TestBed.createComponent(RegisterPage);
    fixture.detectChanges();
    httpMock
      .expectOne(EVENT_URL)
      .flush({ error: 'This event could not be found.' }, { status: 404, statusText: 'Not Found' });
    fixture.detectChanges();

    expect((fixture.nativeElement as HTMLElement).textContent).toContain('This event could not be found');
  });
});
