/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * the registration page of Assessment 3.
 *
 * @file app/pages/register/register.ts
 * @file app/pages/register/register.ts
 */

import { Component, DestroyRef, OnInit, computed, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { isNotFound, toApiError } from '../../core/api-error';
import { EventApiService } from '../../core/event-api.service';
import { formatEventDateTime, formatMoney, toNumber } from '../../core/format';
import type {
  CharityEvent,
  CreateRegistrationResponse,
  RegistrationFieldErrors,
} from '../../core/models';

/** The five states this page can be in. */
type RegisterState = 'loading' | 'notFound' | 'error' | 'form' | 'done';

/**
 * The Register page: the form that buys tickets for one event, the running total
 * beside it, and the receipt the API returns.
 *
 * @remarks
 * The event being registered for comes from `EventApiService.getEvent(id)`,
 * where `id` is the `:id` of the `/register/:id` route; the receipt comes from
 * `EventApiService.createRegistration(id, body)`.
 */
@Component({
  selector: 'app-register',
  imports: [RouterLink],
  templateUrl: './register.html',
  styleUrl: './register.css',
})
export class RegisterPage implements OnInit {
  private readonly api = inject(EventApiService);
  private readonly route = inject(ActivatedRoute);
  private readonly destroyRef = inject(DestroyRef);

  /**
   * The ":id" of "/register/:id". Public because the template builds links such
   * as `[routerLink]="['/event', eventId]"` from it.
   */
  readonly eventId = this.route.snapshot.paramMap.get('id') ?? '';

  /** The event being registered for, or null until the API answers. */
  readonly event = signal<CharityEvent | null>(null);

  /** True while GET /api/events/:id is in flight. */
  readonly loading = signal(true);

  /** True for a 404/400: the event is missing or suspended. */
  readonly notFound = signal(false);

  /** The message for a general failure, shown with a retry button. */
  readonly loadError = signal('');

  /**
   * The first name field.
   *
   * @remarks
   * The form keeps one signal per field, read straight from the DOM events. Each
   * value is a string, exactly as the control holds it, so nothing is re-written
   * under the visitor's fingers while they type.
   */
  readonly firstName = signal('');

  /** The last name field. */
  readonly lastName = signal('');

  /** The email field; the server enforces one registration per address. */
  readonly email = signal('');

  /** The contact number field. */
  readonly phone = signal('');

  /**
   * The number of tickets, stored as text rather than a number.
   *
   * @remarks
   * A number input can be left empty (or hold "abc" while the visitor is typing)
   * and `Number('')` is 0, so storing a number would rewrite the box as the
   * visitor types. Keeping the raw text and converting when it is needed leaves
   * the input under their control.
   */
  readonly ticketsInput = signal('1');

  /** The optional note field. */
  readonly notes = signal('');

  /** Set on the first submit, so errors appear after trying, not while typing. */
  readonly submitAttempted = signal(false);

  /** True while the POST is in flight, which stops a double submission. */
  readonly submitting = signal(false);

  /** The per-field messages that came back with a 400. */
  readonly serverFieldErrors = signal<RegistrationFieldErrors>({});

  /** The form-level message: the 400 `error`, or the 409/404 text. */
  readonly formError = signal('');

  /** Filled by a successful 201; its presence switches the page to the receipt. */
  readonly confirmation = signal<CreateRegistrationResponse | null>(null);

  /**
   * The ticket count as a whole number.
   *
   * @returns The typed count, or 0 for an empty box and for anything that is not
   * a finite number. Used for the running total only.
   */
  readonly ticketCount = computed(() => {
    const text = this.ticketsInput().trim();
    if (text === '') {
      return 0;
    }
    const value = Number(text);
    return Number.isFinite(value) ? Math.trunc(value) : 0;
  });

  /**
   * The running total the brief asks for: ticket price x number of tickets.
   *
   * @remarks
   * It recalculates the moment either the event or the ticket count changes,
   * because both are signals. `toNumber` handles the "25.00" string that MySQL
   * sends for a DECIMAL column.
   */
  readonly total = computed(() => toNumber(this.event()?.ticket_price) * this.ticketCount());

  /** The total as money, e.g. "$75.00". */
  readonly totalLabel = computed(() => formatMoney(this.total()));

  /** The ticket price on its own, e.g. "$25.00". */
  readonly priceLabel = computed(() => formatMoney(this.event()?.ticket_price));

  /**
   * The line that shows the visitor how the total was reached.
   *
   * @returns A sentence such as "3 tickets x $25.00 ticket price".
   */
  readonly calculation = computed(() => {
    const count = this.ticketCount();
    const noun = count === 1 ? 'ticket' : 'tickets';
    return `${count} ${noun} x ${this.priceLabel()} ticket price`;
  });

  /** The event's date and time, e.g. "Tue 27 Oct 2026, 6:30 am". */
  readonly when = computed(() => formatEventDateTime(this.event()?.event_date));

  /** The total the server calculated, shown on the receipt. */
  readonly confirmationTotal = computed(() =>
    formatMoney(this.confirmation()?.registration.total_amount ?? 0),
  );

  /**
   * The messages to show under the inputs.
   *
   * @returns One message per field that is wrong, keyed by the field name.
   *
   * @remarks
   * The client's own rules run once the visitor has pressed the button, and the
   * server's 400 map is layered on top, so the server always has the last word.
   * Spreading the objects is enough because the keys are the field names.
   *
   * @see validate
   */
  readonly fieldErrors = computed<RegistrationFieldErrors>(() => {
    const local = this.submitAttempted() ? this.validate() : {};
    return { ...local, ...this.serverFieldErrors() };
  });

  /**
   * Which of the five states is on screen.
   *
   * @returns `'loading'`, `'notFound'`, `'error'`, `'form'` or `'done'` - used by
   * the `@switch` in the template.
   */
  readonly stateName = computed<RegisterState>(() => {
    if (this.loading()) {
      return 'loading';
    }
    if (this.notFound()) {
      return 'notFound';
    }
    if (this.loadError()) {
      return 'error';
    }
    return this.confirmation() === null ? 'form' : 'done';
  });

  /**
   * Angular lifecycle hook: decides whether the event has to be fetched at all.
   *
   * @remarks
   * "/register/abc" could never be an event, so the page goes straight to the
   * friendly state rather than making a request that is certain to be a 400.
   *
   * @see loadEvent
   */
  ngOnInit(): void {
    if (/^[0-9]+$/.test(this.eventId) === false) {
      this.notFound.set(true);
      this.loading.set(false);
      return;
    }
    this.loadEvent();
  }

  /**
   * GET /api/events/:id - the event the visitor is registering for.
   *
   * @remarks
   * The detail endpoint is reused rather than a special "event for registration"
   * one: it already returns everything the summary panel needs, and it is the
   * same resource.
   *
   * @see EventApiService.getEvent
   */
  private loadEvent(): void {
    this.loading.set(true);
    this.loadError.set('');
    this.notFound.set(false);

    this.api
      .getEvent(this.eventId)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (response) => {
          this.event.set(response.event);
          this.loading.set(false);
        },
        error: (error: unknown) => {
          const apiError = toApiError(error);
          if (isNotFound(apiError)) {
            this.notFound.set(true);
          } else {
            this.loadError.set(apiError.message);
          }
          this.loading.set(false);
        },
      });
  }

  /** The "try again" button of the load-error state. */
  retry(): void {
    this.loadEvent();
  }

  /**
   * The client-side rules, run after the first submit.
   *
   * @returns One message per invalid field, or an empty object when the form is
   * ready to send.
   *
   * @remarks
   * These rules deliberately mirror `validation.validateRegistration()` in the
   * API so the visitor sees the same wording either way. They are a convenience,
   * not a security measure: the server repeats every check.
   *
   * @example
   */
  private validate(): RegistrationFieldErrors {
    const errors: RegistrationFieldErrors = {};

    const firstName = this.firstName().trim();
    if (firstName.length === 0) {
      errors.first_name = 'Your first name is required.';
    } else if (firstName.length > 80) {
      errors.first_name = 'Your first name cannot be longer than 80 characters.';
    }

    const lastName = this.lastName().trim();
    if (lastName.length === 0) {
      errors.last_name = 'Your last name is required.';
    } else if (lastName.length > 80) {
      errors.last_name = 'Your last name cannot be longer than 80 characters.';
    }

    const email = this.email().trim();
    if (email.length === 0) {
      errors.email = 'Your email address is required.';
    } else if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) === false) {
      errors.email = 'Please enter a valid email address.';
    }

    const phone = this.phone().trim();
    if (phone.length === 0) {
      errors.phone = 'A contact number is required.';
    } else if (/^[0-9+\-() ]{6,40}$/.test(phone) === false) {
      errors.phone = 'Please enter a contact number using digits, spaces, +, - or ( ).';
    }

    // The ticket count is a whole number between 1 and 10. Both the empty box
    // and "1.5" get the first message, exactly as the server does it.
    const ticketsText = this.ticketsInput().trim();
    const tickets = Number(ticketsText);
    if (ticketsText === '' || Number.isInteger(tickets) === false) {
      errors.tickets = 'Please enter a whole number of tickets.';
    } else if (tickets < 1 || tickets > 10) {
      errors.tickets = 'You can buy between 1 and 10 tickets.';
    }

    if (this.notes().trim().length > 255) {
      errors.notes = 'The note cannot be longer than 255 characters.';
    }

    return errors;
  }

  /**
   * Reads the string value out of an `<input>` or a `<textarea>`.
   *
   * @param domEvent - The DOM event raised by the control.
   * @returns The control's current value, or an empty string when the event has
   * no element target.
   *
   * @remarks
   * The parameter is the DOM's own `Event`, which is why the API's event shape is
   * named `CharityEvent` in models.ts - the two would otherwise clash here.
   */
  private valueOf(domEvent: Event): string {
    const target = domEvent.target as HTMLInputElement | HTMLTextAreaElement | null;
    return target === null ? '' : target.value;
  }

  /**
   * Forget the server's message for a field as soon as the visitor edits it.
   *
   * @param field - The field whose server message should be dropped.
   *
   * @remarks
   * Otherwise a "that email is already registered" warning would sit under an
   * input the visitor has just corrected, which is confusing.
   */
  private clearServerError(field: keyof RegistrationFieldErrors): void {
    const current = this.serverFieldErrors();
    if (current[field] === undefined) {
      return;
    }
    const next = { ...current };
    delete next[field];
    this.serverFieldErrors.set(next);
  }

  /**
   * Handles typing in the first name box.
   *
   * @param domEvent - The `input` event of the first name `<input>`.
   */
  onFirstNameInput(domEvent: Event): void {
    this.firstName.set(this.valueOf(domEvent));
    this.clearServerError('first_name');
  }

  /**
   * Handles typing in the last name box.
   *
   * @param domEvent - The `input` event of the last name `<input>`.
   */
  onLastNameInput(domEvent: Event): void {
    this.lastName.set(this.valueOf(domEvent));
    this.clearServerError('last_name');
  }

  /**
   * Handles typing in the email box.
   *
   * @param domEvent - The `input` event of the email `<input>`.
   */
  onEmailInput(domEvent: Event): void {
    this.email.set(this.valueOf(domEvent));
    this.clearServerError('email');
  }

  /**
   * Handles typing in the contact number box.
   *
   * @param domEvent - The `input` event of the phone `<input>`.
   */
  onPhoneInput(domEvent: Event): void {
    this.phone.set(this.valueOf(domEvent));
    this.clearServerError('phone');
  }

  /**
   * Handles typing in the ticket count box.
   *
   * @param domEvent - The `input` event of the tickets `<input>`.
   */
  onTicketsInput(domEvent: Event): void {
    this.ticketsInput.set(this.valueOf(domEvent));
    this.clearServerError('tickets');
  }

  /**
   * Handles typing in the optional note box.
   *
   * @param domEvent - The `input` event of the notes `<textarea>`.
   */
  onNotesInput(domEvent: Event): void {
    this.notes.set(this.valueOf(domEvent));
    this.clearServerError('notes');
  }

  /**
   * Submits the registration form.
   *
   * @param domEvent - The form's `submit` event.
   *
   * @remarks
   * The order matters: the default form submission is cancelled first, a second
   * click while the POST is still running is ignored (it would create a duplicate
   * registration), then the client validates. Only when everything passes is the
   * POST sent - and it deliberately sends no `total_amount`, because the server
   * works that out.
   *
   * @example
   *
   * @see EventApiService.createRegistration
   */
  onSubmit(domEvent: Event): void {
    // Stop the browser navigating away with its own form submission.
    domEvent.preventDefault();

    // A second click while the first POST is still running would create a second
    // registration, so it is ignored.
    if (this.submitting()) {
      return;
    }

    this.submitAttempted.set(true);
    this.formError.set('');
    this.serverFieldErrors.set({});

    // 1. Client-side check. If anything is wrong the request is not sent at all.
    if (Object.keys(this.validate()).length > 0) {
      this.formError.set('Please correct the highlighted fields.');
      return;
    }

    if (this.event() === null) {
      this.formError.set('The event has not loaded yet. Please try again in a moment.');
      return;
    }

    // 2. The POST. Note: no total_amount - the server works that out.
    this.submitting.set(true);
    this.api
      .createRegistration(this.eventId, {
        first_name: this.firstName().trim(),
        last_name: this.lastName().trim(),
        email: this.email().trim().toLowerCase(),
        phone: this.phone().trim(),
        tickets: Number(this.ticketsInput()),
        notes: this.notes().trim(),
      })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (response) => {
          // 201: the page switches to the receipt state.
          this.confirmation.set(response);
          this.submitting.set(false);
        },
        error: (error: unknown) => {
          const apiError = toApiError(error);

          // `fields` is present on a 400 and empty on every other status, so
          // setting it unconditionally is safe.
          this.serverFieldErrors.set(apiError.fields);

          // 400 -> "Please correct the highlighted fields."
          // 409 -> "This email address has already registered for this event.",
          //        "This event is currently suspended...", "This event has
          //        already taken place."
          // 404 -> "This event could not be found."
          // Every one of them is shown in the alert at the top of the form AND,
          // for a 400, next to the matching input.
          this.formError.set(apiError.message);
          this.submitting.set(false);
        },
      });
  }

  /**
   * Start a second registration (a different attendee, or a corrected email).
   *
   * @remarks
   * The form is cleared and the page goes back to the form state.
   */
  registerAnother(): void {
    this.firstName.set('');
    this.lastName.set('');
    this.email.set('');
    this.phone.set('');
    this.ticketsInput.set('1');
    this.notes.set('');
    this.submitAttempted.set(false);
    this.serverFieldErrors.set({});
    this.formError.set('');
    this.confirmation.set(null);
  }
}
