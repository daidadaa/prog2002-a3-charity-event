/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * the three-criteria search page.
 *
 * @file app/pages/search/search.ts
 * @file app/pages/search/search.ts
 */

import { Component, DestroyRef, OnInit, computed, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { RouterLink } from '@angular/router';
import { toApiError } from '../../core/api-error';
import { EventApiService } from '../../core/event-api.service';
import { formatEventDate } from '../../core/format';
import type { Category, CharityEvent } from '../../core/models';
import { EventCardComponent } from '../../shared/event-card/event-card';

/**
 * The Search page: a filter form that can use one, several or all criteria, and
 * the list of events the API returns for them.
 *
 * @remarks
 * Every list on this page comes from `EventApiService`: `getEventDates()` and
 * `getCategories()` fill the dropdowns when the page opens, and
 * `searchEvents(filters)` is called on submit. The four filter signals are the
 * only state the form owns.
 */
@Component({
  selector: 'app-search',
  imports: [RouterLink, EventCardComponent],
  templateUrl: './search.html',
  styleUrl: './search.css',
})
export class SearchPage implements OnInit {
  private readonly api = inject(EventApiService);
  private readonly destroyRef = inject(DestroyRef);

  /**
   * A "YYYY-MM-DD" string chosen from the dropdown built from /api/event-dates.
   *
   * @remarks
   * The four filter fields are strings because that is exactly what an `<input>`
   * and a `<select>` give us; the service converts them into query parameters.
   */
  readonly filterDate = signal('');

  /** Free text; the server matches it inside the location with LIKE. */
  readonly filterLocation = signal('');

  /** A category_id as a string; empty means "any category". */
  readonly filterCategory = signal('');

  /**
   * The extra criterion: upcoming (the server's default) | past | all.
   *
   * @remarks
   * The brief allows an optional status filter, and it is what makes it possible
   * to look at the events that have already finished.
   */
  readonly filterStatus = signal('upcoming');

  /**
   * GET /api/event-dates - an array of "YYYY-MM-DD" strings.
   *
   * @remarks
   * Loaded once, when the page opens.
   */
  readonly dates = signal<string[]>([]);

  /** GET /api/categories - used for the category dropdown below. */
  readonly categories = signal<Category[]>([]);

  /** A message if either lookup fails; the form still works without them. */
  readonly optionsError = signal('');

  /**
   * The dates paired with the label a person should read.
   *
   * @returns One `{ value, label }` pair per date, e.g.
   * `{ value: '2026-10-27', label: 'Tue 27 Oct 2026' }`.
   *
   * @remarks
   * The API sends "2026-10-27"; an `<option>` should say "Tue 27 Oct 2026". Doing
   * the pairing in a `computed()` means the conversion runs once per date instead
   * of on every change-detection pass, which is what would happen if the template
   * called a method.
   *
   * @see formatEventDate
   */
  readonly dateOptions = computed(() =>
    this.dates().map((day) => ({ value: day, label: formatEventDate(day) })),
  );

  /**
   * The search results.
   *
   * @remarks
   * `null` means "the visitor has not searched yet", which is different from an
   * empty array ("the search ran and found nothing"). Keeping those two apart is
   * what lets the page show the right message.
   */
  readonly results = signal<CharityEvent[] | null>(null);

  /** True while the search request is in flight. */
  readonly loading = signal(false);

  /** The API's error text, shown in an alert on the page. */
  readonly errorMessage = signal('');

  /**
   * Has a search been run at least once?
   *
   * @returns `true` once `results` holds an array (even an empty one).
   */
  readonly hasSearched = computed(() => this.results() !== null);

  /**
   * The heading above the result list.
   *
   * @returns "1 event matched your search." or "N events matched your search."
   */
  readonly resultsHeading = computed(() => {
    const count = this.results()?.length ?? 0;
    return count === 1 ? '1 event matched your search.' : `${count} events matched your search.`;
  });

  /**
   * A plain-English sentence naming the criteria that were used, e.g.
   * "Showing upcoming events, on Tue 27 Oct 2026, at places matching "Lismore"."
   *
   * @returns The sentence shown under the results heading.
   *
   * @remarks
   * It is built by `computed()` from the four field signals, so it is always in
   * step with the form and tells the visitor what the list below is showing.
   */
  readonly searchDescription = computed(() => {
    const parts: string[] = [];

    const status = this.filterStatus();
    if (status === 'past') {
      parts.push('events that have already happened');
    } else if (status === 'all') {
      parts.push('all events');
    } else {
      parts.push('upcoming events');
    }
    if (this.filterDate()) {
      parts.push('on ' + formatEventDate(this.filterDate()));
    }
    if (this.filterLocation().trim()) {
      parts.push('at places matching "' + this.filterLocation().trim() + '"');
    }
    const categoryId = Number(this.filterCategory());
    if (this.filterCategory()) {
      const found = this.categories().find((c) => c.category_id === categoryId);
      parts.push('in the ' + (found ? found.name : 'chosen') + ' category');
    }
    return 'Showing ' + parts.join(', ') + '.';
  });

  /**
   * Angular lifecycle hook: loads the two dropdown lists.
   *
   * @see loadFilterOptions
   */
  ngOnInit(): void {
    this.loadFilterOptions();
  }

  /**
   * Loads the two lookup lists.
   *
   * @remarks
   * They are two separate requests because they are two separate resources in
   * the API. Each one is handled on its own so that a failure of one does not
   * stop the other from filling its dropdown.
   */
  private loadFilterOptions(): void {
    this.api
      .getEventDates()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (days) => this.dates.set(days),
        error: (error: unknown) => this.optionsError.set(toApiError(error).message),
      });

    this.api
      .getCategories()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (categories) => this.categories.set(categories),
        error: (error: unknown) => this.optionsError.set(toApiError(error).message),
      });
  }

  /**
   * Reads the string value out of an `<input>` or a `<select>`.
   *
   * @param domEvent - The DOM event raised by the control.
   * @returns The control's current value, or an empty string when the event has
   * no element target.
   *
   * @remarks
   * The parameter is the DOM's built-in `Event`, which is why the project's event
   * interface is named `CharityEvent` instead of `Event`: the two would otherwise
   * collide in this file.
   */
  private valueOf(domEvent: Event): string {
    const target = domEvent.target as HTMLInputElement | HTMLSelectElement | null;
    return target === null ? '' : target.value;
  }

  /**
   * Handles a change of the date dropdown.
   *
   * @param domEvent - The `change` event of the date `<select>`.
   */
  onDateChange(domEvent: Event): void {
    this.filterDate.set(this.valueOf(domEvent));
  }

  /**
   * Handles typing in the location box.
   *
   * @param domEvent - The `input` event of the location `<input>`.
   */
  onLocationInput(domEvent: Event): void {
    this.filterLocation.set(this.valueOf(domEvent));
  }

  /**
   * Handles a change of the category dropdown.
   *
   * @param domEvent - The `change` event of the category `<select>`.
   */
  onCategoryChange(domEvent: Event): void {
    this.filterCategory.set(this.valueOf(domEvent));
  }

  /**
   * Handles a change of the status dropdown.
   *
   * @param domEvent - The `change` event of the status `<select>`.
   */
  onStatusChange(domEvent: Event): void {
    this.filterStatus.set(this.valueOf(domEvent));
  }

  /**
   * Submits the filter form.
   *
   * @param domEvent - The form's `submit` event.
   *
   * @remarks
   * `preventDefault()` stops the browser doing its own form submission (which
   * would reload the whole single-page application). Every criterion is passed
   * on; the service omits the empty ones, and the server applies only the ones
   * it receives.
   *
   * @example
   *
   * @see EventApiService.searchEvents
   */
  onSearch(domEvent: Event): void {
    domEvent.preventDefault();

    this.loading.set(true);
    this.errorMessage.set('');

    this.api
      .searchEvents({
        status: this.filterStatus(),
        date: this.filterDate(),
        location: this.filterLocation(),
        category: this.filterCategory(),
      })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (events) => {
          this.results.set(events);
          this.loading.set(false);
        },
        error: (error: unknown) => {
          // A 400 body such as `{ error: 'Please pick a valid date.' }` lands
          // here and is displayed in the alert above the form.
          this.errorMessage.set(toApiError(error).message);
          // Set the results to an empty list so the page leaves the "not searched
          // yet" state and the visitor can see that the search was rejected.
          this.results.set([]);
          this.loading.set(false);
        },
      });
  }

  /**
   * "Clear filters": every field goes back to its starting value and the result
   * list disappears, so the visitor is back to the form as they first saw it.
   */
  clearFilters(): void {
    this.filterDate.set('');
    this.filterLocation.set('');
    this.filterCategory.set('');
    this.filterStatus.set('upcoming');
    this.results.set(null);
    this.errorMessage.set('');
    this.loading.set(false);
  }
}
