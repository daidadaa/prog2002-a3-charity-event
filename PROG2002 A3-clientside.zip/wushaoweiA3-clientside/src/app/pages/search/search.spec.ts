/**
 * PROG2002 Web Development II - Assessment 3
 * WU Shao Wei
 * pages/search/search.spec.ts
 *
 * @remarks
 * The search page has four graded behaviours, so each one gets a test:
 *   1. the two <select> lists are populated from the API, not hard-coded,
 *   2. criteria can be combined,
 *   3. "Clear filters" resets every field,
 *   4. the "no matches" message and the API's own 400 text appear in the page.
 *
 * @see SearchPage - the page under test.
 */

import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import type { Category, CharityEvent } from '../../core/models';
import { SearchPage } from './search';

/** Base URL of the API the page's service is configured to call. */
const BASE = 'http://localhost:3000';

/** The search endpoint; matched with a predicate because its query string varies. */
const EVENTS_URL = `${BASE}/api/events`;

/** One event in exactly the shape the live API returns it (DECIMALs as strings). */
const EVENT: CharityEvent = {
  event_id: 5,
  name: 'Harbour Voices Concert',
  event_date: '2026-11-23 19:00:00',
  location: 'Lismore City Hall',
  latitude: '-28.81',
  longitude: '153.28',
  purpose: 'Fund music therapy.',
  description: 'An evening of local choirs.',
  ticket_price: '40.00',
  fundraising_goal: '9000.00',
  amount_raised: '1200.00',
  status: 'active',
  image_url: 'assets/images/harbour-voices-concert.jpg',
  organisation_id: 1,
  category_id: 4,
  category_name: 'Concert',
  organisation_name: 'Kind',
  organisation_mission: 'We bring neighbours together.',
  organisation_email: 'hello@kind.org',
  organisation_phone: '(02) 6600 2000',
  display_status: 'active',
};

/** The two rows GET /api/categories returns, used to prove the list is dynamic. */
const CATEGORIES: Category[] = [
  { category_id: 1, name: 'Fun Run', description: 'Community runs.' },
  { category_id: 4, name: 'Concert', description: 'Live music events.' },
];

/**
 * Covers the filter form, the query string it produces and the four result
 * states of the page.
 *
 * @see SearchPage
 */
describe('SearchPage', () => {
  let httpMock: HttpTestingController;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SearchPage],
      providers: [provideRouter([]), provideHttpClient(), provideHttpClientTesting()],
    }).compileComponents();

    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => httpMock.verify());

  /**
   * Creates the page and answers the two lookup requests it makes at start-up.
   *
   * @returns The rendered fixture, its native element and the component instance.
   */
  function render() {
    const fixture = TestBed.createComponent(SearchPage);
    fixture.detectChanges(); // ngOnInit -> two GETs
    httpMock.expectOne(`${BASE}/api/event-dates`).flush(['2026-10-27', '2026-11-23']);
    httpMock.expectOne(`${BASE}/api/categories`).flush(CATEGORIES);
    fixture.detectChanges();
    return {
      fixture,
      native: fixture.nativeElement as HTMLElement,
      component: fixture.componentInstance,
    };
  }

  /**
   * Presses the form's Search button the way a browser would.
   *
   * @param native - The rendered page element that contains the form.
   */
  function submitForm(native: HTMLElement): void {
    native.querySelector('form')!.dispatchEvent(new Event('submit'));
  }

  it('populates the date select from GET /api/event-dates', () => {
    const { native } = render();
    const select = native.querySelector('#search-date') as HTMLSelectElement;
    const labels = Array.from(select.options).map((option) => option.textContent?.trim());

    // The first option is the "no filter" choice the template adds.
    expect(labels[0]).toBe('Any date');
    expect(labels).toContain('Tue 27 Oct 2026');
    expect(labels).toContain('Mon 23 Nov 2026');
    expect(select.options.length).toBe(3);
  });

  it('populates the category select from GET /api/categories', () => {
    const { native } = render();
    const select = native.querySelector('#search-category') as HTMLSelectElement;
    const labels = Array.from(select.options).map((option) => option.textContent?.trim());

    expect(labels[0]).toBe('Any category');
    expect(labels).toContain('Fun Run');
    expect(labels).toContain('Concert');
  });

  it('sends several criteria together when they are chosen', () => {
    const { fixture, native } = render();

    const date = native.querySelector('#search-date') as HTMLSelectElement;
    date.value = '2026-10-27';
    date.dispatchEvent(new Event('change'));

    const location = native.querySelector('#search-location') as HTMLInputElement;
    location.value = 'Lismore';
    location.dispatchEvent(new Event('input'));

    const category = native.querySelector('#search-category') as HTMLSelectElement;
    category.value = '1';
    category.dispatchEvent(new Event('change'));

    submitForm(native);

    const request = httpMock.expectOne((req) => req.url === EVENTS_URL);
    expect(request.request.params.get('date')).toBe('2026-10-27');
    expect(request.request.params.get('location')).toBe('Lismore');
    expect(request.request.params.get('category')).toBe('1');
    request.flush([EVENT]);
    fixture.detectChanges();

    const text = native.textContent ?? '';
    expect(text).toContain('Harbour Voices Concert');
    expect(text).toContain('1 event matched your search.');
    expect(native.querySelector('app-event-card a[href="/event/5"]')).not.toBeNull();
  });

  it('works with a single criterion as well', () => {
    const { fixture, native } = render();

    const location = native.querySelector('#search-location') as HTMLInputElement;
    location.value = 'Lismore';
    location.dispatchEvent(new Event('input'));
    submitForm(native);

    const request = httpMock.expectOne((req) => req.url === EVENTS_URL);
    expect(request.request.params.get('location')).toBe('Lismore');
    expect(request.request.params.has('date')).toBe(false);
    expect(request.request.params.has('category')).toBe(false);
    request.flush([EVENT]);
    fixture.detectChanges();
  });

  it('shows the "no matches" message when nothing matched', () => {
    const { fixture, native } = render();

    submitForm(native);
    httpMock.expectOne((req) => req.url === EVENTS_URL).flush([]);
    // The empty array landed in the `results` signal; render it before asserting.
    fixture.detectChanges();

    expect(native.querySelector('.empty-state')).not.toBeNull();
    expect(native.textContent).toContain('No events match those filters');
    expect(native.querySelectorAll('app-event-card').length).toBe(0);
  });

  it('shows the API 400 error text in the page', () => {
    const { fixture, native } = render();

    submitForm(native);
    httpMock
      .expectOne((req) => req.url === EVENTS_URL)
      .flush({ error: 'Please pick a valid date.' }, { status: 400, statusText: 'Bad Request' });
    fixture.detectChanges();

    const alert = native.querySelector('.alert-error');
    expect(alert).not.toBeNull();
    expect(alert?.textContent).toContain('Please pick a valid date.');
  });

  it('resets every field and the results when "Clear filters" is pressed', () => {
    const { fixture, native, component } = render();

    // Fill everything in and run a search.
    const date = native.querySelector('#search-date') as HTMLSelectElement;
    date.value = '2026-10-27';
    date.dispatchEvent(new Event('change'));
    const location = native.querySelector('#search-location') as HTMLInputElement;
    location.value = 'Lismore';
    location.dispatchEvent(new Event('input'));
    const category = native.querySelector('#search-category') as HTMLSelectElement;
    category.value = '1';
    category.dispatchEvent(new Event('change'));
    const status = native.querySelector('#search-status') as HTMLSelectElement;
    status.value = 'past';
    status.dispatchEvent(new Event('change'));

    submitForm(native);
    httpMock.expectOne((req) => req.url === EVENTS_URL).flush([EVENT]);
    fixture.detectChanges();

    expect(component.filterDate()).toBe('2026-10-27');
    expect(component.results()).toEqual([EVENT]);
    expect(native.textContent).toContain('Harbour Voices Concert');

    // Press "Clear filters" (the secondary button inside the search form).
    const clear = native.querySelector('.search-form .button-secondary') as HTMLButtonElement;
    expect(clear.textContent).toContain('Clear filters');
    clear.click();
    // One change-detection pass writes the reset values back into the DOM. No
    // further HTTP request is made: clearing is entirely local state.
    fixture.detectChanges();

    expect(component.filterDate()).toBe('');
    expect(component.filterLocation()).toBe('');
    expect(component.filterCategory()).toBe('');
    expect(component.filterStatus()).toBe('upcoming');

    // The controls themselves are empty again, which is the visible proof.
    expect(date.value).toBe('');
    expect(location.value).toBe('');
    expect(category.value).toBe('');
    expect(status.value).toBe('upcoming');

    // Back to the "not searched yet" state, so the result panel disappears.
    expect(component.results()).toBeNull();
    expect(native.textContent).toContain('Tell us what you are looking for');
    expect(native.querySelectorAll('app-event-card').length).toBe(0);
  });
});
