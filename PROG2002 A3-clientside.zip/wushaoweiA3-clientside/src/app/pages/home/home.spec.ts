/**
 * PROG2002 Web Development II - Assessment 3
 * WU Shao Wei
 * pages/home/home.spec.ts
 *
 * @remarks
 * Renders the real component template against a mocked API, which proves three
 * things the build alone cannot:
 *   1. the event list really comes from GET /api/events/home (not from markup),
 *   2. `image_url` is bound into the <img src> exactly as it arrives, and
 *   3. an API failure is shown ON THE PAGE, not only in the console.
 *
 * @see HomePage - the page under test.
 * @see EventApiService - the service the page calls.
 */

import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import type { CharityEvent } from '../../core/models';
import { HomePage } from './home';

/** One event in exactly the shape the live API returns it (DECIMALs as strings). */
const EVENT: CharityEvent = {
  event_id: 1,
  name: 'Coastal Sunrise Fun Run',
  event_date: '2026-10-27 06:30:00',
  location: 'Lismore Riverside Park',
  latitude: '-28.813500',
  longitude: '153.277300',
  purpose: 'Fund youth mental health outreach.',
  description: 'Choose a 5 km or 10 km riverside course.',
  ticket_price: '25.00',
  fundraising_goal: '18000.00',
  amount_raised: '7450.00',
  status: 'active',
  image_url: 'assets/images/coastal-sunrise-fun-run.jpg',
  organisation_id: 1,
  category_id: 1,
  category_name: 'Fun Run',
  organisation_name: 'Kind',
  organisation_mission: 'We bring neighbours together.',
  organisation_email: 'hello@kind.org',
  organisation_phone: '(02) 6600 2000',
  display_status: 'active',
};

/** The one endpoint the home page calls. */
const HOME_URL = 'http://localhost:3000/api/events/home';

/**
 * Covers the home page's data flow, from the HTTP call to the rendered DOM.
 *
 * @see HomePage
 */
describe('HomePage', () => {
  let httpMock: HttpTestingController;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HomePage],
      providers: [provideRouter([]), provideHttpClient(), provideHttpClientTesting()],
    }).compileComponents();

    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => httpMock.verify());

  /**
   * Creates the page and answers the home request with the given response.
   *
   * @param flush - Called once the pending request has been matched; it flushes
   * whichever response the test wants (a list, an empty array, or an error).
   * @returns The rendered fixture and its native element.
   *
   * @remarks
   * The first `detectChanges()` runs `ngOnInit`, which fires the HTTP GET; the
   * second pass, after `flush`, renders the signal writes.
   */
  function render(flush: () => void) {
    const fixture = TestBed.createComponent(HomePage);
    fixture.detectChanges(); // runs ngOnInit -> the HTTP GET
    flush();
    fixture.detectChanges(); // signal writes have landed; render them
    return { fixture, native: fixture.nativeElement as HTMLElement };
  }

  /**
   * Renders the page with a successful home response.
   *
   * @param events - The events the API should return; defaults to the single
   * sample event.
   * @returns The rendered fixture and its native element.
   */
  function renderWithEvents(events: CharityEvent[] = [EVENT]) {
    return render(() => httpMock.expectOne(HOME_URL).flush(events));
  }

  it('asks the API for the home events', () => {
    const fixture = TestBed.createComponent(HomePage);
    fixture.detectChanges();

    const request = httpMock.expectOne(HOME_URL);
    expect(request.request.method).toBe('GET');
    request.flush([EVENT]);
  });

  it('renders the dynamic event list with name, category, date, place and price', () => {
    const { native } = renderWithEvents();
    const text = native.textContent ?? '';

    expect(text).toContain('Coastal Sunrise Fun Run');
    expect(text).toContain('Fun Run'); // the category badge
    expect(text).toContain('Tue 27 Oct 2026');
    expect(text).toContain('6:30 am');
    expect(text).toContain('Lismore Riverside Park');
    expect(text).toContain('$25.00');

    // One card component per event.
    expect(native.querySelectorAll('app-event-card').length).toBe(1);
    // ... and it links to the detail page for that event.
    expect(native.querySelector('app-event-card a[href="/event/1"]')).not.toBeNull();
  });

  it('binds the API image_url straight into the img src', () => {
    const { native } = renderWithEvents();
    const image = native.querySelector('.event-card-image') as HTMLImageElement;

    expect(image).not.toBeNull();
    expect(image.getAttribute('src')).toBe('assets/images/coastal-sunrise-fun-run.jpg');
  });

  it('renders one card per event and keeps a stable track key', () => {
    const second: CharityEvent = {
      ...EVENT,
      event_id: 2,
      name: 'Light the Way Gala',
      image_url: 'assets/images/light-the-way-gala.jpg',
    };
    const { native } = renderWithEvents([EVENT, second]);

    expect(native.querySelectorAll('app-event-card').length).toBe(2);
    expect(native.textContent).toContain('Light the Way Gala');
  });

  it('shows the API error message in the page when the request fails', () => {
    const { native } = render(() =>
      httpMock
        .expectOne(HOME_URL)
        .flush({ error: 'Something went wrong on the server.' }, { status: 500, statusText: 'Server Error' }),
    );

    const alert = native.querySelector('.alert-error');
    expect(alert).not.toBeNull();
    expect(alert?.textContent).toContain('Something went wrong on the server.');
    // ... and there is a way to try again.
    expect(alert?.querySelector('button')).not.toBeNull();
  });

  it('shows a friendly empty state when the API returns no events', () => {
    const { native } = renderWithEvents([]);

    expect(native.querySelector('.empty-state')).not.toBeNull();
    expect(native.textContent).toContain('No events are scheduled just yet');
    expect(native.querySelectorAll('app-event-card').length).toBe(0);
  });

  it('shows the loading message before the API answers', () => {
    const fixture = TestBed.createComponent(HomePage);
    fixture.detectChanges();

    expect((fixture.nativeElement as HTMLElement).textContent).toContain('Loading the latest events');
    httpMock.expectOne(HOME_URL).flush([]);
  });
});
