/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * the client website's front door.
 *
 * @file app/pages/home/home.ts
 * @file app/pages/home/home.ts
 */

import { Component, DestroyRef, OnInit, computed, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { RouterLink } from '@angular/router';
import { toApiError } from '../../core/api-error';
import { EventApiService } from '../../core/event-api.service';
import type { CharityEvent } from '../../core/models';
import { EventCardComponent } from '../../shared/event-card/event-card';

/**
 * The Home page: the charity's front door and the dynamic list of what is on.
 *
 * @remarks
 * Every dynamic value on the page comes from `EventApiService.getHomeEvents()`,
 * which is called once from `ngOnInit` and stored in the `events` signal. The
 * static content (mission wording, contact fallbacks) is read from the first
 * event row through the `organisation` computed signal.
 */
@Component({
  selector: 'app-home',
  imports: [RouterLink, EventCardComponent],
  templateUrl: './home.html',
  styleUrl: './home.css',
})
export class HomePage implements OnInit {
  private readonly api = inject(EventApiService);

  /**
   * `DestroyRef` lets `takeUntilDestroyed` cancel an in-flight request when the
   * visitor leaves the page before the API answers. Without it, the subscribe
   * callback could still run against a destroyed component.
   */
  private readonly destroyRef = inject(DestroyRef);

  /**
   * The events returned by GET /api/events/home. Empty until the call answers.
   *
   * @remarks
   * `readonly` only stops the signal object being replaced; its value is changed
   * with `.set()`, which is what notifies the template.
   */
  readonly events = signal<CharityEvent[]>([]);

  /** True while the request is in flight, so the page can show a loading line. */
  readonly loading = signal(true);

  /** A message for the visitor when the request fails (never just a console log). */
  readonly errorMessage = signal('');

  /**
   * The organisation's details, taken from the event rows the API returned.
   *
   * @remarks
   * The API joins the organisations table, so every event row carries the name,
   * mission, email and phone. Taking them from the API rather than repeating them
   * in the template means the page shows what the database actually holds, and it
   * falls back to the known values while the request is still running.
   */
  readonly organisation = computed(() => {
    const first = this.events()[0];
    return {
      name: first?.organisation_name ?? 'Kind',
      mission:
        first?.organisation_mission ??
        'We bring neighbours together to fund practical support and brighter futures.',
      email: first?.organisation_email ?? 'hello@kind.org',
      phone: first?.organisation_phone ?? '(02) 6600 2000',
    };
  });

  /**
   * The heading line above the event grid.
   *
   * @returns "1 upcoming event" for a single row, otherwise "N upcoming events".
   */
  readonly eventsHeading = computed(() => {
    const count = this.events().length;
    return count === 1 ? '1 upcoming event' : `${count} upcoming events`;
  });

  /**
   * Angular lifecycle hook: starts the one request the page needs.
   *
   * @see loadEvents
   */
  ngOnInit(): void {
    this.loadEvents();
  }

  /**
   * Loads (or reloads) the home list.
   *
   * @remarks
   * The three callbacks of `subscribe` are the whole error-handling story:
   *  - next:  put the array into the signal;
   *  - error: turn the failure into a sentence with `toApiError` and show it;
   *  - and `finalize`-style cleanup is done in both branches by clearing the
   *    loading flag, so the spinner never gets stuck.
   *
   * @see toApiError
   */
  private loadEvents(): void {
    this.loading.set(true);
    this.errorMessage.set('');

    this.api
      .getHomeEvents()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (events) => {
          this.events.set(events);
          this.loading.set(false);
        },
        error: (error: unknown) => {
          // The API's own `error` text ("The event service could not be
          // reached...", "Something went wrong on the server.") ends up on the
          // page, which the brief requires.
          this.errorMessage.set(toApiError(error).message);
          this.loading.set(false);
        },
      });
  }

  /** The "Try again" button of the error state. */
  retry(): void {
    this.loadEvents();
  }
}
