/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * one event in full.
 *
 * @file app/pages/event-detail/event-detail.ts
 * @file app/pages/event-detail/event-detail.ts
 */

import { Component, DestroyRef, OnInit, computed, inject, signal } from '@angular/core';
import { TitleCasePipe } from '@angular/common';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { isNotFound, toApiError } from '../../core/api-error';
import { EventApiService } from '../../core/event-api.service';
import {
  formatEventDateTime,
  formatMoney,
  formatRegistrationDate,
  formatShortDate,
  formatTemperature,
  toNumber,
} from '../../core/format';
import type {
  CharityEvent,
  Registration,
  RegistrationSummary,
  WeatherForecast,
} from '../../core/models';

/** The three states the weather block can be in. */
type WeatherState = 'loading' | 'ready' | 'unavailable';

/**
 * The event detail page: one event with its fundraising progress, its
 * registration list and the weather forecast for the day.
 *
 * @remarks
 * The event, its registrations and the totals all arrive together from
 * `EventApiService.getEvent(id)`; the forecast arrives separately from
 * `EventApiService.getWeather(id)`. The `id` itself comes from the activated
 * route, `/event/:id`.
 */
@Component({
  selector: 'app-event-detail',
  // TitleCasePipe turns the API's lowercase "active"/"past" into a readable
  // "Active"/"Past" badge, matching the admin website's status labels.
  imports: [RouterLink, TitleCasePipe],
  templateUrl: './event-detail.html',
  styleUrl: './event-detail.css',
})
export class EventDetailPage implements OnInit {
  private readonly api = inject(EventApiService);
  private readonly route = inject(ActivatedRoute);
  private readonly destroyRef = inject(DestroyRef);

  /**
   * The route parameter. `ActivatedRoute` is injected rather than using the
   * router's input binding, because a plain snapshot read is enough here: the
   * component is re-created for each "/event/:id" navigation.
   */
  private readonly eventId = this.route.snapshot.paramMap.get('id') ?? '';

  /** The event, or null until the API answers. */
  readonly event = signal<CharityEvent | null>(null);

  /**
   * The registrations, in the order the API returned them: newest first.
   * (See the note at the top of this file - the page does not re-sort.)
   */
  readonly registrations = signal<Registration[]>([]);

  /** The totals shown above the list. `null` until the request answers. */
  readonly summary = signal<RegistrationSummary | null>(null);

  /** True while GET /api/events/:id is in flight. */
  readonly loading = signal(true);

  /** A general failure message (500, or the API not running at all). */
  readonly errorMessage = signal('');

  /** True for a 404/400: the event is missing or suspended. */
  readonly notFound = signal(false);

  /**
   * The forecast, or null until /api/weather/:id answers.
   *
   * @remarks
   * The weather state is kept completely separate from the event state on
   * purpose, so that a failing forecast cannot affect the event itself.
   */
  readonly weather = signal<WeatherForecast | null>(null);

  /** Which of the three weather states is on screen. */
  readonly weatherState = signal<WeatherState>('loading');

  /** The reason the forecast is unavailable, shown as a small note. */
  readonly weatherNote = signal('');

  /**
   * The API's `image_url` used exactly as it arrives.
   *
   * @remarks
   * The derived display values below all use `computed()`, which caches and only
   * recalculates when one of the signals it reads changes, so they are cheap to
   * use in the template.
   */
  readonly imageUrl = computed(() => this.event()?.image_url ?? '');

  /** "Tue 27 Oct 2026, 6:30 am" - formatted by slicing, not by `new Date(text)`. */
  readonly when = computed(() => formatEventDateTime(this.event()?.event_date));

  /** "$25.00" - `ticket_price` arrives from MySQL as the string "25.00". */
  readonly price = computed(() => formatMoney(this.event()?.ticket_price));

  /** True when the event has already happened, so registration is closed. */
  readonly isPast = computed(() => this.event()?.display_status === 'past');

  /**
   * How much has been raised, as a real number.
   *
   * @remarks
   * `toNumber` is essential here: "7450.00" would otherwise break the maths.
   */
  readonly raised = computed(() => toNumber(this.event()?.amount_raised));

  /** The fundraising target, as a real number, for the same reason. */
  readonly goal = computed(() => toNumber(this.event()?.fundraising_goal));

  /** "Raised so far", e.g. "$7,450.00". */
  readonly raisedLabel = computed(() => formatMoney(this.raised()));

  /** The goal, e.g. "$18,000.00". */
  readonly goalLabel = computed(() => formatMoney(this.goal()));

  /**
   * The percentage of the goal that has been raised.
   *
   * @returns The real percentage, rounded to a whole number, or 0 when no goal
   * has been set. It may be more than 100 for an over-achieving event.
   */
  readonly percentComplete = computed(() => {
    const goal = this.goal();
    if (goal <= 0) {
      return 0;
    }
    return Math.round((this.raised() / goal) * 100);
  });

  /**
   * The width of the progress bar.
   *
   * @returns The percentage clamped to 0-100 so the CSS bar can never overflow.
   */
  readonly barWidth = computed(() => Math.min(100, Math.max(0, this.percentComplete())));

  /** How much is left to raise, never less than $0.00. */
  readonly remainingLabel = computed(() => formatMoney(Math.max(0, this.goal() - this.raised())));

  /**
   * The sentence under the progress bar, e.g. "41% of the way there. $10,550.00
   * still to raise."
   *
   * @returns A sentence that changes with the progress, or an explanation when no
   * goal has been set.
   */
  readonly progressNote = computed(() => {
    const kept = this.percentComplete();
    if (this.goal() <= 0) {
      return 'No fundraising goal has been set for this event.';
    }
    if (kept >= 100) {
      return 'Goal reached - thank you! Every extra dollar still supports the cause.';
    }
    return `${kept}% of the way there. ${this.remainingLabel()} still to raise.`;
  });

  /**
   * The `aria-valuenow` of the progress bar.
   *
   * @returns The same clamped value as `barWidth`, so it is a valid 0-100.
   */
  readonly barValue = computed(() => this.barWidth());

  /** How many registrations the event has. */
  readonly registrationCount = computed(() => this.summary()?.registration_count ?? 0);

  /** Total tickets sold; `toNumber` handles the SQL SUM() arriving as a string. */
  readonly ticketsSold = computed(() => toNumber(this.summary()?.tickets_sold));

  /** Total money registered, e.g. "$1,250.00". */
  readonly amountRegistered = computed(() => formatMoney(this.summary()?.amount_registered ?? 0));

  /** The newest registration's date, e.g. "12 Oct 2026, 6:22 pm". */
  readonly latestRegistration = computed(() =>
    formatRegistrationDate(this.summary()?.latest_registration ?? null),
  );

  /**
   * Has anything been registered yet?
   *
   * @returns `true` when the list is not empty; drives the empty state.
   */
  readonly hasRegistrations = computed(() => this.registrations().length > 0);

  /**
   * The credits line for the forecast.
   *
   * @returns The source the API reported, e.g. "Open-Meteo".
   */
  readonly weatherSource = computed(() => this.weather()?.source ?? 'Open-Meteo');

  /**
   * Which of the page's four states is on screen.
   *
   * @returns `'loading'`, `'notFound'`, `'error'` or `'ready'`.
   *
   * @remarks
   * Turning the separate loading / notFound / errorMessage signals into one name
   * lets the template use a single `@switch` instead of a chain of `@if` blocks,
   * which makes the four states obvious at a glance.
   */
  readonly stateName = computed<'loading' | 'notFound' | 'error' | 'ready'>(() => {
    if (this.loading()) {
      return 'loading';
    }
    if (this.notFound()) {
      return 'notFound';
    }
    if (this.errorMessage()) {
      return 'error';
    }
    return 'ready';
  });

  /**
   * Angular lifecycle hook: decides which requests to make.
   *
   * @remarks
   * An id that is not a positive whole number could never match a row, so the
   * page goes straight to the friendly "not found" state without a request.
   *
   * @see loadEvent
   * @see loadWeather
   */
  ngOnInit(): void {
    if (/^[0-9]+$/.test(this.eventId) === false) {
      this.notFound.set(true);
      this.loading.set(false);
      this.weatherState.set('unavailable');
      return;
    }

    this.loadEvent();
    this.loadWeather();
  }

  /**
   * GET /api/events/:id - the event, its registrations and the summary.
   *
   * @remarks
   * The three parts of the response are written to the three signals; the
   * registrations are stored exactly as received, because the server already
   * sorted them newest first and the brief wants that order kept.
   */
  private loadEvent(): void {
    this.loading.set(true);
    this.errorMessage.set('');
    this.notFound.set(false);

    this.api
      .getEvent(this.eventId)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (response) => {
          this.event.set(response.event);
          // Stored exactly as received: the server already sorted them newest
          // first, and the brief wants that order kept.
          this.registrations.set(response.registrations);
          this.summary.set(response.summary);
          this.loading.set(false);
        },
        error: (error: unknown) => {
          const apiError = toApiError(error);
          if (isNotFound(apiError)) {
            // 404 for a missing or suspended event; 400 for a non-numeric id.
            // Both mean "there is nothing here to show".
            this.notFound.set(true);
          } else {
            this.errorMessage.set(apiError.message);
          }
          this.loading.set(false);
        },
      });
  }

  /**
   * GET /api/weather/:id - the 5-day Open-Meteo forecast.
   *
   * @remarks
   * Every failure is swallowed on purpose. The weather is a nice-to-have: when
   * Open-Meteo cannot be reached (502) or the event has no coordinates (422),
   * the visitor gets one short note and the event, progress, registrations and
   * register button carry on working.
   */
  private loadWeather(): void {
    this.weatherState.set('loading');

    this.api
      .getWeather(this.eventId)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (forecast) => {
          this.weather.set(forecast);
          this.weatherState.set('ready');
        },
        error: (error: unknown) => {
          this.weatherNote.set(toApiError(error).message);
          this.weatherState.set('unavailable');
        },
      });
  }

  /** The "try again" button of the general error state. */
  retry(): void {
    this.loadEvent();
    this.loadWeather();
  }

  /**
   * Format one forecast temperature for the template.
   *
   * @param value - The temperature in degrees Celsius, or null.
   * @returns A string such as "20.3°C", or an en dash when there is no value.
   *
   * @see formatTemperature
   */
  temperature(value: number | null): string {
    return formatTemperature(value);
  }

  /**
   * Label one day of the forecast.
   *
   * @param date - The forecast day, "YYYY-MM-DD".
   * @returns A string such as "Wed 14 Oct".
   *
   * @remarks
   * Weather dates carry no time, so they get the short weekday label.
   *
   * @see formatShortDate
   */
  weatherDayLabel(date: string): string {
    return formatShortDate(date);
  }

  /**
   * Show when a registration's tickets were bought.
   *
   * @param date - The registration's `registration_date`.
   * @returns A string such as "12 Oct 2026, 6:22 pm".
   *
   * @see formatRegistrationDate
   */
  registrationRegistered(date: string): string {
    return formatRegistrationDate(date);
  }

  /**
   * Show one registration's total.
   *
   * @param registration - The registration row from the API.
   * @returns The total as money, e.g. "$75.00".
   *
   * @remarks
   * `total_amount` is another DECIMAL that arrives as a string.
   */
  registrationTotal(registration: Registration): string {
    return formatMoney(registration.total_amount);
  }
}
