/**
 * PROG2002 Web Development II - Assessment 3
 * WU Shao Wei
 * pages/event-detail/event-detail.spec.ts
 *
 * @remarks
 * The two requests the page makes are mocked separately, which is exactly the
 * point: the weather call can fail while the event call succeeds, and the test
 * proves the page keeps working in that case.
 *
 * @see EventDetailPage - the page under test.
 */

import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { ActivatedRoute, convertToParamMap, provideRouter } from '@angular/router';
import type { CharityEvent, Registration, WeatherForecast } from '../../core/models';
import { EventDetailPage } from './event-detail';

/** Base URL of the API the page's service is configured to call. */
const BASE = 'http://localhost:3000';

/** One event in exactly the shape the live API returns it (DECIMALs as strings). */
const EVENT: CharityEvent = {
  event_id: 1,
  name: 'Coastal Sunrise Fun Run',
  event_date: '2026-10-27 06:30:00',
  location: 'Lismore Riverside Park',
  latitude: '-28.813500',
  longitude: '153.277300',
  purpose: 'Fund youth mental health outreach.',
  description: 'Choose a 5 km or 10 km riverside course.',
  ticket_price: '25.00',
  fundraising_goal: '18000.00',
  amount_raised: '7450.00',
  status: 'active',
  image_url: 'assets/images/coastal-sunrise-fun-run.jpg',
  organisation_id: 1,
  category_id: 1,
  category_name: 'Fun Run',
  organisation_name: 'Kind',
  organisation_mission: 'We bring neighbours together.',
  organisation_email: 'hello@kind.org',
  organisation_phone: '(02) 6600 2000',
  display_status: 'active',
};

/** Newest first, which is the order the API documents and the SQL produces. */
const REGISTRATIONS: Registration[] = [
  {
    registration_id: 5,
    first_name: 'Emma',
    last_name: 'Rossi',
    email: 'e***i@example.com',
    phone: 'hidden',
    tickets: 3,
    registration_date: '2026-10-12 18:22:40',
    total_amount: '75.00',
    notes: 'Work team.',
  },
  {
    registration_id: 1,
    first_name: 'Amelia',
    last_name: 'Nguyen',
    email: 'a***n@example.com',
    phone: 'hidden',
    tickets: 2,
    registration_date: '2026-09-23 18:22:40',
    total_amount: '50.00',
    notes: null,
  },
];

/** The three-part 200 body of GET /api/events/:id. */
const DETAIL = {
  event: EVENT,
  registrations: REGISTRATIONS,
  summary: {
    registration_count: 5,
    tickets_sold: '11',
    amount_registered: '275.00',
    latest_registration: '2026-10-12 18:22:40',
  },
};

/** The 200 body of GET /api/weather/:id - two days are enough for the assertions. */
const WEATHER: WeatherForecast = {
  event_id: 1,
  event_name: 'Coastal Sunrise Fun Run',
  location: 'Lismore Riverside Park',
  latitude: -28.8135,
  longitude: 153.2773,
  timezone: 'Australia/Sydney',
  source: 'Open-Meteo (api.open-meteo.com)',
  days: [
    {
      date: '2026-10-14',
      weather_code: 80,
      description: 'Rain showers: slight',
      good_weather: false,
      temperature_max: 20.3,
      temperature_min: 12.1,
      rain_chance: 55,
    },
    {
      date: '2026-10-15',
      weather_code: 0,
      description: 'Clear sky',
      good_weather: true,
      temperature_max: 22,
      temperature_min: 11,
      rain_chance: 5,
    },
  ],
};

/**
 * Covers the event itself, its progress bar, its registration list and the
 * independent weather panel - including the states where the weather fails.
 *
 * @see EventDetailPage
 */
describe('EventDetailPage', () => {
  let httpMock: HttpTestingController;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EventDetailPage],
      providers: [
        provideRouter([]),
        provideHttpClient(),
        provideHttpClientTesting(),
        {
          provide: ActivatedRoute,
          useValue: { snapshot: { paramMap: convertToParamMap({ id: '1' }) } },
        },
      ],
    }).compileComponents();

    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => httpMock.verify());

  /**
   * Renders the page and answers both requests with the supplied responses.
   *
   * @param options - Optional overrides. `options.detail` replaces the event
   * response (e.g. with a 404) and `options.weather` replaces the forecast
   * response (e.g. with a 502); whichever is omitted is answered with the
   * standard 200 fixture.
   * @returns The rendered fixture, its native element and the component instance.
   *
   * @remarks
   * Both requests are fired from `ngOnInit`, so the first `detectChanges()`
   * issues them; the responder functions flush them in whichever order the test
   * needs, and the final pass renders the signal writes.
   */
  function render(options: {
    detail?: () => void;
    weather?: () => void;
  } = {}) {
    const fixture = TestBed.createComponent(EventDetailPage);
    fixture.detectChanges(); // ngOnInit -> GET /api/events/1 and GET /api/weather/1

    if (options.detail) {
      options.detail();
    } else {
      httpMock.expectOne(`${BASE}/api/events/1`).flush(DETAIL);
    }
    if (options.weather) {
      options.weather();
    } else {
      httpMock.expectOne(`${BASE}/api/weather/1`).flush(WEATHER);
    }

    fixture.detectChanges();
    return { fixture, native: fixture.nativeElement as HTMLElement, component: fixture.componentInstance };
  }

  it('reads the id from the route and fetches that event', () => {
    const fixture = TestBed.createComponent(EventDetailPage);
    fixture.detectChanges();

    httpMock.expectOne(`${BASE}/api/events/1`).flush(DETAIL);
    httpMock.expectOne(`${BASE}/api/weather/1`).flush(WEATHER);

    expect(fixture.componentInstance.event()?.event_id).toBe(1);
  });

  it('shows the full event details', () => {
    const { native } = render();
    const text = native.textContent ?? '';

    expect(text).toContain('Coastal Sunrise Fun Run');
    expect(text).toContain('Tue 27 Oct 2026, 6:30 am');
    expect(text).toContain('Lismore Riverside Park');
    expect(text).toContain('Fund youth mental health outreach.');
    expect(text).toContain('Choose a 5 km or 10 km riverside course.');
    expect(text).toContain('$25.00'); // the ticket price
    expect(text).toContain('Fun Run'); // the category
    expect(text).toContain('Kind'); // the organisation
  });

  it('binds the API image_url straight into the img src', () => {
    const { native } = render();
    const image = native.querySelector('.detail-image') as HTMLImageElement;
    expect(image.getAttribute('src')).toBe('assets/images/coastal-sunrise-fun-run.jpg');
  });

  it('shows amount_raised against fundraising_goal with a percentage progress bar', () => {
    const { native, component } = render();

    // 7450 / 18000 = 41.4% -> 41%
    expect(component.percentComplete()).toBe(41);
    expect(component.barWidth()).toBe(41);

    const text = native.textContent ?? '';
    expect(text).toContain('$7,450.00');
    expect(text).toContain('$18,000.00');
    expect(text).toContain('41%');

    const bar = native.querySelector('.progress-bar span') as HTMLElement;
    expect(bar.style.width).toBe('41%');
  });

  it('caps the bar at 100% when an event has beaten its goal', () => {
    const { component } = render({
      detail: () =>
        httpMock
          .expectOne(`${BASE}/api/events/1`)
          .flush({ ...DETAIL, event: { ...EVENT, amount_raised: '25000.00' } }),
    });

    expect(component.percentComplete()).toBe(139);
    expect(component.barWidth()).toBe(100);
  });

  it('lists the registrations newest first, exactly as the API returned them', () => {
    const { native } = render();

    const rows = Array.from(native.querySelectorAll('.data-table tbody tr'));
    expect(rows.length).toBe(2);
    // The API sorted them, and the page must not reorder them.
    expect(rows[0].textContent).toContain('Emma Rossi');
    expect(rows[1].textContent).toContain('Amelia Nguyen');
    // Attendee, tickets and the registration date are all visible.
    expect(rows[0].textContent).toContain('12 Oct 2026, 6:22 pm');
    expect(rows[0].textContent).toContain('3');
    expect(rows[0].textContent).toContain('$75.00');
    // The masked email the public endpoint sends is shown as it arrived.
    expect(rows[0].textContent).toContain('e***i@example.com');
  });

  it('shows the summary totals', () => {
    const { native } = render();
    const text = native.textContent ?? '';

    expect(text).toContain('Registrations');
    expect(text).toContain('5'); // registration_count
    expect(text).toContain('Tickets sold');
    expect(text).toContain('11'); // tickets_sold, which arrives as a string
    expect(text).toContain('Amount registered');
    expect(text).toContain('$275.00');
  });

  it('offers a Register button that navigates to /register/:id', () => {
    const { native } = render();
    const link = native.querySelector('a[href="/register/1"]');
    expect(link).not.toBeNull();
    expect(link?.textContent).toContain('Register for this event');
  });

  it('shows the 5-day forecast and credits Open-Meteo', () => {
    const { native } = render();
    const text = native.textContent ?? '';

    expect(native.querySelectorAll('.weather-day').length).toBe(2);
    expect(text).toContain('Wed 14 Oct');
    expect(text).toContain('Rain showers: slight');
    expect(text).toContain('20.3°C');
    expect(text).toContain('12.1°C');
    expect(text).toContain('55% rain');
    // The source label the brief asks for.
    expect(text).toContain('Open-Meteo');
  });

  it('keeps the rest of the page working when the weather call fails (502)', () => {
    const { native } = render({
      weather: () =>
        httpMock
          .expectOne(`${BASE}/api/weather/1`)
          .flush({ error: 'The weather service could not be reached.' }, { status: 502, statusText: 'Bad Gateway' }),
    });
    const text = native.textContent ?? '';

    // The short note is there...
    expect(text).toContain('Weather is unavailable for this event right now.');
    expect(native.querySelectorAll('.weather-day').length).toBe(0);
    // ... and so is everything else, including the register link.
    expect(text).toContain('Coastal Sunrise Fun Run');
    expect(text).toContain('$7,450.00');
    expect(native.querySelector('a[href="/register/1"]')).not.toBeNull();
    // The event itself did NOT become an error page.
    expect(native.querySelector('.detail-body .alert-error')).toBeNull();
  });

  it('keeps the page working when the event has no coordinates (422)', () => {
    const { native } = render({
      weather: () =>
        httpMock
          .expectOne(`${BASE}/api/weather/1`)
          .flush({ error: 'This event has no coordinates yet.' }, { status: 422, statusText: 'Unprocessable' }),
    });

    expect(native.textContent).toContain('Weather is unavailable for this event right now.');
    expect(native.textContent).toContain('Coastal Sunrise Fun Run');
  });

  it('shows a friendly "not found" state for a 404 and no error alert', () => {
    const { native } = render({
      detail: () =>
        httpMock
          .expectOne(`${BASE}/api/events/1`)
          .flush({ error: 'This event could not be found.' }, { status: 404, statusText: 'Not Found' }),
    });
    const text = native.textContent ?? '';

    expect(text).toContain('This event could not be found');
    expect(native.querySelector('.empty-state')).not.toBeNull();
    // A missing event is not a failure: no red alert is shown.
    expect(native.querySelector('.alert-error')).toBeNull();
  });

  it('shows the API message for a real server failure', () => {
    const { native } = render({
      detail: () =>
        httpMock
          .expectOne(`${BASE}/api/events/1`)
          .flush({ error: 'Something went wrong on the server.' }, { status: 500, statusText: 'Server Error' }),
    });

    const alert = native.querySelector('.alert-error');
    expect(alert).not.toBeNull();
    expect(alert?.textContent).toContain('Something went wrong on the server.');
  });
});
