/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * the root component: the shell that every page is drawn inside.
 *
 * @file app/app.ts
 * @file app/app.ts
 */

import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { SiteFooterComponent } from './shared/layout/site-footer/site-footer';
import { SiteHeaderComponent } from './shared/layout/site-header/site-header';
import { SiteNavComponent } from './shared/layout/site-nav/site-nav';

/**
 * The root component: the Header / Nav / Body / Footer shell of the whole site.
 *
 * @remarks
 * The class is intentionally empty. Everything it renders comes from the four
 * segment components and the router, and it holds no state that could get out of
 * step with them.
 *
 * @example
 */
@Component({
  selector: 'app-root',
  imports: [RouterOutlet, SiteHeaderComponent, SiteNavComponent, SiteFooterComponent],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {}
