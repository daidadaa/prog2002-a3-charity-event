/**
 * PROG2002 Web Development II - Assessment 3 (WU Shao Wei).
 *
 * @module event_model
 * @description
 * All of the SQL for the charity events API, wrapped in one function per
 * operation. The route modules never write SQL themselves; they call a function
 * here and get plain objects back.
 *
 * @remarks
 * Every statement uses `?` placeholders, so nothing that comes from the browser
 * is ever written into the SQL text itself.
 *
 * The exported functions fall into five groups, which the section comments of
 * the original file used to mark out:
 *
 * - **Client-side reads** - {@link module:event_model~getHomeEvents},
 *   {@link module:event_model~searchEvents}, {@link module:event_model~getEventDates},
 *   {@link module:event_model~getCategories}, {@link module:event_model~getEventById},
 *   {@link module:event_model~getRegistrationsForEvent},
 *   {@link module:event_model~getRegistrationSummary}.
 * - **Admin-side reads (any status)** - {@link module:event_model~getAllEventsForAdmin},
 *   {@link module:event_model~getAdminEventById}, {@link module:event_model~eventExists}.
 * - **Admin-side event writes** - {@link module:event_model~createEvent},
 *   {@link module:event_model~updateEvent}, {@link module:event_model~countRegistrations},
 *   {@link module:event_model~deleteEventSafely}.
 * - **Public registration writes** - {@link module:event_model~getEventForRegistration},
 *   {@link module:event_model~findRegistration},
 *   {@link module:event_model~createRegistration}.
 * - **Weather proxy support** - {@link module:event_model~getEventCoordinates}.
 *
 * The SQL is hand-built rather than generated, so the column list and the joins
 * are declared once as {@link module:event_model~EVENT_COLUMNS} and
 * {@link module:event_model~EVENT_JOINS} and reused by every event query.
 *
 * @see module:event_db - the connection pool these queries run on
 * @see module:validation - the input checks that run before the writes
 * @see module:routes/events - the client-side and admin event endpoints
 */

const dbcon = require('./event_db');
const pool = dbcon.pool;

/**
 * A charity event as returned by the client-side queries: the columns listed in
 * {@link module:event_model~EVENT_COLUMNS} plus the computed `display_status`.
 *
 * @typedef {object} CharityEvent
 * @property {number} event_id - Primary key.
 * @property {string} name - Event name.
 * @property {string} event_date - `YYYY-MM-DD HH:MM:SS` text (kept as text by `dateStrings` in {@link module:event_db}).
 * @property {string} location - Free-text place.
 * @property {number} latitude - Latitude, used by the weather proxy.
 * @property {number} longitude - Longitude, used by the weather proxy.
 * @property {string} purpose - What the event is raising money for.
 * @property {string} description - The long description.
 * @property {number} ticket_price - Price of one ticket; `0` means a free event.
 * @property {number} fundraising_goal - Target amount.
 * @property {number} amount_raised - Amount collected so far.
 * @property {'active'|'suspended'} status - The stored status; "past" is derived from the date.
 * @property {string} image_url - Relative image path.
 * @property {number} organisation_id - Owning organisation.
 * @property {number} category_id - Category of the event.
 * @property {string} category_name - Joined `categories.name`.
 * @property {string} organisation_name - Joined `organisations.name`.
 * @property {string} organisation_mission - Joined `organisations.mission`.
 * @property {string} organisation_email - Joined `organisations.email`.
 * @property {string} organisation_phone - Joined `organisations.phone`.
 * @property {'active'|'past'|'suspended'} [display_status] - Added by {@link module:event_model~addDisplayStatus}: the three states the brief asks the admin page to show.
 * @property {number} [registration_count] - Admin queries only: how many registrations the event has.
 * @property {number} [tickets_sold] - Admin queries only: how many tickets have been sold.
 */

/**
 * The optional search criteria of `GET /api/events`.
 *
 * @typedef {object} EventFilters
 * @property {'upcoming'|'past'|'all'} [status] - Which slice of time to show; `upcoming` is the default and unknown values are rejected before they reach here.
 * @property {string} [date] - An exact day, `YYYY-MM-DD`.
 * @property {string} [location] - A partial place name, matched case-insensitively. The route escapes `%` and `_` first.
 * @property {number|string} [category] - A category id.
 */

/**
 * The event fields the admin form may send.
 *
 * @typedef {object} EventInput
 * @property {number|string} [organisation_id] - Owning organisation; defaults to `1` (the case study has one).
 * @property {number|string} [category_id] - Category of the event.
 * @property {string} [name] - Event name.
 * @property {string} [event_date] - Date and time, `YYYY-MM-DD HH:MM`.
 * @property {string} [location] - Free-text place.
 * @property {number|string} [latitude] - Latitude, between -90 and 90.
 * @property {number|string} [longitude] - Longitude, between -180 and 180.
 * @property {string} [purpose] - What the event is raising money for.
 * @property {string} [description] - The long description.
 * @property {number|string} [ticket_price] - Price of one ticket, `0` or more.
 * @property {number|string} [fundraising_goal] - Target amount, more than 0.
 * @property {number|string} [amount_raised] - Amount collected so far.
 * @property {'active'|'suspended'} [status] - The stored status.
 * @property {string} [image_url] - Relative image path.
 */

/**
 * The values the public registration form may send.
 *
 * @typedef {object} RegistrationInput
 * @property {string} first_name - The registrant's first name.
 * @property {string} last_name - The registrant's last name.
 * @property {string} email - Lower-cased email address; unique per event.
 * @property {string} phone - Contact number.
 * @property {number} tickets - Whole number of tickets, 1 to 10.
 * @property {string} [notes] - Optional note.
 */

/**
 * One registration as it is allowed to leave the API.
 *
 * @typedef {object} PublicRegistration
 * @property {number} registration_id - Primary key.
 * @property {string} first_name - The registrant's first name.
 * @property {string} last_name - The registrant's last name.
 * @property {string} email - The real address for staff, or a masked one for the public site.
 * @property {string} phone - The real number for staff, or the literal `'hidden'` for the public site.
 * @property {number} tickets - Number of tickets bought.
 * @property {string} registration_date - `YYYY-MM-DD HH:MM:SS` text.
 * @property {number} total_amount - Ticket price x tickets, worked out on the server.
 * @property {string} [notes] - Optional note.
 */

/**
 * The outcome of {@link module:event_model~deleteEventSafely}.
 *
 * @typedef {object} DeleteOutcome
 * @property {'deleted'|'not_found'|'has_registrations'} result - What happened; the caller turns this into 200, 404 or 409.
 * @property {number} [registrationCount] - Present only when `result` is `'has_registrations'`.
 */

/**
 * The column list every client-side event query selects.
 *
 * @constant {string}
 * @remarks
 * `is_past` is worked out by MySQL so the JavaScript does not have to parse
 * dates, and it lets the admin list show Active / Past / Suspended without an
 * extra table column (the brief asks for those three states). The joins that
 * provide `c.name` and the `o.*` columns live in
 * {@link module:event_model~EVENT_JOINS}.
 */
const EVENT_COLUMNS =
  'e.event_id, e.name, e.event_date, e.location, e.latitude, e.longitude, ' +
  'e.purpose, e.description, e.ticket_price, e.fundraising_goal, e.amount_raised, ' +
  'e.status, e.image_url, e.organisation_id, e.category_id, ' +
  '(e.event_date < NOW()) AS is_past, ' +
  'c.name AS category_name, ' +
  'o.name AS organisation_name, o.mission AS organisation_mission, ' +
  'o.email AS organisation_email, o.phone AS organisation_phone';

/**
 * The joins that complete {@link module:event_model~EVENT_COLUMNS}.
 *
 * @constant {string}
 * @remarks
 * `INNER JOIN` is deliberate: every event must have a category and an
 * organisation, so a missing row would be a data fault worth hiding.
 */
const EVENT_JOINS =
  'FROM events e ' +
  'INNER JOIN categories c ON e.category_id = c.category_id ' +
  'INNER JOIN organisations o ON e.organisation_id = o.organisation_id';

/**
 * Adds the derived `display_status` to a raw event row, in place.
 *
 * @function addDisplayStatus
 * @param {CharityEvent|undefined} row - A row of the shape produced by {@link module:event_model~EVENT_COLUMNS}, or nothing at all.
 * @returns {CharityEvent|undefined} The same object with a `display_status` of `'suspended'`, `'past'` or `'active'` and without the raw `is_past` flag.
 * @remarks
 * The brief needs the three states Active / Past / Suspended on the admin page.
 * The precedence is suspended, then past, then active: a suspended event that
 * has already happened is still reported as suspended because that is the state
 * staff have to act on. `is_past` is deleted so it never reaches the JSON.
 * @example
 * addDisplayStatus({ status: 'active', is_past: 1 });
 * // -> { status: 'active', display_status: 'past' }
 */
function addDisplayStatus(row) {
  if (!row) {
    return row;
  }
  if (row.status === 'suspended') {
    row.display_status = 'suspended';
  } else if (Number(row.is_past) === 1) {
    row.display_status = 'past';
  } else {
    row.display_status = 'active';
  }
  delete row.is_past;
  return row;
}

/**
 * Hides the middle of an email address before it is published.
 *
 * @function maskEmail
 * @param {string} email - The address to mask; anything without an `@` is returned unchanged.
 * @returns {string} The masked address, for example `a***z@example.com`; very short local parts become `a***@example.com`.
 * @remarks
 * The public detail page shows who registered, but a full email address of a
 * member of the public should not be published on an open website, so the
 * client-side endpoint gets a masked version. The admin endpoint (which is for
 * staff) returns the real address.
 * @see module:event_model~publicRegistration
 * @example
 * maskEmail('amelia.nguyen@example.com'); // 'a***n@example.com'
 * maskEmail('jo@example.com');            // 'j***@example.com'
 * maskEmail('not-an-address');            // 'not-an-address'
 */
function maskEmail(email) {
  if (!email || email.indexOf('@') === -1) {
    return email;
  }
  const parts = email.split('@');
  const name = parts[0];
  const domain = parts[1];
  if (name.length <= 2) {
    return name.charAt(0) + '***@' + domain;
  }
  return name.charAt(0) + '***' + name.charAt(name.length - 1) + '@' + domain;
}

/**
 * Reshapes a registration row for delivery to a website.
 *
 * @function publicRegistration
 * @param {object} row - A row from the `registrations` table.
 * @param {boolean} mask - `true` for the public site (mask the email, hide the phone), `false` for the staff view (send the real values).
 * @returns {PublicRegistration} A copy with exactly the fields the websites are allowed to see, so a future column cannot leak out by accident.
 * @example
 * publicRegistration({ email: 'amelia.nguyen@example.com', phone: '0400 111 222', tickets: 2 }, true);
 * // -> { ..., email: 'a***n@example.com', phone: 'hidden', tickets: 2 }
 */
function publicRegistration(row, mask) {
  return {
    registration_id: row.registration_id,
    first_name: row.first_name,
    last_name: row.last_name,
    email: mask ? maskEmail(row.email) : row.email,
    phone: mask ? 'hidden' : row.phone,
    tickets: row.tickets,
    registration_date: row.registration_date,
    total_amount: row.total_amount,
    notes: row.notes
  };
}

/**
 * Client-side read: the home page list.
 *
 * @function getHomeEvents
 * @async
 * @returns {Promise<CharityEvent[]>} A promise for the active events from today onwards, soonest first; an empty array when there are none.
 * @throws {Error} If the query fails; Express 5 forwards the rejection to the `module:server` error handler.
 * @example
 * // GET /api/events/home
 * [ { "event_id": 1, "name": "Coastal Sunrise Fun Run", "display_status": "active", ... } ]
 */
async function getHomeEvents() {
  const sql =
    'SELECT ' + EVENT_COLUMNS + ' ' + EVENT_JOINS +
    " WHERE e.status = 'active' AND e.event_date >= NOW()" +
    ' ORDER BY e.event_date ASC';
  const [rows] = await pool.query(sql);
  return rows.map(addDisplayStatus);
}

/**
 * Client-side read: the search page, with optional criteria that can be combined.
 *
 * @function searchEvents
 * @async
 * @param {EventFilters} filters - The already-validated search criteria. An empty object behaves like `{ status: 'upcoming' }`.
 * @returns {Promise<CharityEvent[]>} A promise for the matching active events, soonest first.
 * @throws {Error} If the query fails; Express 5 forwards the rejection to the `module:server` error handler.
 * @remarks
 * Only active events are ever searched: a suspended event is not published, so
 * it must not be findable. Every criterion is appended with `AND`, so the
 * filters narrow each other. The `date`, `location` and `category` values are
 * pushed as bound parameters in the same order as their placeholders, which is
 * what keeps the statement injection-proof.
 * @see module:routes/events - builds `filters` and rejects invalid values with a 400
 * @example
 * await searchEvents({ status: 'all', category: 1, location: 'lismore' });
 * // -> [ the one active/any-status event in Lismore of category 1 ]
 */
async function searchEvents(filters) {
  const where = ["e.status = 'active'"];
  const values = [];

  // upcoming (default), already finished, or everything
  if (filters.status === 'past') {
    where.push('e.event_date < NOW()');
  } else if (filters.status === 'all') {
    // no extra condition
  } else {
    where.push('e.event_date >= NOW()');
  }

  if (filters.date) {
    where.push('DATE(e.event_date) = ?');
    values.push(filters.date);
  }
  if (filters.location) {
    // LOWER() makes the place search case-insensitive
    where.push('LOWER(e.location) LIKE LOWER(?)');
    values.push('%' + filters.location + '%');
  }
  if (filters.category) {
    where.push('e.category_id = ?');
    values.push(filters.category);
  }

  const sql =
    'SELECT ' + EVENT_COLUMNS + ' ' + EVENT_JOINS +
    ' WHERE ' + where.join(' AND ') +
    ' ORDER BY e.event_date ASC';
  const [rows] = await pool.query(sql, values);
  return rows.map(addDisplayStatus);
}

/**
 * Client-side read: the days that have an upcoming active event.
 *
 * @function getEventDates
 * @async
 * @returns {Promise<string[]>} A promise for the distinct days as `YYYY-MM-DD` strings, earliest first.
 * @throws {Error} If the query fails; Express 5 forwards the rejection to the `module:server` error handler.
 * @remarks
 * Feeds the date dropdown of the search form. `DISTINCT` plus `DATE_FORMAT` is
 * done in SQL so the list is already sorted and de-duplicated.
 * @see module:routes/lookups - `GET /api/event-dates`
 */
async function getEventDates() {
  const sql =
    "SELECT DISTINCT DATE_FORMAT(e.event_date, '%Y-%m-%d') AS event_day " +
    'FROM events e ' +
    "WHERE e.status = 'active' AND e.event_date >= NOW() " +
    'ORDER BY event_day ASC';
  const [rows] = await pool.query(sql);
  return rows.map(function (row) {
    return row.event_day;
  });
}

/**
 * Client-side read: the event categories for the search dropdown.
 *
 * @function getCategories
 * @async
 * @returns {Promise<Array<{category_id: number, name: string, description: string}>>} A promise for every category, ordered by name.
 * @throws {Error} If the query fails; Express 5 forwards the rejection to the `module:server` error handler.
 * @see module:routes/lookups - `GET /api/categories`
 */
async function getCategories() {
  const sql = 'SELECT category_id, name, description FROM categories ORDER BY name ASC';
  const [rows] = await pool.query(sql);
  return rows;
}

/**
 * Client-side read: the registrations of one event, newest first.
 *
 * @function getRegistrationsForEvent
 * @async
 * @param {number} eventId - The event to list; the caller has already checked that it exists.
 * @returns {Promise<object[]>} A promise for the raw registration rows (the caller decides whether to mask them with {@link module:event_model~publicRegistration}).
 * @throws {Error} If the query fails; Express 5 forwards the rejection to the `module:server` error handler.
 * @remarks
 * The brief asks the event page to list the purchased tickets "sorted by the
 * latest date when the tickets were purchased", so the order is `DESC`.
 * `registration_id` breaks ties for registrations made in the same second,
 * which keeps the list stable between two identical requests.
 */
async function getRegistrationsForEvent(eventId) {
  const sql =
    'SELECT registration_id, event_id, first_name, last_name, email, phone, ' +
    'tickets, registration_date, total_amount, notes ' +
    'FROM registrations WHERE event_id = ? ' +
    'ORDER BY registration_date DESC, registration_id DESC';
  const [rows] = await pool.query(sql, [eventId]);
  return rows;
}

/**
 * Client-side read: the totals shown above the registration list.
 *
 * @function getRegistrationSummary
 * @async
 * @param {number} eventId - The event to total up.
 * @returns {Promise<{registration_count: number, tickets_sold: number, amount_registered: number, latest_registration: string|null}>} A promise for one aggregate row; the sums are `0` (not `null`) for an event with no registrations, because of `COALESCE`.
 * @throws {Error} If the query fails; Express 5 forwards the rejection to the `module:server` error handler.
 * @remarks
 * Aggregating in SQL rather than in JavaScript means the figures cannot drift
 * from the rows they describe, and only one small row crosses the wire.
 */
async function getRegistrationSummary(eventId) {
  const sql =
    'SELECT COUNT(*) AS registration_count, ' +
    'COALESCE(SUM(tickets), 0) AS tickets_sold, ' +
    'COALESCE(SUM(total_amount), 0) AS amount_registered, ' +
    'MAX(registration_date) AS latest_registration ' +
    'FROM registrations WHERE event_id = ?';
  const [rows] = await pool.query(sql, [eventId]);
  return rows[0];
}

/**
 * Client-side read: one event for the client detail page.
 *
 * @function getEventById
 * @async
 * @param {number} id - The event id, already parsed into a positive integer.
 * @returns {Promise<CharityEvent|undefined>} A promise for the event, or `undefined` when there is no such event or it is suspended; the caller turns that into a 404.
 * @throws {Error} If the query fails; Express 5 forwards the rejection to the `module:server` error handler.
 * @remarks
 * A suspended event is never published, but a past event can still be opened in
 * case the link was shared earlier. That is why the filter is
 * `status <> 'suspended'` rather than a date test.
 * @see module:event_model~getAdminEventById - the staff equivalent, which includes suspended events
 */
async function getEventById(id) {
  const sql =
    'SELECT ' + EVENT_COLUMNS + ' ' + EVENT_JOINS +
    " WHERE e.event_id = ? AND e.status <> 'suspended'";
  const [rows] = await pool.query(sql, [id]);
  return addDisplayStatus(rows[0]);
}

/**
 * Admin-side read: every event regardless of status, with its counters.
 *
 * @function getAllEventsForAdmin
 * @async
 * @returns {Promise<CharityEvent[]>} A promise for all events, latest event date first, each with `registration_count` and `tickets_sold`.
 * @throws {Error} If the query fails; Express 5 forwards the rejection to the `module:server` error handler.
 * @remarks
 * The brief requires the staff list to show every event "regardless of their
 * status (Active, Past, Suspended)", so unlike the client queries there is no
 * status filter here. Two correlated sub-queries supply the counters, which
 * keeps the row count at one per event - a `LEFT JOIN ... GROUP BY` would need
 * the same care but is easier to get wrong.
 * @see module:event_model~getHomeEvents
 */
async function getAllEventsForAdmin() {
  const sql =
    'SELECT ' + EVENT_COLUMNS + ', ' +
    '(SELECT COUNT(*) FROM registrations r WHERE r.event_id = e.event_id) AS registration_count, ' +
    '(SELECT COALESCE(SUM(r.tickets), 0) FROM registrations r WHERE r.event_id = e.event_id) AS tickets_sold ' +
    EVENT_JOINS +
    ' ORDER BY e.event_date DESC';
  const [rows] = await pool.query(sql);
  return rows.map(addDisplayStatus);
}

/**
 * Admin-side read: one event of any status, with its counters.
 *
 * @function getAdminEventById
 * @async
 * @param {number} id - The event id, already parsed into a positive integer.
 * @returns {Promise<CharityEvent|undefined>} A promise for the event, or `undefined` when there is no such event.
 * @throws {Error} If the query fails; Express 5 forwards the rejection to the `module:server` error handler.
 * @see module:event_model~getEventById - the public equivalent, which hides suspended events
 */
async function getAdminEventById(id) {
  const sql =
    'SELECT ' + EVENT_COLUMNS + ', ' +
    '(SELECT COUNT(*) FROM registrations r WHERE r.event_id = e.event_id) AS registration_count, ' +
    '(SELECT COALESCE(SUM(r.tickets), 0) FROM registrations r WHERE r.event_id = e.event_id) AS tickets_sold ' +
    EVENT_JOINS +
    ' WHERE e.event_id = ?';
  const [rows] = await pool.query(sql, [id]);
  return addDisplayStatus(rows[0]);
}

/**
 * Admin-side read: a cheap existence test.
 *
 * @function eventExists
 * @async
 * @param {number} id - The event id, already parsed into a positive integer.
 * @returns {Promise<boolean>} A promise for `true` when the row is there, `false` otherwise.
 * @throws {Error} If the query fails; Express 5 forwards the rejection to the `module:server` error handler.
 * @remarks
 * Used before an update or a delete, and before the registration list, so a
 * missing event becomes a `404` instead of an empty `200` response. Only the
 * primary key is selected, so the check stays cheap.
 */
async function eventExists(id) {
  const [rows] = await pool.query('SELECT event_id FROM events WHERE event_id = ?', [id]);
  return rows.length > 0;
}

/**
 * Admin-side write: creates a charity event.
 *
 * @function createEvent
 * @async
 * @param {EventInput} data - The already-validated and normalised fields; `module:validation` has filled in the defaults and converted the strings.
 * @returns {Promise<number>} A promise for the new `event_id` (MySQL's `insertId`), which the endpoint returns as `201`.
 * @throws {Error} If the insert fails - for example `ER_NO_REFERENCED_ROW_2` when the category does not exist, which `module:server` reports as a 409.
 */
async function createEvent(data) {
  const sql =
    'INSERT INTO events (organisation_id, category_id, name, event_date, location, ' +
    'latitude, longitude, purpose, description, ticket_price, fundraising_goal, ' +
    'amount_raised, status, image_url) ' +
    'VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
  const values = [
    data.organisation_id,
    data.category_id,
    data.name,
    data.event_date,
    data.location,
    data.latitude,
    data.longitude,
    data.purpose,
    data.description,
    data.ticket_price,
    data.fundraising_goal,
    data.amount_raised,
    data.status,
    data.image_url
  ];
  const [result] = await pool.query(sql, values);
  return result.insertId;
}

/**
 * Admin-side write: a partial update.
 *
 * @function updateEvent
 * @async
 * @param {number} id - The event to update.
 * @param {EventInput} data - Only the fields the admin actually sent are changed; anything left out keeps its stored value.
 * @returns {Promise<number>} A promise for the number of affected rows. `0` when nothing was sent, and possibly `0` when the sent values equal the stored ones (MySQL does not count an unchanged row).
 * @throws {Error} If the update fails; Express 5 forwards the rejection to the `module:server` error handler.
 * @remarks
 * The whitelist in `allowed` is what makes this safe: a field name from the
 * request body never reaches the SQL text, only the fixed names below do, and
 * every value is bound. Sending no known field at all returns early instead of
 * building an `UPDATE ... SET` with an empty list, which is a syntax error.
 * @example
 * await updateEvent(3, { ticket_price: 30 }); // -> 1  (only the price changes)
 * await updateEvent(3, {});                   // -> 0  (nothing sent)
 */
async function updateEvent(id, data) {
  const allowed = [
    'organisation_id', 'category_id', 'name', 'event_date', 'location',
    'latitude', 'longitude', 'purpose', 'description', 'ticket_price',
    'fundraising_goal', 'amount_raised', 'status', 'image_url'
  ];
  const sets = [];
  const values = [];

  allowed.forEach(function (field) {
    if (data[field] !== undefined) {
      sets.push(field + ' = ?');
      values.push(data[field]);
    }
  });

  if (sets.length === 0) {
    return 0;
  }

  values.push(id);
  const sql = 'UPDATE events SET ' + sets.join(', ') + ' WHERE event_id = ?';
  const [result] = await pool.query(sql, values);
  return result.affectedRows;
}

/**
 * Admin-side write helper: how many registrations an event has.
 *
 * @function countRegistrations
 * @async
 * @param {number} eventId - The event to count for.
 * @returns {Promise<number>} A promise for the number of registration rows.
 * @throws {Error} If the query fails; Express 5 forwards the rejection to the `module:server` error handler.
 * @remarks
 * Used before a delete so the admin page can explain the block. The delete
 * itself re-counts inside its own transaction rather than trusting this value.
 * @see module:event_model~deleteEventSafely
 */
async function countRegistrations(eventId) {
  const [rows] = await pool.query(
    'SELECT COUNT(*) AS total FROM registrations WHERE event_id = ?',
    [eventId]
  );
  return rows[0].total;
}

/**
 * Admin-side write: deletes an event while keeping the data honest.
 *
 * @function deleteEventSafely
 * @async
 * @param {number} id - The event to delete.
 * @returns {Promise<DeleteOutcome>} A promise for one of:
 *
 * ```text
 * { result: 'deleted' }
 * { result: 'not_found' }
 * { result: 'has_registrations', registrationCount: n }
 * ```
 * @throws {Error} If the transaction (or the rollback) fails; the error is re-thrown after the connection is returned to the pool, and `module:server` reports it as a 500.
 * @remarks
 * The brief: "the event can only be deleted if it has not yet received any
 * registrations. If registrations exist, the deletion attempt should be
 * blocked."
 *
 * The check and the delete run inside ONE transaction and the event row is
 * locked with `SELECT ... FOR UPDATE`, so two admins clicking Delete at the
 * same time cannot slip a registration in between the check and the delete.
 * The database foreign key (`ON DELETE RESTRICT`) is the second safety net.
 *
 * ```text
 * 1. BEGIN
 * 2. SELECT event_id FROM events WHERE event_id = ? FOR UPDATE   -- lock the row
 * 3. no row            -> ROLLBACK, return { result: 'not_found' }
 * 4. COUNT(*) registrations for the id
 * 5. count > 0         -> ROLLBACK, return { result: 'has_registrations', registrationCount }
 * 6. DELETE FROM events WHERE event_id = ?
 * 7. COMMIT            -> return { result: 'deleted' }
 * 8. any error         -> ROLLBACK and re-throw
 * 9. finally           -> release the connection back to the pool
 * ```
 *
 * The connection is taken from the pool explicitly because a transaction must
 * stay on one connection; `pool.query` would be free to pick another.
 * @see module:event_model~countRegistrations
 * @see module:routes/events - `DELETE /api/events/:id` turns the outcome into 200, 404 or 409
 * @example
 * const outcome = await deleteEventSafely(4);
 * if (outcome.result === 'has_registrations') {
 *   console.log(outcome.registrationCount + ' registrations block the delete');
 * }
 */
async function deleteEventSafely(id) {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();

    const [eventRows] = await connection.query(
      'SELECT event_id FROM events WHERE event_id = ? FOR UPDATE',
      [id]
    );
    if (eventRows.length === 0) {
      await connection.rollback();
      return { result: 'not_found' };
    }

    const [countRows] = await connection.query(
      'SELECT COUNT(*) AS total FROM registrations WHERE event_id = ?',
      [id]
    );
    const registrationCount = countRows[0].total;
    if (registrationCount > 0) {
      await connection.rollback();
      return { result: 'has_registrations', registrationCount: registrationCount };
    }

    await connection.query('DELETE FROM events WHERE event_id = ?', [id]);
    await connection.commit();
    return { result: 'deleted' };
  } catch (err) {
    await connection.rollback();
    throw err;
  } finally {
    connection.release();
  }
}

/**
 * Public registration write, step 1: load the event the visitor wants to attend.
 *
 * @function getEventForRegistration
 * @async
 * @param {number} eventId - The event being registered for.
 * @returns {Promise<object|null>} A promise for a small event object - `event_id`, `name`, `event_date`, `location`, `ticket_price`, `status` and a boolean `is_past` - or `null` when the event does not exist.
 * @throws {Error} If the query fails; Express 5 forwards the rejection to the `module:server` error handler.
 * @remarks
 * Only the handful of columns the registration needs are selected, and
 * `is_past` is converted to a real boolean here so the route can test
 * `event.is_past === true` instead of comparing MySQL's `0`/`1`.
 * @see module:routes/events - refuses a suspended or past event with a 409 before this can be used
 */
async function getEventForRegistration(eventId) {
  const [rows] = await pool.query(
    'SELECT event_id, name, event_date, location, ticket_price, status, ' +
    '(event_date < NOW()) AS is_past FROM events WHERE event_id = ?',
    [eventId]
  );
  if (rows.length === 0) {
    return null;
  }
  const row = rows[0];
  row.is_past = Number(row.is_past) === 1;
  return row;
}

/**
 * Public registration write, step 2: has this email already registered?
 *
 * @function findRegistration
 * @async
 * @param {number} eventId - The event being registered for.
 * @param {string} email - The lower-cased email address of the visitor.
 * @returns {Promise<{registration_id: number}|null>} A promise for the existing row (only its id), or `null` when this email is new for this event.
 * @throws {Error} If the query fails; Express 5 forwards the rejection to the `module:server` error handler.
 * @remarks
 * The uniqueness the brief asks for is "one registration per email per event",
 * not one per person overall, so the test is on the pair `(event_id, email)`.
 * Checking here turns the duplicate into a friendly `409` instead of a raw
 * database error; the `UNIQUE` key is still the real guarantee.
 * @see module:event_model~createRegistration
 */
async function findRegistration(eventId, email) {
  const [rows] = await pool.query(
    'SELECT registration_id FROM registrations WHERE event_id = ? AND email = ?',
    [eventId, email]
  );
  return rows[0] || null;
}

/**
 * Public registration write, step 3: store the registration and price it.
 *
 * @function createRegistration
 * @async
 * @param {number} eventId - The event being registered for.
 * @param {RegistrationInput} data - The already-validated fields; the price is deliberately NOT one of them.
 * @returns {Promise<{registration_id: number, total_amount: number}>} A promise for the new id and the server-computed total.
 * @throws {Error} If the insert fails; Express 5 forwards the rejection to the `module:server` error handler.
 * @throws {TypeError} If the event has been deleted between the route's check and this call, because `getEventForRegistration` would have returned `null`.
 * @remarks
 * The total is worked out on the server from the ticket price of the event, so
 * the browser cannot send a price of its own. `.toFixed(2)` keeps the money to
 * two decimals and `Number(...)` turns it back into a number, which matches the
 * `decimalNumbers` setting of {@link module:event_db}.
 * @example
 * // event 4 has ticket_price 45
 * await createRegistration(4, { ..., tickets: 2 });
 * // -> { registration_id: 13, total_amount: 90 }
 */
async function createRegistration(eventId, data) {
  const event = await getEventForRegistration(eventId);
  const total = Number((Number(event.ticket_price) * Number(data.tickets)).toFixed(2));

  const sql =
    'INSERT INTO registrations (event_id, first_name, last_name, email, phone, ' +
    'tickets, total_amount, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
  const values = [
    eventId,
    data.first_name,
    data.last_name,
    data.email,
    data.phone,
    data.tickets,
    total,
    data.notes
  ];
  const [result] = await pool.query(sql, values);
  return { registration_id: result.insertId, total_amount: total };
}

/**
 * Weather proxy support: the coordinates of one event.
 *
 * @function getEventCoordinates
 * @async
 * @param {number} eventId - The event whose weather is being looked up.
 * @returns {Promise<object|null>} A promise for `event_id`, `name`, `event_date`, `location`, `latitude` and `longitude`, or `null` when the event does not exist.
 * @throws {Error} If the query fails; Express 5 forwards the rejection to the `module:server` error handler.
 * @remarks
 * The optional extra of the brief calls the Open-Meteo API, which needs a
 * latitude and a longitude. Passing them to the proxy is what lets the Angular
 * pages make one call instead of two.
 * @see module:routes/weather - `GET /api/weather/:eventId`
 */
async function getEventCoordinates(eventId) {
  const [rows] = await pool.query(
    'SELECT event_id, name, event_date, location, latitude, longitude FROM events WHERE event_id = ?',
    [eventId]
  );
  return rows[0] || null;
}

/**
 * The public surface of this module, one function per SQL operation.
 *
 * @type {object}
 * @property {function(): Promise<CharityEvent[]>} getHomeEvents - Active events from today onwards.
 * @property {function(EventFilters): Promise<CharityEvent[]>} searchEvents - The filtered search list.
 * @property {function(): Promise<string[]>} getEventDates - The days that have an upcoming event.
 * @property {function(): Promise<object[]>} getCategories - Every category.
 * @property {function(number): Promise<CharityEvent|undefined>} getEventById - One published event.
 * @property {function(number): Promise<object[]>} getRegistrationsForEvent - The registrations of one event.
 * @property {function(number): Promise<object>} getRegistrationSummary - The totals above the list.
 * @property {function(): Promise<CharityEvent[]>} getAllEventsForAdmin - Every event, any status.
 * @property {function(number): Promise<CharityEvent|undefined>} getAdminEventById - One event, any status.
 * @property {function(number): Promise<boolean>} eventExists - Is there such an event?
 * @property {function(EventInput): Promise<number>} createEvent - Insert and return the new id.
 * @property {function(number, EventInput): Promise<number>} updateEvent - Partial update.
 * @property {function(number): Promise<number>} countRegistrations - Registrations of one event.
 * @property {function(number): Promise<DeleteOutcome>} deleteEventSafely - Transactional delete.
 * @property {function(number): Promise<object|null>} getEventForRegistration - The event, for the registration checks.
 * @property {function(number, string): Promise<object|null>} findRegistration - Duplicate check by email.
 * @property {function(number, RegistrationInput): Promise<{registration_id: number, total_amount: number}>} createRegistration - Insert a registration.
 * @property {function(number): Promise<object|null>} getEventCoordinates - Coordinates for the weather proxy.
 * @property {function(object, boolean): PublicRegistration} publicRegistration - Reshape a row for a website.
 */
module.exports = {
  getHomeEvents: getHomeEvents,
  searchEvents: searchEvents,
  getEventDates: getEventDates,
  getCategories: getCategories,
  getEventById: getEventById,
  getRegistrationsForEvent: getRegistrationsForEvent,
  getRegistrationSummary: getRegistrationSummary,
  getAllEventsForAdmin: getAllEventsForAdmin,
  getAdminEventById: getAdminEventById,
  eventExists: eventExists,
  createEvent: createEvent,
  updateEvent: updateEvent,
  countRegistrations: countRegistrations,
  deleteEventSafely: deleteEventSafely,
  getEventForRegistration: getEventForRegistration,
  findRegistration: findRegistration,
  createRegistration: createRegistration,
  getEventCoordinates: getEventCoordinates,
  publicRegistration: publicRegistration
};
