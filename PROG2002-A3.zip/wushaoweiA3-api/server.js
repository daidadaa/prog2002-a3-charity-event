/**
 * PROG2002 Web Development II - Assessment 3 (WU Shao Wei).
 *
 * @module server
 * @description
 * The Express application for the charity events API. It parses JSON request
 * bodies, sets the CORS headers the two Angular websites need, mounts the four
 * route modules and turns anything unhandled into a JSON error.
 *
 * @remarks
 * Assessment 2 served the static pages and the API from the same address. In
 * Assessment 3 the two websites are Angular applications, so this server is now
 * API only - the three-tier architecture of the assignment:
 *
 * ```text
 *   the Angular client website (dev: http://localhost:4200)
 *   the Angular admin website  (dev: http://localhost:4300)
 *              |  JSON over HTTP
 *              v
 *   this Express API          (http://localhost:3000)
 *              |  mysql2 pool
 *              v
 *   MySQL  charityevents_db
 * ```
 *
 * Run it with `npm start` (or `npm run dev` for nodemon).
 * The documentation for this API is generated with `npm run docs`.
 *
 * @see module:event_db   - the shared MySQL connection pool
 * @see module:event_model - the SQL behind every route
 * @see module:routes/events  - the client website and admin event endpoints
 * @see module:routes/admin   - the admin-only endpoints
 * @see module:routes/lookups - the dropdown lists
 * @see module:routes/weather - the optional Open-Meteo proxy
 */

const express = require('express');
const eventRoutes = require('./routes/events');
const adminRoutes = require('./routes/admin');
const lookupRoutes = require('./routes/lookups');
const weatherRoutes = require('./routes/weather');

/**
 * The Express application instance that every route module is mounted on.
 *
 * @constant {express.Express}
 */
const app = express();

/**
 * The TCP port the API listens on.
 *
 * @constant {number}
 * @default
 * @remarks
 * Taken from `PORT` in `.env` (see `.env.example`) so the same code works on
 * localhost and on the SCU cPanel, where the host assigns the port.
 */
const port = process.env.PORT || 3000;

/**
 * Body parser for POST and PUT.
 *
 * Turns an `application/json` request body into `req.body`, so the route
 * handlers and {@link module:validation} can read it. Both Angular
 * applications post JSON, so no form-encoded parser is installed.
 *
 * @function jsonBodyParser
 * @see module:validation
 */
app.use(express.json());

/**
 * CORS middleware.
 *
 * @function corsHeaders
 * @param {express.Request} req - The Express request; only `req.method` is inspected.
 * @param {express.Response} res - The Express response the headers are set on.
 * @param {express.NextFunction} next - Moves the request on to the next middleware.
 * @returns {void} Returns nothing; either the preflight reply is sent or the chain continues.
 * @remarks
 * The two Angular websites run on different ports (4200 and 4300) during
 * development, so the browser is making a cross-origin request. Only the
 * methods the API actually supports are allowed. An `OPTIONS` preflight is
 * answered immediately with `204 No Content`; the browser never sends the real
 * request unless that succeeds.
 */
app.use(function (req, res, next) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(204);
  }
  next();
});

/**
 * A very small request log, useful when demonstrating the data flow in the video.
 *
 * @function requestLogger
 * @param {express.Request} req - The Express request being logged.
 * @param {express.Response} res - The Express response; not used here.
 * @param {express.NextFunction} next - Called immediately so the logger never delays a request.
 * @returns {void} Nothing; the line is written to the console.
 * @example
 * // console
 * // 2026-10-15T02:14:07.512Z  GET /api/events/home
 */
app.use(function (req, res, next) {
  console.log(new Date().toISOString() + '  ' + req.method + ' ' + req.originalUrl);
  next();
});

/**
 * `GET /api/health` - a trivially cheap liveness check.
 *
 * @function healthCheck
 * @param {express.Request} req - The Express request; nothing is read from it.
 * @param {express.Response} res - The Express response, sent with the JSON status object.
 * @returns {void} Nothing; the reply is written straight to `res`.
 * @remarks
 * Handy on the SCU cPanel to prove the API is up (and that Node is serving, not
 * just Apache). It is deliberately the only route here that touches no table.
 * @example
 * // GET /api/health  ->  200 OK
 * { "status": "ok", "service": "charity events API", "assessment": "PROG2002 A3" }
 */
app.get('/api/health', function (req, res) {
  res.json({ status: 'ok', service: 'charity events API', assessment: 'PROG2002 A3' });
});

/**
 * Mounts the four routers underneath `/api`.
 *
 * @function mountRoutes
 * @remarks
 * Each router owns one URL prefix, which keeps the RESTful paths of the brief
 * (for example `GET /api/events/:id/registrations`) out of this file.
 * @see module:routes/events
 * @see module:routes/admin
 * @see module:routes/lookups
 * @see module:routes/weather
 */
app.use('/api/events', eventRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api', lookupRoutes);   // /api/categories and /api/event-dates
app.use('/api/weather', weatherRoutes);

/**
 * Fallback for every unmatched path under `/api`.
 *
 * @function apiNotFound
 * @param {express.Request} req - The Express request (already unmatched).
 * @param {express.Response} res - The Express response; answered with `404` and a JSON error.
 * @returns {void} Nothing; the reply is written straight to `res`.
 * @remarks
 * Anything else under `/api` is a 404 in JSON, not an HTML page, so the Angular
 * applications can show a sensible message instead of trying to parse HTML.
 * @example
 * // GET /api/nope  ->  404 Not Found
 * { "error": "API endpoint not found." }
 */
app.use('/api', function (req, res) {
  res.status(404).json({ error: 'API endpoint not found.' });
});

/**
 * The last error handler for the whole application.
 *
 * @function errorHandler
 * @param {Error} err - The error thrown or rejected by a route handler; a MySQL
 *   error also carries `err.code` (for example `ER_DUP_ENTRY`).
 * @param {express.Request} req - The Express request that failed.
 * @param {express.Response} res - The Express response the JSON error is written to.
 * @param {express.NextFunction} next - Never called; Express needs the fourth parameter to recognise this as an error handler.
 * @returns {void} Nothing; the reply is written straight to `res`.
 * @throws {Error} Never re-throws - this is the end of the chain.
 * @remarks
 * A database error message is logged on the server but never sent to the
 * browser (it can name tables and columns), and the two integrity errors a
 * marker is most likely to trigger are turned into a friendly `409`:
 *
 * ```text
 * ER_DUP_ENTRY            -> 409 That record already exists.
 * ER_NO_REFERENCED_ROW_2  -> 409 That record refers to something that does not exist.
 * anything else           -> 500 Something went wrong on the server.
 * ```
 */
app.use(function (err, req, res, next) {
  console.log('Unhandled error on ' + req.method + ' ' + req.originalUrl + ':');
  console.log(err);

  if (err && err.code === 'ER_DUP_ENTRY') {
    return res.status(409).json({ error: 'That record already exists.' });
  }
  if (err && err.code === 'ER_NO_REFERENCED_ROW_2') {
    return res.status(409).json({ error: 'That record refers to something that does not exist.' });
  }
  res.status(500).json({ error: 'Something went wrong on the server.' });
});

/**
 * Starts the HTTP server.
 *
 * @function startServer
 * @returns {void} Nothing; the callback only logs the two banner lines.
 * @example
 * // console
 * // Charity events API is running at http://localhost:3000
 * // Try http://localhost:3000/api/events/home
 */
app.listen(port, function () {
  console.log('Charity events API is running at http://localhost:' + port);
  console.log('Try http://localhost:' + port + '/api/events/home');
});
