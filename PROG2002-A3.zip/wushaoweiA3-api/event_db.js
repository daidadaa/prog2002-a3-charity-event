/**
 * PROG2002 Web Development II - Assessment 3 (WU Shao Wei).
 *
 * @module event_db
 * @description
 * Creates and exports the single MySQL connection pool that the whole API
 * shares, and reports on the console whether the database answered at start-up.
 *
 * @remarks
 * Assessment 2 opened one single connection with `mysql.createConnection`.
 * Assessment 3 needs to serve the client website, the admin website and the
 * weather proxy at the same time, so this file now creates a connection POOL
 * with `mysql2` and {@link module:event_model} uses async/await instead of
 * nested callbacks.
 *
 * The schema change of Assessment 3 is the new `registrations` table. The pool
 * itself does not need to know about tables, but the queries in
 * {@link module:event_model} do, for example:
 *
 * ```sql
 * SELECT ... FROM registrations WHERE event_id = ? ORDER BY registration_date DESC
 * ```
 *
 * The settings come from `.env` (see `.env.example`) so the marker can use their
 * own MySQL password without editing any code.
 *
 * @see module:event_model - the only consumer of the exported pool
 */

require('dotenv').config();

// 'mysql2/promise' is the promise version of the driver, so the model can use
// async/await (pool.query(...) resolves to [rows, fields])
const mysql = require('mysql2/promise');

/**
 * The MySQL connection settings, read from the process environment.
 *
 * @constant {object}
 * @property {string} host - `DB_HOST`, defaulting to `127.0.0.1`.
 * @property {string} user - `DB_USER`, defaulting to `root`.
 * @property {string} password - `DB_PASSWORD`; there is deliberately no default, so a missing password fails loudly rather than silently connecting.
 * @property {string} database - `DB_NAME`, defaulting to `charityevents_db`.
 * @property {boolean} dateStrings - Keep `DATE` and `DATETIME` as text. Otherwise the JSON gives a timezone-shifted ISO string and the dates on the pages look wrong.
 * @property {boolean} decimalNumbers - Hand `DECIMAL` values over as JavaScript numbers instead of the driver's precision-preserving strings (for example `ticket_price` would be `"25.00"`). Both Angular applications type money as a number, so this makes the JSON match the documented API contract; the amounts in this case study are small enough that a double is exact to the cent.
 * @property {boolean} waitForConnections - Queue a request when all connections are busy rather than failing it.
 * @property {number} connectionLimit - Maximum number of connections in the pool.
 * @property {number} queueLimit - `0` means the queue is unlimited.
 */
const dbDetails = {
  host: process.env.DB_HOST || '127.0.0.1',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'charityevents_db',
  dateStrings: true,
  decimalNumbers: true,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
};

if (!process.env.DB_PASSWORD) {
  console.log('Database password is missing. Copy .env.example to .env and fill in your MySQL password.');
}

/**
 * The one connection pool for the whole application.
 *
 * @constant {mysql.Pool}
 * @see module:event_model
 */
const pool = mysql.createPool(dbDetails);

/**
 * The start-up connection check.
 *
 * @function checkConnection
 * @async
 * @returns {Promise<void>} A promise that resolves once the pool has lent out (and taken back) one connection; the connection itself is released and never used again.
 * @remarks
 * A quick check at start up so the console says whether MySQL answered. Failure
 * is caught here and only logged, so a database that is down at boot does not
 * stop the API from starting - the individual routes then fail and
 * {@link module:server} turns that into a `500`.
 * @example
 * // console, database reachable
 * // Connected to the charityevents_db database.
 * // console, database down
 * // Database connection failed:
 * // connect ECONNREFUSED 127.0.0.1:3306
 */
pool
  .getConnection()
  .then(function (connection) {
    connection.release();
    console.log('Connected to the ' + dbDetails.database + ' database.');
  })
  .catch(function (err) {
    console.log('Database connection failed:');
    console.log(err.message);
  });

/**
 * The public surface of this module.
 *
 * @type {object}
 * @property {mysql.Pool} pool - The shared pool that {@link module:event_model} runs every query on.
 */
module.exports = { pool: pool };
