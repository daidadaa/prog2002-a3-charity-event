/**
 * PROG2002 Web Development II - Assessment 3 (WU Shao Wei).
 *
 * @module routes/events
 * @description
 * The RESTful routes for the "events" resource, mounted by
 * {@link module:server} at `/api/events`: the public lists the client website
 * reads, the public registration write, and the admin create/update/delete
 * operations.
 *
 * @remarks
 * The route table:
 *
 * ```text
 *   GET    /api/events/home               the home page list
 *   GET    /api/events                    the search page list (query strings)
 *   GET    /api/events/:id                one event + its registrations
 *   GET    /api/events/:id/registrations  the registrations of one event
 *   POST   /api/events/:id/registrations  register for an event
 *   POST   /api/events                    create a charity event
 *   PUT    /api/events/:id                update a charity event
 *   DELETE /api/events/:id                delete a charity event
 * ```
 *
 * The URLs are built around the resources (events, registrations) and the HTTP
 * method says what happens to the resource, which is the RESTful style the
 * brief asks for. POST, PUT and DELETE are the admin-side operations.
 *
 * Express 5 forwards a rejected promise from an async handler to the
 * `module:server` error handler, so the handlers below can use async/await
 * without a try/catch. The one exception is the registration insert, which
 * catches the duplicate-key error itself to answer a friendlier `409`.
 *
 * Every `:id` in a URL goes through {@link module:routes/events~parseId}, so a
 * non-numeric id is a `400` and never reaches SQL.
 *
 * @see module:event_model - the SQL these handlers call
 * @see module:validation - the body and query checks
 * @see module:routes/admin - the staff-only endpoints
 */

const express = require('express');

/**
 * The router for the `/api/events` prefix.
 *
 * @constant {express.Router}
 */
const router = express.Router();
const model = require('../event_model');
const validation = require('../validation');

/**
 * Parses an id from the URL.
 *
 * @function parseId
 * @param {string} value - The raw `req.params.id` text.
 * @returns {number|null} The id as a positive whole number, or `null` when the text is not one (the caller answers `400`).
 * @remarks
 * Rejecting `null` here is what keeps values such as `abc`, `-1`, `1.5` and
 * `1e3` out of the SQL, so the only ids that ever reach
 * {@link module:event_model} are plain positive integers.
 * @example
 * parseId('12');  // 12
 * parseId('abc'); // null
 * parseId('0');   // null
 */
function parseId(value) {
  if (/^[0-9]+$/.test(value) === false) {
    return null;
  }
  const id = Number(value);
  return id > 0 ? id : null;
}

/**
 * `GET /api/events/home` - the home page list.
 *
 * Declared before `/:id`, otherwise "home" would be read as an event id.
 *
 * @function getHomeEventsHandler
 * @async
 * @param {express.Request} req - The Express request; no query string parameters are used.
 * @param {express.Response} res - The Express response.
 * @returns {Promise<void>} A promise that resolves once the JSON array has been sent.
 * @throws {Error} If the query fails; Express 5 forwards the rejection to the `module:server` error handler, which answers 500.
 * @see module:event_model~getHomeEvents
 * @example
 * // GET /api/events/home  ->  200 OK
 * [ { "event_id": 1, "name": "Coastal Sunrise Fun Run", "display_status": "active", ... } ]
 */
router.get('/home', async function (req, res) {
  const events = await model.getHomeEvents();
  res.json(events);
});

/**
 * `GET /api/events` - the search page.
 *
 * Optional query strings `status`, `date`, `location` and `category`; they
 * combine, and all of them are validated before the model is called. The
 * response is always a JSON array, so an empty search is `200 []` rather than a
 * `404`.
 *
 * @function searchEventsHandler
 * @async
 * @param {express.Request} req - The Express request. `req.query.status` must be `upcoming`, `past` or `all`; `req.query.date` must be `YYYY-MM-DD`; `req.query.location` is a partial place name; `req.query.category` must be digits.
 * @param {express.Response} res - The Express response.
 * @returns {Promise<void>} A promise that resolves once the JSON array has been sent.
 * @throws {Error} If the query fails; Express 5 forwards the rejection to the `module:server` error handler, which answers 500.
 * @remarks
 * Codes returned:
 *
 * - `200` - the matching events, oldest event first (an empty array is a valid answer).
 * - `400` - `status` is not one of the three words, `date` is not a real day, or `category` is not numeric. Each case names the field in `error`.
 *
 * `location` is escaped before it is bound: `%` and `_` are LIKE wildcards, so a
 * visitor searching for `%` would otherwise match every event in the table.
 * @see module:event_model~searchEvents
 * @example
 * // GET /api/events?status=all&category=1&location=lismore  ->  200 OK
 * [ { "event_id": 1, "name": "Coastal Sunrise Fun Run", "display_status": "active", ... } ]
 *
 * // GET /api/events?status=banana  ->  400 Bad Request
 * { "error": "Please pick a valid status." }
 */
router.get('/', async function (req, res) {
  const filters = {};

  if (req.query.status !== undefined && req.query.status !== '') {
    if (['upcoming', 'past', 'all'].indexOf(req.query.status) === -1) {
      return res.status(400).json({ error: 'Please pick a valid status.' });
    }
    filters.status = req.query.status;
  } else {
    filters.status = 'upcoming';
  }

  if (req.query.date !== undefined && req.query.date !== '') {
    const date = validation.normaliseDate(req.query.date);
    if (date === null) {
      return res.status(400).json({ error: 'Please pick a valid date.' });
    }
    filters.date = date;
  }

  if (req.query.location !== undefined && req.query.location !== '') {
    // escape the LIKE wildcards so a search for "%" does not match everything
    const place = String(req.query.location).replace(/%/g, '\\%').replace(/_/g, '\\_').trim();
    if (place.length > 0) {
      filters.location = place;
    }
  }

  if (req.query.category !== undefined && req.query.category !== '') {
    if (/^[0-9]+$/.test(req.query.category) === false) {
      return res.status(400).json({ error: 'Please pick a category from the list.' });
    }
    filters.category = req.query.category;
  }

  const events = await model.searchEvents(filters);
  res.json(events);
});

/**
 * `GET /api/events/:id` - one event together with its registrations.
 *
 * The improved endpoint of Part 2: it returns the event AND the complete list
 * of registrations for that event, so the client detail page needs one call
 * instead of two. The registrations come newest first.
 *
 * @function getEventDetailHandler
 * @async
 * @param {express.Request} req - The Express request; `req.params.id` is the event id.
 * @param {express.Response} res - The Express response.
 * @returns {Promise<void>} A promise that resolves once the JSON object has been sent.
 * @throws {Error} If a query fails; Express 5 forwards the rejection to the `module:server` error handler, which answers 500.
 * @remarks
 * Codes returned:
 *
 * - `200` - `{ event, registrations, summary }`, where `event` carries the derived `display_status` and `summary` holds `registration_count`, `tickets_sold`, `amount_registered` and `latest_registration`.
 * - `400` - the id is not a positive whole number.
 * - `404` - there is no such event, or it is suspended and therefore not published.
 *
 * The email address and phone number of a member of the public are masked here
 * because this endpoint is open to everyone; the admin endpoint returns them.
 * @see module:event_model~getEventById
 * @see module:event_model~publicRegistration
 * @see module:routes/admin - `GET /api/admin/events/:id`, the staff view
 * @example
 * // GET /api/events/1  ->  200 OK
 * {
 *   "event": { "event_id": 1, "name": "Coastal Sunrise Fun Run", "display_status": "active", ... },
 *   "registrations": [ { "registration_id": 1, "email": "a***n@example.com", "phone": "hidden", ... } ],
 *   "summary": { "registration_count": 5, "tickets_sold": 11, ... }
 * }
 */
router.get('/:id', async function (req, res) {
  const id = parseId(req.params.id);
  if (id === null) {
    return res.status(400).json({ error: 'A valid event ID is required.' });
  }

  const event = await model.getEventById(id);
  if (!event) {
    return res.status(404).json({ error: 'This event could not be found.' });
  }

  const rows = await model.getRegistrationsForEvent(id);
  const summary = await model.getRegistrationSummary(id);

  res.json({
    event: event,
    registrations: rows.map(function (row) {
      return model.publicRegistration(row, true);
    }),
    summary: summary
  });
});

/**
 * `GET /api/events/:id/registrations` - just the registration list.
 *
 * @function getEventRegistrationsHandler
 * @async
 * @param {express.Request} req - The Express request; `req.params.id` is the event id.
 * @param {express.Response} res - The Express response.
 * @returns {Promise<void>} A promise that resolves once the JSON object has been sent.
 * @throws {Error} If a query fails; Express 5 forwards the rejection to the `module:server` error handler, which answers 500.
 * @remarks
 * Codes returned:
 *
 * - `200` - `{ registrations, summary }`, masked exactly like the detail endpoint.
 * - `400` - the id is not a positive whole number.
 * - `404` - the event does not exist, including the suspended ones.
 *
 * This exists so a page that only needs the list (for example a refresh after a
 * registration) does not have to re-read the event.
 * @see module:event_model~getRegistrationsForEvent
 */
router.get('/:id/registrations', async function (req, res) {
  const id = parseId(req.params.id);
  if (id === null) {
    return res.status(400).json({ error: 'A valid event ID is required.' });
  }
  if ((await model.eventExists(id)) === false) {
    return res.status(404).json({ error: 'This event could not be found.' });
  }

  const rows = await model.getRegistrationsForEvent(id);
  res.json({
    registrations: rows.map(function (row) {
      return model.publicRegistration(row, true);
    }),
    summary: await model.getRegistrationSummary(id)
  });
});

/**
 * `POST /api/events/:id/registrations` - buy tickets for an event.
 *
 * The registration page of the client website calls this.
 *
 * @function createRegistrationHandler
 * @async
 * @param {express.Request} req - The Express request; `req.params.id` is the event id and `req.body` holds `first_name`, `last_name`, `email`, `phone`, `tickets` and optionally `notes`.
 * @param {express.Response} res - The Express response.
 * @returns {Promise<void>} A promise that resolves once the JSON object has been sent.
 * @throws {Error} If an unexpected database error occurs; Express 5 forwards the rejection to the `module:server` error handler, which answers 500.
 * @remarks
 * Codes returned, and why:
 *
 * - `201` - the registration was stored; the body repeats the server-computed total so the page can show a confirmation.
 * - `400` - the id is invalid, or the body failed `module:validation`; `fields` maps each broken field to its message.
 * - `404` - the event does not exist.
 * - `409` - the event is suspended, the event has already taken place, or this email address has already registered for this event. A suspended or finished event is refused before the body is even looked at, because nothing the visitor types can make it bookable.
 *
 * The duplicate is checked twice on purpose: a friendly pre-check answers the
 * normal case, and the `UNIQUE` key on `(event_id, email)` is caught here for
 * the race where two requests arrive together.
 * @see module:validation~validateRegistration
 * @see module:event_model~createRegistration
 * @example
 * // POST /api/events/4/registrations  {"tickets": 2, ...}  ->  201 Created
 * {
 *   "message": "Thank you, your registration has been received.",
 *   "registration": { "registration_id": 13, "event_id": 4, "event_name": "Songs for Shelter", "tickets": 2, "total_amount": 90 }
 * }
 *
 * // the same email again  ->  409 Conflict
 * { "error": "This email address has already registered for this event." }
 */
router.post('/:id/registrations', async function (req, res) {
  const id = parseId(req.params.id);
  if (id === null) {
    return res.status(400).json({ error: 'A valid event ID is required.' });
  }

  const event = await model.getEventForRegistration(id);
  if (!event) {
    return res.status(404).json({ error: 'This event could not be found.' });
  }
  if (event.status === 'suspended') {
    return res.status(409).json({ error: 'This event is currently suspended and is not open for registration.' });
  }
  if (event.is_past === true) {
    return res.status(409).json({ error: 'This event has already taken place.' });
  }

  const checked = validation.validateRegistration(req.body || {});
  if (Object.keys(checked.errors).length > 0) {
    return res.status(400).json({
      error: 'Please correct the highlighted fields.',
      fields: checked.errors
    });
  }

  // "can only register for an event once" - checked first so the user gets a
  // friendly 409 instead of a raw duplicate-key database error
  const existing = await model.findRegistration(id, checked.data.email);
  if (existing) {
    return res.status(409).json({
      error: 'This email address has already registered for this event.'
    });
  }

  let created;
  try {
    created = await model.createRegistration(id, checked.data);
  } catch (err) {
    // the UNIQUE key is the final guard if two requests arrive together
    if (err && err.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({
        error: 'This email address has already registered for this event.'
      });
    }
    throw err;
  }

  res.status(201).json({
    message: 'Thank you, your registration has been received.',
    registration: {
      registration_id: created.registration_id,
      event_id: id,
      event_name: event.name,
      tickets: checked.data.tickets,
      total_amount: created.total_amount
    }
  });
});

/**
 * `POST /api/events` - the admin "New event" form.
 *
 * @function createEventHandler
 * @async
 * @param {express.Request} req - The Express request; `req.body` is the whole event, see {@link module:event_model~EventInput}.
 * @param {express.Response} res - The Express response.
 * @returns {Promise<void>} A promise that resolves once the JSON object has been sent.
 * @throws {Error} If the insert fails; Express 5 forwards the rejection to the `module:server` error handler, which answers 409 for a foreign-key violation and 500 otherwise.
 * @remarks
 * Codes returned:
 *
 * - `201` - `{ message, event_id }` with the id MySQL assigned, so the admin page can immediately open or edit the new event.
 * - `400` - `module:validation` rejected one or more fields; `fields` maps each broken field to its message.
 *
 * The body is validated in full mode (`partial === false`), so any field the
 * form leaves out is stored with its documented default rather than `NULL`.
 * @see module:validation~validateEvent
 * @see module:event_model~createEvent
 * @example
 * // POST /api/events  {"category_id": 1, "name": "A3 Test Fun Run", ...}  ->  201 Created
 * { "message": "The event was created.", "event_id": 9 }
 */
router.post('/', async function (req, res) {
  const checked = validation.validateEvent(req.body || {}, false);
  if (Object.keys(checked.errors).length > 0) {
    return res.status(400).json({
      error: 'Please correct the highlighted fields.',
      fields: checked.errors
    });
  }

  const newId = await model.createEvent(checked.data);
  res.status(201).json({
    message: 'The event was created.',
    event_id: newId
  });
});

/**
 * `PUT /api/events/:id` - the admin "Update event" form.
 *
 * @function updateEventHandler
 * @async
 * @param {express.Request} req - The Express request; `req.params.id` is the event id and `req.body` holds only the fields the staff member changed.
 * @param {express.Response} res - The Express response.
 * @returns {Promise<void>} A promise that resolves once the JSON object has been sent.
 * @throws {Error} If the update fails; Express 5 forwards the rejection to the `module:server` error handler, which answers 409 for a foreign-key violation and 500 otherwise.
 * @remarks
 * Codes returned:
 *
 * - `200` - `{ message, event_id }`; the fields that were not sent keep their stored values.
 * - `400` - an invalid id, a field that failed `module:validation`, or a body that contained no field this API knows about ("There was nothing to update.").
 * - `404` - the event does not exist; checked before anything is written.
 *
 * The body is validated in partial mode (`partial === true`), which is what
 * makes a one-field update possible without wiping the rest of the row.
 * @see module:validation~validateEvent
 * @see module:event_model~updateEvent
 * @example
 * // PUT /api/events/9  {"ticket_price": 30, "status": "suspended"}  ->  200 OK
 * { "message": "The event was updated.", "event_id": 9 }
 */
router.put('/:id', async function (req, res) {
  const id = parseId(req.params.id);
  if (id === null) {
    return res.status(400).json({ error: 'A valid event ID is required.' });
  }
  if ((await model.eventExists(id)) === false) {
    return res.status(404).json({ error: 'This event could not be found.' });
  }

  const checked = validation.validateEvent(req.body || {}, true);
  if (Object.keys(checked.errors).length > 0) {
    return res.status(400).json({
      error: 'Please correct the highlighted fields.',
      fields: checked.errors
    });
  }
  if (Object.keys(checked.data).length === 0) {
    return res.status(400).json({ error: 'There was nothing to update.' });
  }

  await model.updateEvent(id, checked.data);
  res.json({ message: 'The event was updated.', event_id: id });
});

/**
 * `DELETE /api/events/:id` - delete an event that has no registrations.
 *
 * @function deleteEventHandler
 * @async
 * @param {express.Request} req - The Express request; `req.params.id` is the event id.
 * @param {express.Response} res - The Express response.
 * @returns {Promise<void>} A promise that resolves once the JSON object has been sent.
 * @throws {Error} If the transactional delete fails; Express 5 forwards the rejection to the `module:server` error handler, which answers 500.
 * @remarks
 * Data integrity: an event that already has registrations is NOT deleted.
 * A `409 Conflict` is returned together with the number of registrations, so
 * the admin page can explain why the delete was blocked.
 *
 * Codes returned:
 *
 * - `200` - `{ message, event_id }`; the row is gone.
 * - `400` - the id is not a positive whole number.
 * - `404` - the event does not exist.
 * - `409` - the event has registrations; `registration_count` carries the number so the page can say so without another request.
 *
 * The check-and-delete pair runs in one transaction inside
 * {@link module:event_model~deleteEventSafely}, so two admins clicking Delete
 * at once cannot both succeed.
 * @see module:event_model~deleteEventSafely
 * @example
 * // DELETE /api/events/9  ->  200 OK
 * { "message": "The event was deleted.", "event_id": 9 }
 *
 * // DELETE /api/events/1 (it has 5 registrations)  ->  409 Conflict
 * { "error": "This event cannot be deleted because it already has 5 registration(s).",
 *   "registration_count": 5 }
 */
router.delete('/:id', async function (req, res) {
  const id = parseId(req.params.id);
  if (id === null) {
    return res.status(400).json({ error: 'A valid event ID is required.' });
  }

  const outcome = await model.deleteEventSafely(id);

  if (outcome.result === 'not_found') {
    return res.status(404).json({ error: 'This event could not be found.' });
  }
  if (outcome.result === 'has_registrations') {
    return res.status(409).json({
      error: 'This event cannot be deleted because it already has ' +
        outcome.registrationCount + ' registration(s).',
      registration_count: outcome.registrationCount
    });
  }

  res.json({ message: 'The event was deleted.', event_id: id });
});

/**
 * The exported router, mounted by {@link module:server} at `/api/events`.
 *
 * @type {express.Router}
 */
module.exports = router;
