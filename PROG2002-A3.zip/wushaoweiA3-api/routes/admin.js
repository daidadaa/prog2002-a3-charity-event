/**
 * PROG2002 Web Development II - Assessment 3 (WU Shao Wei).
 *
 * @module routes/admin
 * @description
 * The endpoints the admin-side website uses, mounted by {@link module:server}
 * at `/api/admin`.
 *
 * @remarks
 * The public endpoints hide suspended events, but the staff interface has to
 * show every event "regardless of their status (Active, Past, Suspended)", so
 * the admin resource is kept separate under `/api/admin`.
 *
 * There is no log in (the brief says authentication is not required), but
 * keeping the admin routes in their own namespace makes it obvious which
 * endpoints would need protecting in a real deployment.
 *
 * The route table:
 *
 * ```text
 *   GET /api/admin/events       every event, with its counters
 *   GET /api/admin/events/:id   one event of any status + the real registration list
 * ```
 *
 * @see module:routes/events - the public equivalent, which masks personal details and hides suspended events
 * @see module:event_model - the SQL these handlers call
 */

const express = require('express');

/**
 * The router for the `/api/admin` prefix.
 *
 * @constant {express.Router}
 */
const router = express.Router();
const model = require('../event_model');

/**
 * Parses an id from the URL.
 *
 * @function parseId
 * @param {string} value - The raw `req.params.id` text.
 * @returns {number|null} The id as a positive whole number, or `null` when the text is not one (the caller answers `400`).
 * @remarks
 * Deliberately the same rule as `module:routes/events~parseId`. The duplication
 * is a few lines and keeps each router self-contained; if a third router ever
 * needs it, it belongs in a shared helper instead.
 * @see module:routes/events~parseId
 * @example
 * parseId('3');   // 3
 * parseId('3.0'); // null
 */
function parseId(value) {
  if (/^[0-9]+$/.test(value) === false) {
    return null;
  }
  const id = Number(value);
  return id > 0 ? id : null;
}

/**
 * `GET /api/admin/events` - the staff event list.
 *
 * Every event, with the number of registrations and tickets sold, so the list
 * page and the delete button know what they are dealing with.
 *
 * @function getAllEventsForAdminHandler
 * @async
 * @param {express.Request} req - The Express request; no query string parameters are used.
 * @param {express.Response} res - The Express response.
 * @returns {Promise<void>} A promise that resolves once the JSON array has been sent.
 * @throws {Error} If the query fails; Express 5 forwards the rejection to the `module:server` error handler, which answers 500.
 * @remarks
 * Codes returned: `200` with the array, never `404` - an empty table is a valid,
 * empty list. Each element carries `display_status` (`active`, `past` or
 * `suspended`), `registration_count` and `tickets_sold`.
 * @see module:event_model~getAllEventsForAdmin
 * @example
 * // GET /api/admin/events  ->  200 OK
 * [ { "event_id": 1, "name": "Coastal Sunrise Fun Run", "display_status": "active",
 *     "registration_count": 5, "tickets_sold": 11, ... } ]
 */
router.get('/events', async function (req, res) {
  const events = await model.getAllEventsForAdmin();
  res.json(events);
});

/**
 * `GET /api/admin/events/:id` - one event of any status, with the full registration list.
 *
 * One event of any status, together with the full registration list (real email
 * addresses, because this is the staff view). The update form uses this so the
 * staff member can see who has registered before changing the event.
 *
 * @function getAdminEventHandler
 * @async
 * @param {express.Request} req - The Express request; `req.params.id` is the event id.
 * @param {express.Response} res - The Express response.
 * @returns {Promise<void>} A promise that resolves once the JSON object has been sent.
 * @throws {Error} If a query fails; Express 5 forwards the rejection to the `module:server` error handler, which answers 500.
 * @remarks
 * Codes returned:
 *
 * - `200` - `{ event, registrations, summary }`. The event is included even when it is suspended or already past, and the registrations carry the real email address and phone number because this is the staff view.
 * - `400` - the id is not a positive whole number.
 * - `404` - there is no such event.
 *
 * The personal details are unmasked by passing `false` to
 * {@link module:event_model~publicRegistration}, which is the whole difference
 * from the public `GET /api/events/:id`.
 * @see module:event_model~getAdminEventById
 * @see module:event_model~publicRegistration
 * @example
 * // GET /api/admin/events/1  ->  200 OK
 * {
 *   "event": { "event_id": 1, "display_status": "active", "registration_count": 5, ... },
 *   "registrations": [ { "registration_id": 1, "email": "amelia.nguyen@example.com", "phone": "0400 111 222", ... } ],
 *   "summary": { "registration_count": 5, "tickets_sold": 11, ... }
 * }
 */
router.get('/events/:id', async function (req, res) {
  const id = parseId(req.params.id);
  if (id === null) {
    return res.status(400).json({ error: 'A valid event ID is required.' });
  }

  const event = await model.getAdminEventById(id);
  if (!event) {
    return res.status(404).json({ error: 'This event could not be found.' });
  }

  const rows = await model.getRegistrationsForEvent(id);
  res.json({
    event: event,
    registrations: rows.map(function (row) {
      return model.publicRegistration(row, false);
    }),
    summary: await model.getRegistrationSummary(id)
  });
});

/**
 * The exported router, mounted by {@link module:server} at `/api/admin`.
 *
 * @type {express.Router}
 */
module.exports = router;
