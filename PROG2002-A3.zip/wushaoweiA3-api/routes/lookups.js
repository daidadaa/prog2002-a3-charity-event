/**
 * PROG2002 Web Development II - Assessment 3 (WU Shao Wei).
 *
 * @module routes/lookups
 * @description
 * The small reference lists the search form needs, mounted by
 * {@link module:server} at `/api`.
 *
 * @remarks
 * The route table:
 *
 * ```text
 *   GET /api/categories    the categories for the dropdown
 *   GET /api/event-dates   the days that have an upcoming event, for the date list
 * ```
 *
 * Only GET is needed here, and the brief says category and registration
 * manipulation endpoints are not required. Both endpoints are public and both
 * answer an array, so there is no `404` case: a list with no rows is `200 []`
 * and the Angular pages render an empty dropdown.
 *
 * Because these paths are mounted at `/api` itself, they sit alongside
 * `/api/events`, `/api/admin` and `/api/weather` without colliding.
 *
 * @see module:event_model~getCategories
 * @see module:event_model~getEventDates
 * @see module:routes/events - the search page that consumes both lists
 */

const express = require('express');

/**
 * The router for the two lookup paths, mounted at `/api`.
 *
 * @constant {express.Router}
 */
const router = express.Router();
const model = require('../event_model');

/**
 * `GET /api/categories` - every category, for the search dropdown.
 *
 * @function getCategoriesHandler
 * @async
 * @param {express.Request} req - The Express request; no parameters are used.
 * @param {express.Response} res - The Express response.
 * @returns {Promise<void>} A promise that resolves once the JSON array has been sent.
 * @throws {Error} If the query fails; Express 5 forwards the rejection to the `module:server` error handler, which answers 500.
 * @remarks
 * Codes returned: `200` with an array of `{ category_id, name, description }`,
 * ordered by name. The Angular search form binds the id to the same `category`
 * query string that `GET /api/events` validates.
 * @example
 * // GET /api/categories  ->  200 OK
 * [ { "category_id": 1, "name": "Sport", "description": "..." }, ... ]
 */
router.get('/categories', async function (req, res) {
  const categories = await model.getCategories();
  res.json(categories);
});

/**
 * `GET /api/event-dates` - the days that have an upcoming active event.
 *
 * @function getEventDatesHandler
 * @async
 * @param {express.Request} req - The Express request; no parameters are used.
 * @param {express.Response} res - The Express response.
 * @returns {Promise<void>} A promise that resolves once the JSON array has been sent.
 * @throws {Error} If the query fails; Express 5 forwards the rejection to the `module:server` error handler, which answers 500.
 * @remarks
 * Codes returned: `200` with an array of `YYYY-MM-DD` strings, earliest first.
 * Suspended events are excluded, so the date list can never offer a day that
 * the search itself would then refuse to show.
 * @example
 * // GET /api/event-dates  ->  200 OK
 * [ "2026-10-15", "2026-11-01", ... ]
 */
router.get('/event-dates', async function (req, res) {
  const days = await model.getEventDates();
  res.json(days);
});

/**
 * The exported router, mounted by {@link module:server} at `/api`.
 *
 * @type {express.Router}
 */
module.exports = router;
