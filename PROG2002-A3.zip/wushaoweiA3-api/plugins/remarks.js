/**
 * A tiny JSDoc plugin that teaches jsdoc the `@remarks` tag.
 *
 * `@remarks` (the tag the assessment feedback asks for, and the one TSDoc uses)
 * is not part of jsdoc's own tag dictionary, so without this plugin jsdoc
 * accepts the tag and then silently throws its text away - the design rationale
 * and the ASCII architecture diagrams would never reach `docs/api`.
 *
 * The plugin registers the tag and appends its text to the doclet's
 * `description`, which is the one property the default template always renders.
 * The markdown plugin runs later (`parseComplete`), so the appended markdown and
 * fenced code blocks are converted like the rest of the description.
 *
 * It is a build-time helper only: nothing in `server.js`, `event_model.js` or
 * the routes depends on it, and the API behaves identically with or without it.
 */
exports.defineTags = function (dictionary) {
  dictionary.defineTag('remarks', {
    canHaveType: false,
    canHaveName: false,
    onTagged: function (doclet, tag) {
      const text = (tag.text || '').trim();
      if (text.length === 0) {
        return;
      }
      doclet.remarks = doclet.remarks ? doclet.remarks + '\n\n' + text : text;
      doclet.description = doclet.description
        ? doclet.description + '\n\n' + text
        : text;
    }
  });
};
