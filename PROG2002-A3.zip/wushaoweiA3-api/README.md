# Charity events API - PROG2002 Assessment 3

WU Shao Wei

The Node.js, Express and MySQL back end for the Assessment 3 charity event
website. It serves the client-side website, the admin-side website and the
optional Open-Meteo weather lookup.

## What changed since Assessment 2

| | Assessment 2 | Assessment 3 |
|---|---|---|
| Database | `organisations`, `categories`, `events` | + **`registrations`** table, and `latitude` / `longitude` on `events` |
| Connection | one `createConnection` | a **pool** (`mysql2`) with `async` / `await` |
| HTTP methods | GET only | full C.R.U.D. (`GET`, `POST`, `PUT`, `DELETE`) |
| Event detail | just the event | the event **plus its registrations** (`registration_date` newest first) |
| Deleting an event | not possible | possible, but **blocked with 409** when registrations exist |
| Extra | - | `/api/weather/:eventId` proxy to Open-Meteo |
| Validation | query strings only | a shared `validation.js` for events and registrations |

## How to run it

1. Import the database. Open `charityevents_db.sql` in MySQL Workbench and run
   the whole file. It creates `charityevents_db` with four tables and the sample
   data (8 events, 12 registrations).

   > There are two SQL files on purpose:
   >
   > | File | Use it for |
   > |---|---|
   > | `charityevents_db.sql` | your own MySQL / MySQL Workbench. It starts with `DROP DATABASE` and `CREATE DATABASE`, so it builds the database from nothing. This is the file the marker runs. |
   > | `charityevents_db_cpanel.sql` | the **SCU cPanel** import. A cPanel account may not run `CREATE DATABASE`, and its database name carries an account prefix, so this copy keeps only the tables and the data. Create the database in the cPanel panel first, then import this file into it with phpMyAdmin. |
   >
   > See `../DEPLOYMENT-GUIDE.md` step 3 for the full sequence.
2. In this folder:

   ```
   npm install
   ```

3. Copy `.env.example` to `.env` and put your own MySQL password in it.
4. Start the server:

   ```
   npm start
   ```

5. Check it: <http://localhost:3000/api/health> and
   <http://localhost:3000/api/events/home>

The API listens on port 3000 by default. The Angular websites run on 4200 and
4300 during development, which is why the server sends CORS headers.

## API documentation (JSDoc / autodoc)

Every source file is documented in JSDoc style (`/** ... */` directly above the
declaration it describes), so the HTML reference is generated from the code
rather than written by hand.

```
npm run docs
```

That runs `jsdoc -c jsdoc.json` and writes the site to `docs/api`
(open `docs/api/index.html`). The generated HTML is **not committed** -
`docs/` is in `.gitignore` - because it is a build product that `npm run docs`
recreates at any time.

The comments use `@module` and `@description` for the file, `@param`,
`@returns`, `@throws`, `@async` and `@example` on the functions, `@typedef` /
`@property` for the plain object shapes the model returns, `@see` to
cross-reference related files, and `@remarks` for the design rationale and the
architecture diagrams.

`plugins/remarks.js` is a small local jsdoc plugin: jsdoc does not know the
`@remarks` tag, so without it the rationale and the diagrams would be accepted
and then silently dropped from the generated pages. It is a build-time helper
only and has no effect on the running API.

## Endpoints

### Public (used by the client-side website)

| Method | URL | What it does |
|---|---|---|
| GET | `/api/health` | a small status check |
| GET | `/api/events/home` | active events from today onwards |
| GET | `/api/events` | search. Optional: `status` (`upcoming` default, `past`, `all`), `date` (`YYYY-MM-DD`), `location` (part of a place name), `category` (a category id). They combine. |
| GET | `/api/events/:id` | **the improved endpoint**: `{ event, registrations, summary }`. Registrations are newest first and the email address is masked. Suspended events are never returned. |
| GET | `/api/events/:id/registrations` | just the registration list and the totals |
| POST | `/api/events/:id/registrations` | register for an event (buy tickets) |
| GET | `/api/categories` | the categories for the search dropdown |
| GET | `/api/event-dates` | the days that have an upcoming event |
| GET | `/api/weather/:eventId` | 5 day Open-Meteo forecast for the event location, with `weather_code` translated into words. Cached for 15 minutes. |

### Admin (used by the admin-side website)

| Method | URL | What it does |
|---|---|---|
| GET | `/api/admin/events` | **every** event, any status, with its registration count and tickets sold |
| GET | `/api/admin/events/:id` | one event of any status plus the full registration list (real email addresses, staff view) |
| POST | `/api/events` | create a charity event |
| PUT | `/api/events/:id` | update a charity event (partial update) |
| DELETE | `/api/events/:id` | delete a charity event - see the rule below |

### POST /api/events/:id/registrations - request and response

Request body:

```json
{
  "first_name": "Amelia",
  "last_name": "Nguyen",
  "email": "amelia.nguyen@example.com",
  "phone": "0400 111 201",
  "tickets": 2,
  "notes": "Running with a friend."
}
```

`total_amount` is **not** accepted from the browser. The server calculates it
from the ticket price stored in the database.

Success (`201`):

```json
{
  "message": "Thank you, your registration has been received.",
  "registration": {
    "registration_id": 13,
    "event_id": 4,
    "event_name": "Songs for Shelter",
    "tickets": 2,
    "total_amount": 90
  }
}
```

### The delete rule (data integrity)

An event **can only be deleted when it has no registrations**.

* `DELETE /api/events/4` on an event with no registrations -> `200`
* `DELETE /api/events/1` on an event with 5 registrations -> `409`

```json
{
  "error": "This event cannot be deleted because it already has 5 registration(s).",
  "registration_count": 5
}
```

The check and the delete run inside one transaction and the event row is locked
with `SELECT ... FOR UPDATE`. The `ON DELETE RESTRICT` foreign key on
`registrations.event_id` is the second guard, so the rule also holds if someone
edits the database by hand.

## Status codes

| Code | Meaning |
|---|---|
| 200 | the request worked |
| 201 | a new event or registration was created |
| 400 | a value had the wrong format, or a form field was missing (`fields` lists them) |
| 404 | the event does not exist, or is suspended when the public page asks for it |
| 409 | the rule was broken: duplicate registration, registering for a past or suspended event, or deleting an event that has registrations |
| 422 | the event has no coordinates, so the weather cannot be looked up |
| 500 | the server or the database failed |
| 502 | Open-Meteo could not be reached |

## Security and design notes

* Every SQL statement uses `?` placeholders, so nothing from the browser is
  written into the SQL text.
* The public event detail endpoint **masks** the email address and hides the
  phone number of the people who registered; only `/api/admin/events/:id`
  returns them.
* There is no login, as the brief says authentication is not required. The admin
  endpoints live under `/api/admin` so it is obvious which routes would need
  protecting in a real deployment.
* Validation is shared (`validation.js`) so the create form and the update form
  cannot disagree, and the database has `CHECK` and `UNIQUE` constraints as the
  final guard.
