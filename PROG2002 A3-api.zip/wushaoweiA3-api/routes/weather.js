/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * routes/weather.js
 *
 * @module routes/weather
 * @file routes/weather.js
 */

const express = require('express');

/**
 * The router for the `/api/weather` prefix.
 *
 * @constant {express.Router}
 */
const router = express.Router();
const model = require('../event_model');

/**
 * How long a cached forecast stays fresh, in minutes.
 *
 * @constant {number}
 * @default 15
 * @remarks
 * Long enough to absorb a page being refreshed repeatedly, short enough that a
 * forecast is never more than a quarter of an hour stale.
 */
const CACHE_MINUTES = 15;

/**
 * How long to wait for api.open-meteo.com before giving up, in milliseconds.
 *
 * @constant {number}
 * @default 8000
 * @remarks
 * `fetch` does not time out on its own. If the upstream service accepted the
 * connection and then stopped answering, the request would hang and the browser
 * would wait with it. A normal round trip is about 300 ms, so 8 seconds is far
 * above anything healthy while still being short enough that a visitor never
 * notices - and the handler turns the timeout into the same `502` a refused
 * connection produces, so the rest of the event page keeps working.
 * @see module:routes/weather~getEventWeather
 */
const UPSTREAM_TIMEOUT_MS = 8000;

/**
 * The in-memory forecast cache, keyed by event id.
 *
 * @constant {Object<number, {payload: WeatherForecast, expires: number}>}
 * @remarks
 * `expires` is an absolute `Date.now()` millisecond stamp, which is why the
 * handler compares it with `>` rather than counting down. A process restart
 * simply empties the cache; nothing is persisted, and the API does not require
 * the upstream service to be reachable in order to start.
 * @see module:routes/weather~getEventWeather
 */
const cache = {};

/**
 * One forecast day of the translated payload.
 *
 * @typedef {object} WeatherDay
 * @property {string} date - The day, `YYYY-MM-DD`.
 * @property {number} weather_code - The raw WMO code from Open-Meteo.
 * @property {string} description - The code in words, for example `Rain: slight`.
 * @property {boolean} good_weather - Whether the page should present the day as pleasant.
 * @property {number|null} temperature_max - Maximum temperature, or `null` when the upstream response omitted it.
 * @property {number|null} temperature_min - Minimum temperature, or `null`.
 * @property {number|null} rain_chance - Maximum precipitation probability as a percentage, or `null`.
 */

/**
 * The body of a successful weather response.
 *
 * @typedef {object} WeatherForecast
 * @property {number} event_id - The event the forecast belongs to.
 * @property {string} event_name - Its name, so the page can title the panel.
 * @property {string} location - Its stored location text.
 * @property {number} latitude - The latitude that was queried.
 * @property {number} longitude - The longitude that was queried.
 * @property {string} timezone - The timezone Open-Meteo reported, falling back to `Australia/Sydney`.
 * @property {string} source - Attribution text for the panel.
 * @property {WeatherDay[]} days - Up to five days of forecast.
 */

/**
 * Translates a WMO `weather_code` into words.
 *
 * @function describeWeatherCode
 * @param {number} code - The `weather_code` value from Open-Meteo.
 * @returns {string} The matching description from the table in the assessment brief, or `'Unknown'` for a code the table does not cover.
 * @remarks
 * The table is the one from the assessment brief: `0` clear sky through `99`
 * thunderstorm with heavy hail. Returning `'Unknown'` rather than throwing means
 * a new code added by Open-Meteo degrades to a readable panel instead of a
 * `500`.
 * @see {@link https://open-meteo.com/en/docs} - where the codes are defined
 * @example
 * describeWeatherCode(0);  // 'Clear sky'
 * describeWeatherCode(51); // 'Drizzle: light'
 * describeWeatherCode(7);  // 'Unknown'
 */
function describeWeatherCode(code) {
  const table = {
    0: 'Clear sky',
    1: 'Mainly clear', 2: 'Partly cloudy', 3: 'Overcast',
    45: 'Fog', 48: 'Depositing rime fog',
    51: 'Drizzle: light', 53: 'Drizzle: moderate', 55: 'Drizzle: dense',
    56: 'Freezing drizzle: light', 57: 'Freezing drizzle: dense',
    61: 'Rain: slight', 63: 'Rain: moderate', 65: 'Rain: heavy',
    66: 'Freezing rain: light', 67: 'Freezing rain: heavy',
    71: 'Snow fall: slight', 73: 'Snow fall: moderate', 75: 'Snow fall: heavy',
    77: 'Snow grains',
    80: 'Rain showers: slight', 81: 'Rain showers: moderate', 82: 'Rain showers: violent',
    85: 'Snow showers: slight', 86: 'Snow showers: heavy',
    95: 'Thunderstorm: slight or moderate',
    96: 'Thunderstorm with slight hail', 99: 'Thunderstorm with heavy hail'
  };
  return table[code] || 'Unknown';
}

/**
 * Decides whether a forecast day is pleasant enough to highlight.
 *
 * @function isGoodWeather
 * @param {number} code - The `weather_code` value from Open-Meteo.
 * @returns {boolean} `true` for clear sky, mainly clear, partly cloudy or overcast; `false` for anything with fog, drizzle, rain, snow or a thunderstorm.
 * @remarks
 * A tiny yes/no for the page. The threshold is deliberately generous - overcast
 * still counts as good - because the flag only drives the wording of the panel,
 * not any decision.
 * @example
 * isGoodWeather(2);  // true
 * isGoodWeather(61); // false
 */
function isGoodWeather(code) {
  return [0, 1, 2, 3].indexOf(code) !== -1;
}

/**
 * Parses the event id from the URL.
 *
 * @function parseId
 * @param {string} value - The raw `req.params.eventId` text.
 * @returns {number|null} The id as a positive whole number, or `null` when the text is not one (the caller answers `400`).
 * @see module:routes/events~parseId
 */
function parseId(value) {
  if (/^[0-9]+$/.test(value) === false) {
    return null;
  }
  const id = Number(value);
  return id > 0 ? id : null;
}

/**
 * `GET /api/weather/:eventId` - the cached Open-Meteo forecast for one event.
 *
 * @function getEventWeather
 * @async
 * @param {express.Request} req - The Express request; `req.params.eventId` is the event id.
 * @param {express.Response} res - The Express response.
 * @returns {Promise<void>} A promise that resolves once the JSON object has been sent (the handler never returns the payload itself).
 * @throws {Error} If a database query fails; Express 5 forwards that rejection to the `module:server` error handler, which answers 500. A failure of the upstream weather service never throws - it is answered as `502` below.
 * @remarks
 * Codes returned, and why:
 *
 * - `200` - the forecast, either from the cache or freshly translated. `days` may be empty if Open-Meteo answered without a `daily` block.
 * - `400` - `eventId` is not a positive whole number.
 * - `404` - there is no such event.
 * - `422` - the event exists but its coordinates are still `(0, 0)`, which is the value `module:validation` stores when the admin form leaves them empty. There is nothing sensible to look up, so the page is told why rather than being shown the weather for the Gulf of Guinea.
 * - `502` - Open-Meteo answered with a non-OK status, or could not be reached at all. The site has to keep working even when the internet is down, so the failure is reported as JSON instead of crashing the request.
 * @see module:event_model~getEventCoordinates
 * @see module:routes/weather~describeWeatherCode
 * @example
 * // GET /api/weather/1  ->  200 OK
 * {
 *   "event_id": 1, "event_name": "Coastal Sunrise Fun Run", "location": "Lismore, NSW",
 *   "latitude": -28.81, "longitude": 153.28, "timezone": "Australia/Sydney",
 *   "source": "Open-Meteo (api.open-meteo.com)",
 *   "days": [ { "date": "2026-10-15", "weather_code": 51, "description": "Drizzle: light",
 *               "good_weather": false, "temperature_max": 21.5, "temperature_min": 12.1,
 *               "rain_chance": 40 } ]
 * }
 *
 * // GET /api/weather/9 (no coordinates yet)  ->  422 Unprocessable Entity
 * { "error": "This event has no coordinates yet, so the weather cannot be looked up.",
 *   "event_id": 9 }
 */
router.get('/:eventId', async function (req, res) {
  const id = parseId(req.params.eventId);
  if (id === null) {
    return res.status(400).json({ error: 'A valid event ID is required.' });
  }

  const event = await model.getEventCoordinates(id);
  if (!event) {
    return res.status(404).json({ error: 'This event could not be found.' });
  }

  const latitude = Number(event.latitude);
  const longitude = Number(event.longitude);
  if (latitude === 0 && longitude === 0) {
    return res.status(422).json({
      error: 'This event has no coordinates yet, so the weather cannot be looked up.',
      event_id: id
    });
  }

  // cached?
  const cached = cache[id];
  if (cached && cached.expires > Date.now()) {
    return res.json(cached.payload);
  }

  const url =
    'https://api.open-meteo.com/v1/forecast' +
    '?latitude=' + latitude +
    '&longitude=' + longitude +
    '&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max' +
    '&timezone=Australia%2FSydney' +
    '&forecast_days=5';

  let forecast;
  try {
    // The timeout matters as much as the try/catch. `fetch` has no default
    // timeout, so if api.open-meteo.com accepts the connection and then stops
    // answering, this request - and the HTTP request from the browser that is
    // waiting on it - would hang until the operating system gave up. With a
    // signal the wait is bounded, the catch below turns it into a 502, and the
    // event page shows its "weather unavailable" note while everything else on
    // the page keeps working. 8 seconds is well above the normal round trip
    // (about 300 ms) but short enough that a visitor never waits on it.
    const response = await fetch(url, { signal: AbortSignal.timeout(UPSTREAM_TIMEOUT_MS) });
    if (response.ok === false) {
      return res.status(502).json({ error: 'The weather service did not answer correctly.' });
    }
    forecast = await response.json();
  } catch (err) {
    // the site has to keep working even when the internet is down, so a timeout
    // and a refused connection are reported the same way: a 502, never a crash
    return res.status(502).json({ error: 'The weather service could not be reached.' });
  }

  const daily = forecast.daily || {};
  const days = (daily.time || []).map(function (day, index) {
    const code = daily.weather_code[index];
    return {
      date: day,
      weather_code: code,
      description: describeWeatherCode(code),
      good_weather: isGoodWeather(code),
      temperature_max: daily.temperature_2m_max ? daily.temperature_2m_max[index] : null,
      temperature_min: daily.temperature_2m_min ? daily.temperature_2m_min[index] : null,
      rain_chance: daily.precipitation_probability_max ? daily.precipitation_probability_max[index] : null
    };
  });

  const payload = {
    event_id: id,
    event_name: event.name,
    location: event.location,
    latitude: latitude,
    longitude: longitude,
    timezone: forecast.timezone || 'Australia/Sydney',
    source: 'Open-Meteo (api.open-meteo.com)',
    days: days
  };

  cache[id] = {
    payload: payload,
    expires: Date.now() + CACHE_MINUTES * 60 * 1000
  };

  res.json(payload);
});

/**
 * The exported router, mounted by {@link module:server} at `/api/weather`.
 *
 * @type {express.Router}
 */
module.exports = router;
