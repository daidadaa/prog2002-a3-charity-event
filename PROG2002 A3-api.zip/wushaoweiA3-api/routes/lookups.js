/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * The small reference lists the search form needs, mounted by {@link
 * module:server} at `/api`.
 *
 * @module routes/lookups
 * @file routes/lookups.js
 */

const express = require('express');

/**
 * The router for the two lookup paths, mounted at `/api`.
 *
 * @constant {express.Router}
 */
const router = express.Router();
const model = require('../event_model');

/**
 * `GET /api/categories` - every category, for the search dropdown.
 *
 * @function getCategoriesHandler
 * @async
 * @param {express.Request} req - The Express request; no parameters are used.
 * @param {express.Response} res - The Express response.
 * @returns {Promise<void>} A promise that resolves once the JSON array has been sent.
 * @throws {Error} If the query fails; Express 5 forwards the rejection to the `module:server` error handler, which answers 500.
 * @remarks
 * Codes returned: `200` with an array of `{ category_id, name, description }`,
 * ordered by name. The Angular search form binds the id to the same `category`
 * query string that `GET /api/events` validates.
 * @example
 * // GET /api/categories  ->  200 OK
 * [ { "category_id": 1, "name": "Sport", "description": "..." }, ... ]
 */
router.get('/categories', async function (req, res) {
  const categories = await model.getCategories();
  res.json(categories);
});

/**
 * `GET /api/event-dates` - the days that have an upcoming active event.
 *
 * @function getEventDatesHandler
 * @async
 * @param {express.Request} req - The Express request; no parameters are used.
 * @param {express.Response} res - The Express response.
 * @returns {Promise<void>} A promise that resolves once the JSON array has been sent.
 * @throws {Error} If the query fails; Express 5 forwards the rejection to the `module:server` error handler, which answers 500.
 * @remarks
 * Codes returned: `200` with an array of `YYYY-MM-DD` strings, earliest first.
 * Suspended events are excluded, so the date list can never offer a day that
 * the search itself would then refuse to show.
 * @example
 * // GET /api/event-dates  ->  200 OK
 * [ "2026-10-15", "2026-11-01", ... ]
 */
router.get('/event-dates', async function (req, res) {
  const days = await model.getEventDates();
  res.json(days);
});

/**
 * The exported router, mounted by {@link module:server} at `/api`.
 *
 * @type {express.Router}
 */
module.exports = router;
