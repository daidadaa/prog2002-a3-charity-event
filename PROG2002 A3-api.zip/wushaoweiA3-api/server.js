/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * The Express application for the charity events API.
 *
 * @module server
 * @file server.js
 */

const express = require('express');
const eventRoutes = require('./routes/events');
const adminRoutes = require('./routes/admin');
const lookupRoutes = require('./routes/lookups');
const weatherRoutes = require('./routes/weather');

/**
 * The Express application instance that every route module is mounted on.
 *
 * @constant {express.Express}
 */
const app = express();

/**
 * The TCP port the API listens on.
 *
 * @constant {number}
 * @default
 * @remarks
 * Taken from `PORT` in `.env` (see `.env.example`) so the same code works on
 * localhost and on the SCU cPanel, where the host assigns the port.
 */
const port = process.env.PORT || 3000;

/**
 * A folder prefix that has to be removed from the incoming URL, or an empty
 * string when the API is served from the domain root.
 *
 * @constant {string}
 * @default '/a3api'
 * @remarks
 * On the SCU cPanel the Express application is mounted at a sub-URL such as
 * `/a3api`, and Passenger forwards the request with that prefix STILL ATTACHED:
 * a browser asking for `/a3api/api/health` reaches the app as `/a3api/api/health`.
 * Every router below is registered at `/api/...`, so without this the app answers
 * `Cannot GET /a3api/api/health` even though it started correctly.
 *
 * The middleware below trims the prefix, so `/a3api/api/health` is routed as
 * `/api/health` and matches the health endpoint.
 *
 * WHY THE PREFIX IS THE DEFAULT RATHER THAN A REQUIRED ENVIRONMENT VARIABLE:
 * the cPanel mount point is fixed for this deployment, and relying on an
 * environment variable that may not have been saved yet turns one missing setting
 * into a puzzling 404. Defaulting to the real mount means the deployed copy works
 * as uploaded; `BASE_PATH` can still override it (or be set to empty) if the app
 * is ever mounted somewhere else.
 *
 * WHY THIS IS HARMLESS LOCALLY: the middleware only rewrites the URL when it
 * actually STARTS WITH the prefix. A local request for `/api/health` does not, so
 * nothing is sliced and `npm start` plus the marker's own run against
 * `http://localhost:3000` behave exactly as before.
 *
 * An EMPTY environment variable is treated as "not set", because a cPanel
 * environment row saved without a value would otherwise silently disable the
 * stripping and bring back the 404. Set `BASE_PATH=/` to switch it off on purpose.
 * @see module:server~stripBasePath
 */
const configuredBasePath = (process.env.BASE_PATH || '').trim();
const basePath = (configuredBasePath === '/' ? '' : configuredBasePath || '/a3api').replace(
  /\/+$/,
  ''
);

/**
 * Trims {@link module:server~basePath} from the start of the request URL.
 *
 * @function stripBasePath
 * @param {express.Request} req - The Express request; `req.url` is rewritten.
 * @param {express.Response} res - Unused, but part of the middleware signature.
 * @param {express.NextFunction} next - Continues to the next middleware.
 * @returns {void}
 * @remarks
 * Runs before the body parser and every route, so nothing downstream has to know
 * that a prefix ever existed. The query string is preserved because it is part of
 * `req.url` and only the leading segment is sliced off.
 * @example
 * // BASE_PATH=/a3api
 * // req.url = '/a3api/api/health'  ->  '/api/health'
 * // req.url = '/a3api'             ->  '/'
 */
if (basePath) {
  app.use(function stripBasePath(req, res, next) {
    if (req.url.indexOf(basePath) === 0) {
      req.url = req.url.slice(basePath.length) || '/';
    }
    next();
  });
}

/**
 * Body parser for POST and PUT.
 *
 * Turns an `application/json` request body into `req.body`, so the route
 * handlers and {@link module:validation} can read it. Both Angular
 * applications post JSON, so no form-encoded parser is installed.
 *
 * @function jsonBodyParser
 * @see module:validation
 */
app.use(express.json());

/**
 * CORS middleware.
 *
 * @function corsHeaders
 * @param {express.Request} req - The Express request; only `req.method` is inspected.
 * @param {express.Response} res - The Express response the headers are set on.
 * @param {express.NextFunction} next - Moves the request on to the next middleware.
 * @returns {void} Returns nothing; either the preflight reply is sent or the chain continues.
 * @remarks
 * The two Angular websites run on different ports (4200 and 4300) during
 * development, so the browser is making a cross-origin request. Only the
 * methods the API actually supports are allowed. An `OPTIONS` preflight is
 * answered immediately with `204 No Content`; the browser never sends the real
 * request unless that succeeds.
 */
app.use(function (req, res, next) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(204);
  }
  next();
});

/**
 * A very small request log, useful when demonstrating the data flow in the video.
 *
 * @function requestLogger
 * @param {express.Request} req - The Express request being logged.
 * @param {express.Response} res - The Express response; not used here.
 * @param {express.NextFunction} next - Called immediately so the logger never delays a request.
 * @returns {void} Nothing; the line is written to the console.
 * @example
 * // console
 * // 2026-10-15T02:14:07.512Z  GET /api/events/home
 */
app.use(function (req, res, next) {
  console.log(new Date().toISOString() + '  ' + req.method + ' ' + req.originalUrl);
  next();
});

/**
 * `GET /api/health` - a trivially cheap liveness check.
 *
 * @function healthCheck
 * @param {express.Request} req - The Express request; nothing is read from it.
 * @param {express.Response} res - The Express response, sent with the JSON status object.
 * @returns {void} Nothing; the reply is written straight to `res`.
 * @remarks
 * Handy on the SCU cPanel to prove the API is up (and that Node is serving, not
 * just Apache). It is deliberately the only route here that touches no table.
 * @example
 * // GET /api/health  ->  200 OK
 * { "status": "ok", "service": "charity events API", "assessment": "PROG2002 A3" }
 */
app.get('/api/health', function (req, res) {
  res.json({ status: 'ok', service: 'charity events API', assessment: 'PROG2002 A3' });
});

/**
 * Mounts the four routers underneath `/api`.
 *
 * @function mountRoutes
 * @remarks
 * Each router owns one URL prefix, which keeps the RESTful paths of the brief
 * (for example `GET /api/events/:id/registrations`) out of this file.
 * @see module:routes/events
 * @see module:routes/admin
 * @see module:routes/lookups
 * @see module:routes/weather
 */
app.use('/api/events', eventRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api', lookupRoutes);   // /api/categories and /api/event-dates
app.use('/api/weather', weatherRoutes);

/**
 * Fallback for every unmatched path under `/api`.
 *
 * @function apiNotFound
 * @param {express.Request} req - The Express request (already unmatched).
 * @param {express.Response} res - The Express response; answered with `404` and a JSON error.
 * @returns {void} Nothing; the reply is written straight to `res`.
 * @remarks
 * Anything else under `/api` is a 404 in JSON, not an HTML page, so the Angular
 * applications can show a sensible message instead of trying to parse HTML.
 * @example
 * // GET /api/nope  ->  404 Not Found
 * { "error": "API endpoint not found." }
 */
app.use('/api', function (req, res) {
  res.status(404).json({ error: 'API endpoint not found.' });
});

/**
 * The last error handler for the whole application.
 *
 * @function errorHandler
 * @param {Error} err - The error thrown or rejected by a route handler; a MySQL
 *   error also carries `err.code` (for example `ER_DUP_ENTRY`).
 * @param {express.Request} req - The Express request that failed.
 * @param {express.Response} res - The Express response the JSON error is written to.
 * @param {express.NextFunction} next - Never called; Express needs the fourth parameter to recognise this as an error handler.
 * @returns {void} Nothing; the reply is written straight to `res`.
 * @throws {Error} Never re-throws - this is the end of the chain.
 * @remarks
 * A database error message is logged on the server but never sent to the
 * browser (it can name tables and columns), and the two integrity errors a
 * marker is most likely to trigger are turned into a friendly `409`:
 *
 */
app.use(function (err, req, res, next) {
  console.log('Unhandled error on ' + req.method + ' ' + req.originalUrl + ':');
  console.log(err);

  if (err && err.code === 'ER_DUP_ENTRY') {
    return res.status(409).json({ error: 'That record already exists.' });
  }
  if (err && err.code === 'ER_NO_REFERENCED_ROW_2') {
    return res.status(409).json({ error: 'That record refers to something that does not exist.' });
  }
  res.status(500).json({ error: 'Something went wrong on the server.' });
});

/**
 * Starts the HTTP server.
 *
 * @function startServer
 * @returns {void} Nothing; the callback only logs the two banner lines.
 * @example
 * // console
 * // Charity events API is running at http://localhost:3000
 * // Try http://localhost:3000/api/events/home
 */
app.listen(port, function () {
  console.log('Charity events API is running at http://localhost:' + port);
  console.log('Try http://localhost:' + port + '/api/events/home');
  // Printed so the deployment log answers the two questions a sub-URL mount
  // raises: is the prefix-stripping middleware switched on, and what prefix is it
  // using? A deployed request for /a3api/api/health only reaches the health route
  // when this line names /a3api.
  console.log('URL prefix stripping: ' + (basePath ? basePath : 'disabled'));
});
