/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * End-to-end test suite for the charity events API.
 *
 * @file api-endpoint-tests.js
 * @remarks Run `node api-endpoint-tests.js` while the API is listening on :3000.
 */
const BASE = process.env.API_BASE || 'http://localhost:3000';

// ---------------------------------------------------------------------------
// Every run gets its own email address and event name.
//
// The suite writes real rows (it must, because it tests a real API against a
// real database), so a fixed email would make the second run fail on purpose:
// the "duplicate registration" case and the "create a registration" case would
// both hit the same row. Using a per-run suffix keeps the suite idempotent, and
// cleanup() removes what this run created so the demo database stays tidy.
// ---------------------------------------------------------------------------
const RUN = Date.now().toString(36);
const TEST_EMAIL = `test.buyer.${RUN}@example.com`;
const TEST_EVENT = `A3 Test Fun Run ${RUN}`;

let pass = 0;
let fail = 0;
const failures = [];

async function call(method, path, body) {
  const options = { method };
  if (body !== undefined) {
    options.headers = { 'Content-Type': 'application/json' };
    options.body = JSON.stringify(body);
  }
  const response = await fetch(BASE + path, options);
  const text = await response.text();
  let json = null;
  try { json = JSON.parse(text); } catch (e) { json = text; }
  return { status: response.status, body: json };
}

async function test(name, fn) {
  try {
    const r = await fn();
    if (r === true) { pass++; console.log('  PASS  ' + name); }
    else { fail++; failures.push(name + ' -> ' + r); console.log('  FAIL  ' + name + '  -> ' + r); }
  } catch (err) {
    fail++; failures.push(name + ' -> exception ' + err.message);
    console.log('  FAIL  ' + name + '  -> exception ' + err.message);
  }
}

(async function () {
  console.log('=== READ (client website) ===');

  await test('GET /api/events/home returns only active upcoming events', async () => {
    const r = await call('GET', '/api/events/home');
    if (r.status !== 200) return 'status ' + r.status;
    if (r.body.length < 1) return 'no events';
    const bad = r.body.filter(e => e.display_status !== 'active');
    if (bad.length) return 'non-active event leaked: ' + bad[0].name;
    return true;
  });

  await test('GET /api/events?status=all hides the suspended event (7 of 8)', async () => {
    const r = await call('GET', '/api/events?status=all');
    if (r.status !== 200) return 'status ' + r.status;
    if (r.body.length !== 7) return 'expected 7, got ' + r.body.length;
    return true;
  });

  await test('GET /api/events?status=upcoming excludes the past event', async () => {
    const r = await call('GET', '/api/events?status=upcoming');
    const past = r.body.filter(e => e.display_status === 'past');
    if (past.length) return 'past event in upcoming list';
    return true;
  });

  await test('GET /api/events?status=past returns exactly the finished event', async () => {
    const r = await call('GET', '/api/events?status=past');
    if (r.body.length !== 1) return 'expected 1, got ' + r.body.length;
    return true;
  });

  await test('GET /api/events combines category + location filters', async () => {
    const r = await call('GET', '/api/events?status=all&category=1&location=lismore');
    if (r.status !== 200) return 'status ' + r.status;
    if (r.body.length !== 1) return 'expected 1, got ' + r.body.length;
    if (r.body[0].name !== 'Coastal Sunrise Fun Run') return 'wrong event: ' + r.body[0].name;
    return true;
  });

  await test('GET /api/events?status=banana -> 400', async () => {
    const r = await call('GET', '/api/events?status=banana');
    if (r.status !== 400) return 'status ' + r.status;
    return true;
  });

  await test('GET /api/events/:id -> event + registrations, newest first, email masked', async () => {
    const r = await call('GET', '/api/events/1');
    if (r.status !== 200) return 'status ' + r.status;
    const regs = r.body.registrations;
    if (regs.length !== 5) return 'expected 5 registrations, got ' + regs.length;
    const dates = regs.map(x => x.registration_date);
    for (let i = 1; i < dates.length; i++) {
      if (dates[i] > dates[i - 1]) return 'not sorted newest first: ' + dates.join(', ');
    }
    if (!regs[0].email.includes('***')) return 'email not masked: ' + regs[0].email;
    if (regs[0].phone !== 'hidden') return 'phone not hidden';
    if (Number(r.body.summary.tickets_sold) !== 11) return 'tickets_sold=' + r.body.summary.tickets_sold;
    return true;
  });

  await test('GET /api/events/8 (suspended) -> 404, never published', async () => {
    const r = await call('GET', '/api/events/8');
    if (r.status !== 404) return 'status ' + r.status;
    return true;
  });

  await test('GET /api/events/7 (past) is still readable and labelled past', async () => {
    const r = await call('GET', '/api/events/7');
    if (r.status !== 200) return 'status ' + r.status;
    if (r.body.event.display_status !== 'past') return 'display_status=' + r.body.event.display_status;
    return true;
  });

  await test('GET /api/events/99999 -> 404', async () => {
    const r = await call('GET', '/api/events/99999');
    if (r.status !== 404) return 'status ' + r.status;
    return true;
  });

  await test('GET /api/events/abc -> 400', async () => {
    const r = await call('GET', '/api/events/abc');
    if (r.status !== 400) return 'status ' + r.status;
    return true;
  });

  console.log('');
  console.log('=== READ (admin website) ===');

  await test('GET /api/admin/events lists all 8 events with Active/Past/Suspended', async () => {
    const r = await call('GET', '/api/admin/events');
    if (r.status !== 200) return 'status ' + r.status;
    if (r.body.length !== 8) return 'expected 8, got ' + r.body.length;
    const set = [...new Set(r.body.map(e => e.display_status))].sort().join(',');
    if (set !== 'active,past,suspended') return 'statuses: ' + set;
    return true;
  });

  await test('GET /api/admin/events/1 returns registration_count and the real email', async () => {
    const r = await call('GET', '/api/admin/events/1');
    if (r.status !== 200) return 'status ' + r.status;
    if (Number(r.body.event.registration_count) !== 5) return 'count=' + r.body.event.registration_count;
    if (r.body.registrations[0].email.includes('***')) return 'admin email should not be masked';
    return true;
  });

  await test('GET /api/categories -> 4 categories', async () => {
    const r = await call('GET', '/api/categories');
    if (r.body.length !== 4) return 'got ' + r.body.length;
    return true;
  });

  await test('GET /api/event-dates -> list of days', async () => {
    const r = await call('GET', '/api/event-dates');
    if (r.status !== 200) return 'status ' + r.status;
    if (!Array.isArray(r.body)) return 'not an array';
    return true;
  });

  console.log('');
  console.log('=== REGISTRATION writes ===');

  await test('POST registration -> 201 and server-side total (45 x 2 = 90)', async () => {
    const r = await call('POST', '/api/events/4/registrations', {
      first_name: 'Test', last_name: 'Buyer', email: TEST_EMAIL,
      phone: '0400 999 001', tickets: 2, notes: 'automated test'
    });
    if (r.status !== 201) return 'status ' + r.status + ' ' + JSON.stringify(r.body);
    if (Number(r.body.registration.total_amount) !== 90) return 'total=' + r.body.registration.total_amount;
    return true;
  });

  await test('POST the same email for the same event -> 409', async () => {
    const r = await call('POST', '/api/events/4/registrations', {
      first_name: 'Test', last_name: 'Buyer', email: TEST_EMAIL,
      phone: '0400 999 001', tickets: 1
    });
    if (r.status !== 409) return 'status ' + r.status;
    return true;
  });

  await test('POST the same email for a DIFFERENT event -> 201 (one person, many events)', async () => {
    const r = await call('POST', '/api/events/5/registrations', {
      first_name: 'Test', last_name: 'Buyer', email: TEST_EMAIL,
      phone: '0400 999 001', tickets: 3
    });
    if (r.status !== 201) return 'status ' + r.status + ' ' + JSON.stringify(r.body);
    if (Number(r.body.registration.total_amount) !== 45) return 'total=' + r.body.registration.total_amount;
    return true;
  });

  await test('POST to a suspended event -> 409', async () => {
    const r = await call('POST', '/api/events/8/registrations', {
      first_name: 'T', last_name: 'B', email: TEST_EMAIL, phone: '0400 999 001', tickets: 1
    });
    if (r.status !== 409) return 'status ' + r.status;
    return true;
  });

  await test('POST to a past event -> 409', async () => {
    const r = await call('POST', '/api/events/7/registrations', {
      first_name: 'T', last_name: 'B', email: TEST_EMAIL, phone: '0400 999 001', tickets: 1
    });
    if (r.status !== 409) return 'status ' + r.status;
    return true;
  });

  await test('POST invalid body -> 400 with per-field messages', async () => {
    const r = await call('POST', '/api/events/4/registrations', {
      first_name: '', last_name: 'X', email: 'not-an-email', phone: 'abc', tickets: 99
    });
    if (r.status !== 400) return 'status ' + r.status;
    const fields = Object.keys(r.body.fields || {});
    if (fields.length < 4) return 'only ' + fields.length + ' field errors';
    return true;
  });

  await test('POST registration to a missing event -> 404', async () => {
    const r = await call('POST', '/api/events/99999/registrations', {
      first_name: 'T', last_name: 'B', email: 't@b.com', phone: '0400 000 000', tickets: 1
    });
    if (r.status !== 404) return 'status ' + r.status;
    return true;
  });

  console.log('');
  console.log('=== EVENT CRUD (admin) ===');

  let newId = 0;
  await test('POST /api/events -> 201', async () => {
    const r = await call('POST', '/api/events', {
      category_id: 1, name: TEST_EVENT, event_date: '2027-03-15T07:00',
      location: 'Test Oval, Lismore', latitude: -28.81, longitude: 153.28,
      purpose: 'Automated test event', description: 'Created by the endpoint test.',
      ticket_price: 20, fundraising_goal: 5000, status: 'active',
      image_url: 'assets/images/event-placeholder.jpg'
    });
    if (r.status !== 201) return 'status ' + r.status + ' ' + JSON.stringify(r.body);
    newId = r.body.event_id;
    return true;
  });

  await test('POST /api/events with missing/invalid fields -> 400', async () => {
    const r = await call('POST', '/api/events', {
      category_id: 1, name: '', event_date: 'not a date', location: '',
      purpose: '', description: '', ticket_price: -5, fundraising_goal: 0
    });
    if (r.status !== 400) return 'status ' + r.status;
    const fields = Object.keys(r.body.fields || {});
    if (fields.length < 6) return 'only ' + fields.length + ' field errors: ' + fields.join(',');
    return true;
  });

  await test('GET /api/admin/events/:id finds the new event', async () => {
    const r = await call('GET', '/api/admin/events/' + newId);
    if (r.status !== 200) return 'status ' + r.status;
    if (r.body.event.name !== TEST_EVENT) return 'name=' + r.body.event.name;
    return true;
  });

  await test('PUT /api/events/:id updates name, price and status', async () => {
    const r = await call('PUT', '/api/events/' + newId, {
      name: TEST_EVENT + ' (updated)', ticket_price: 30, status: 'suspended'
    });
    if (r.status !== 200) return 'status ' + r.status + ' ' + JSON.stringify(r.body);
    const check = await call('GET', '/api/admin/events/' + newId);
    if (check.body.event.name !== TEST_EVENT + ' (updated)') return 'name not saved';
    if (Number(check.body.event.ticket_price) !== 30) return 'price=' + check.body.event.ticket_price;
    if (check.body.event.display_status !== 'suspended') return 'status=' + check.body.event.display_status;
    return true;
  });

  await test('PUT with an invalid value -> 400 and nothing changes', async () => {
    const r = await call('PUT', '/api/events/' + newId, { ticket_price: 'abc', fundraising_goal: -1 });
    if (r.status !== 400) return 'status ' + r.status;
    const check = await call('GET', '/api/admin/events/' + newId);
    if (Number(check.body.event.ticket_price) !== 30) return 'price changed to ' + check.body.event.ticket_price;
    return true;
  });

  await test('PUT on a missing event -> 404', async () => {
    const r = await call('PUT', '/api/events/99999', { name: 'nope' });
    if (r.status !== 404) return 'status ' + r.status;
    return true;
  });

  await test('DELETE an event WITH registrations -> 409 and the event survives', async () => {
    const r = await call('DELETE', '/api/events/1');
    if (r.status !== 409) return 'status ' + r.status;
    if (Number(r.body.registration_count) !== 5) return 'count=' + r.body.registration_count;
    const after = await call('GET', '/api/admin/events/1');
    if (after.status !== 200) return 'event 1 disappeared!';
    return true;
  });

  await test('DELETE an event with NO registrations -> 200, then 404', async () => {
    const r = await call('DELETE', '/api/events/' + newId);
    if (r.status !== 200) return 'status ' + r.status + ' ' + JSON.stringify(r.body);
    const after = await call('GET', '/api/admin/events/' + newId);
    if (after.status !== 404) return 'event still there (' + after.status + ')';
    return true;
  });

  await test('DELETE a missing event -> 404', async () => {
    const r = await call('DELETE', '/api/events/99999');
    if (r.status !== 404) return 'status ' + r.status;
    return true;
  });

  console.log('');
  console.log('=== external weather API (optional bonus) ===');

  await test('GET /api/weather/1 returns a translated Open-Meteo forecast', async () => {
    const r = await call('GET', '/api/weather/1');
    if (r.status !== 200) return 'status ' + r.status + ' ' + JSON.stringify(r.body);
    if (!r.body.days || r.body.days.length < 1) return 'no days';
    if (!r.body.days[0].description) return 'no translation';
    console.log('        -> ' + r.body.days[0].date + '  ' + r.body.days[0].description +
      '  max ' + r.body.days[0].temperature_max + 'C');
    return true;
  });

  await test('GET /api/weather/99999 -> 404', async () => {
    const r = await call('GET', '/api/weather/99999');
    if (r.status !== 404) return 'status ' + r.status;
    return true;
  });

  console.log('');
  console.log('=== unknown route ===');

  await test('GET /api/nope -> JSON 404', async () => {
    const r = await call('GET', '/api/nope');
    if (r.status !== 404) return 'status ' + r.status;
    if (!r.body.error) return 'not JSON';
    return true;
  });

  // -------------------------------------------------------------------------
  // Remove the rows this suite created, so it can be run again immediately and
  // so the demo database keeps exactly the 12 sample registrations.
  //
  // This connects to MySQL directly, because the API deliberately has no
  // endpoint that deletes a registration. If the connection or the mysql2
  // module is unavailable the cleanup is skipped with a note rather than
  // failing the run: leftover test rows are untidy, not a broken suite.
  // -------------------------------------------------------------------------
  await cleanup();

  console.log('');
  console.log('==========  RESULT: ' + pass + ' passed, ' + fail + ' failed  ==========');
  if (fail > 0) {
    console.log('');
    console.log('Failures:');
    failures.forEach(f => console.log('  - ' + f));
  }
  process.exit(fail === 0 ? 0 : 1);
})();

async function cleanup() {
  let connection = null;
  try {
    const path = require('path');
    const fs = require('fs');

    // This file is kept at the project root so "node api-endpoint-tests.js" works
    // from there, but it is ALSO shipped inside wushaoweiA3-api.zip so the marker
    // can find the suite next to the code it tests. Resolving the API folder
    // instead of assuming a fixed depth means both locations work.
    const apiDir = path.basename(__dirname) === 'wushaoweiA3-api'
      ? __dirname
      : path.join(__dirname, 'wushaoweiA3-api');

    // read the same .env the API uses, so there is only one place with the
    // database password
    const envPath = path.join(apiDir, '.env');
    const env = {};
    if (fs.existsSync(envPath)) {
      fs.readFileSync(envPath, 'utf8').split(/\r?\n/).forEach(function (line) {
        const m = line.match(/^\s*([A-Za-z_]+)\s*=\s*(.*)$/);
        if (m) env[m[1]] = m[2].trim();
      });
    }

    const mysql = require(path.join(apiDir, 'node_modules', 'mysql2', 'promise'));
    connection = await mysql.createConnection({
      host: env.DB_HOST || '127.0.0.1',
      user: env.DB_USER || 'root',
      password: env.DB_PASSWORD || '',
      database: env.DB_NAME || 'charityevents_db'
    });

    // The API adds every registration's total to events.amount_raised, so the test
    // rows have to give that money back before they are deleted. Without this the
    // seeded amount_raised would drift up a little on every run and the figures in
    // the report would stop matching the database.
    const [refund] = await connection.query(
      "UPDATE events e " +
      "JOIN (" +
      "  SELECT event_id, SUM(total_amount) AS refund FROM registrations " +
      "  WHERE email = ? OR email LIKE 'test.buyer.%@example.com' " +
      "  GROUP BY event_id" +
      ") t ON t.event_id = e.event_id " +
      "SET e.amount_raised = e.amount_raised - t.refund",
      [TEST_EMAIL]
    );

    // registrations first: events.event_id is referenced with ON DELETE RESTRICT
    const [regs] = await connection.query(
      "DELETE FROM registrations WHERE email = ? OR email LIKE 'test.buyer.%@example.com'",
      [TEST_EMAIL]
    );
    const [evts] = await connection.query(
      "DELETE FROM events WHERE name LIKE 'A3 Test Fun Run%'"
    );
    console.log('');
    console.log('  cleanup: removed ' + regs.affectedRows + ' test registration(s) and ' +
      evts.affectedRows + ' test event(s) from ' + (env.DB_NAME || 'charityevents_db') +
      ', and put ' + refund.affectedRows + ' event amount_raised figure(s) back');
  } catch (err) {
    console.log('');
    console.log('  cleanup skipped (' + err.message + ')');
    console.log('  the suite result above is still valid; the test rows are harmless leftovers');
  } finally {
    if (connection) {
      try { await connection.end(); } catch (e) { /* already closed */ }
    }
  }
}
