/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * The field-by-field input checks shared by `POST /api/events`, `PUT
 * /api/events/:id` and `POST /api/events/:id/registrations`, plus the small
 * parsing helpers those checks are built from.
 *
 * @module validation
 * @file validation.js
 */

/**
 * The result every validator returns.
 *
 * @typedef {object} ValidationOutcome
 * @property {object} data - Only the fields that passed, trimmed and converted to the type the model expects. A key that is absent here must keep its old value (PUT) or its default (POST).
 * @property {Object<string, string>} errors - Field name to message, for example `{ name: 'The event name is required.' }`. The object is empty when everything passed.
 */

/**
 * Is this a number, or a string that looks like one?
 *
 * @function isNumber
 * @param {*} value - The value to test; `''`, `null` and `undefined` are not numbers even though `Number('')` is `0`.
 * @returns {boolean} `true` when `Number(value)` is a real number, `false` otherwise.
 * @remarks
 * HTML form fields always arrive as strings, so a check based on
 * `typeof value === 'number'` would reject every valid price. The explicit
 * guards for `''`, `null` and `undefined` are what stop an empty box becoming a
 * valid zero.
 * @example
 * isNumber('25.00'); // true
 * isNumber('');      // false
 * isNumber('abc');   // false
 */
function isNumber(value) {
  return value !== '' && value !== null && value !== undefined && isNaN(Number(value)) === false;
}

/**
 * Normalises a date and time from a form control into the MySQL `DATETIME` format.
 *
 * @function normaliseDateTime
 * @param {*} value - `'YYYY-MM-DD'`, `'YYYY-MM-DDTHH:mm'` or `'YYYY-MM-DD HH:mm:ss'`; anything else (including a non-string) is rejected.
 * @returns {string|null} The normalised `'YYYY-MM-DD HH:mm:ss'` text, or `null` when the value is not a real date and time.
 * @remarks
 * `<input type="datetime-local">` sends `2027-03-15T07:00`, which MySQL will not
 * accept as it stands, so the `T` becomes a space and the missing seconds (and
 * time) are filled in. The regexes alone would accept `2027-02-30`, so the
 * value is also rebuilt through `Date` and every part is compared back: if
 * JavaScript has rolled the day over, the input did not exist and `null` is
 * returned. This is the only guard against a date such as 30 February reaching
 * the database.
 * @see module:validation~normaliseDate
 * @example
 * normaliseDateTime('2027-03-15T07:00'); // '2027-03-15 07:00:00'
 * normaliseDateTime('2027-03-15');       // '2027-03-15 00:00:00'
 * normaliseDateTime('2027-02-30');       // null  (that day does not exist)
 * normaliseDateTime('next tuesday');     // null
 */
function normaliseDateTime(value) {
  if (typeof value !== 'string') {
    return null;
  }
  let text = value.trim().replace('T', ' ');
  if (/^\d{4}-\d{2}-\d{2}$/.test(text)) {
    text = text + ' 00:00:00';
  } else if (/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/.test(text)) {
    text = text + ':00';
  }
  if (/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(text) === false) {
    return null;
  }
  const parts = text.substring(0, 10).split('-');
  const time = text.substring(11).split(':');
  const date = new Date(
    Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]),
    Number(time[0]), Number(time[1]), Number(time[2])
  );
  const ok =
    date.getFullYear() === Number(parts[0]) &&
    date.getMonth() === Number(parts[1]) - 1 &&
    date.getDate() === Number(parts[2]) &&
    date.getHours() === Number(time[0]) &&
    date.getMinutes() === Number(time[1]);
  return ok ? text : null;
}

/**
 * Checks that a search-filter value is a plain calendar day.
 *
 * @function normaliseDate
 * @param {*} value - The raw `date` query string of `GET /api/events`.
 * @returns {string|null} The trimmed `'YYYY-MM-DD'` text, or `null` when it is not exactly a day.
 * @remarks
 * A day has no time component and no rollover problem, so a regex is enough
 * here; {@link module:validation~normaliseDateTime} is the stricter version used
 * for event dates. `null` tells the route to answer `400` rather than silently
 * searching for nothing.
 * @see module:routes/events
 * @example
 * normaliseDate(' 2026-10-15 '); // '2026-10-15'
 * normaliseDate('15/10/2026');   // null
 */
function normaliseDate(value) {
  if (typeof value !== 'string' || /^\d{4}-\d{2}-\d{2}$/.test(value.trim()) === false) {
    return null;
  }
  return value.trim();
}

/**
 * Trims a text field, treating a missing value as empty.
 *
 * @function trimText
 * @param {*} value - The raw value from the request body.
 * @returns {string} The trimmed text, or `''` when the value is not a string.
 * @remarks
 * Trimming first means a name of three spaces is reported as missing rather
 * than stored, and it is the only place missing/non-string input is flattened,
 * so every length check afterwards can assume a string.
 */
function trimText(value) {
  return typeof value === 'string' ? value.trim() : '';
}

/**
 * Validates a charity event, as sent by the admin form.
 *
 * @function validateEvent
 * @param {object} body - The raw JSON body of `POST /api/events` or `PUT /api/events/:id`.
 * @param {boolean} [partial=false] - `true` for PUT, where the form may send only the changed fields; `false` for POST, where the missing fields get their defaults.
 * @returns {ValidationOutcome} `data` with the accepted fields (converted, trimmed, defaults filled in for a full create) and `errors` keyed by field name.
 * @remarks
 * `partial` is the whole difference between the two endpoints: in partial mode an
 * unmentioned field is left out of `data`, so
 * {@link module:event_model~updateEvent} keeps the stored value; in full mode it
 * gets its documented default instead (`organisation_id` 1, `latitude`/`longitude`
 * 0, `amount_raised` 0, `status` 'active', a placeholder `image_url`).
 *
 * The main rules: name, location, purpose and description are required; name and
 * location stop at 160 characters and purpose at 255; the date must be a real date
 * and time; coordinates must be in range (-90..90 and -180..180); a ticket price
 * may be 0 but not less; a goal must be above 0; and the status may only be
 * 'active' or 'suspended' - "past" is derived from the date, never stored.
 *
 * Every failure is collected rather than thrown, so the admin form can highlight
 * all of the mistakes at once.
 * @see module:event_model~createEvent
 * @see module:event_model~updateEvent
 * @example
 * const checked = validateEvent({ category_id: 1, name: '', ticket_price: -5 }, false);
 * // checked.errors -> { name: 'The event name is required.', ... }
 */
function validateEvent(body, partial) {
  const errors = {};
  const data = {};

  function wanted(field) {
    return partial === true ? body[field] !== undefined : true;
  }

  if (body.organisation_id !== undefined) {
    if (isNumber(body.organisation_id) && Number(body.organisation_id) > 0) {
      data.organisation_id = Number(body.organisation_id);
    } else {
      errors.organisation_id = 'The organisation must be a valid id.';
    }
  } else if (!partial) {
    data.organisation_id = 1;
  }

  if (wanted('category_id')) {
    if (isNumber(body.category_id) && Number(body.category_id) > 0) {
      data.category_id = Number(body.category_id);
    } else {
      errors.category_id = 'Please choose an event category.';
    }
  }

  if (wanted('name')) {
    const name = trimText(body.name);
    if (name.length === 0) {
      errors.name = 'The event name is required.';
    } else if (name.length > 160) {
      errors.name = 'The event name cannot be longer than 160 characters.';
    } else {
      data.name = name;
    }
  }

  if (wanted('event_date')) {
    const eventDate = normaliseDateTime(body.event_date);
    if (eventDate === null) {
      errors.event_date = 'Please choose a valid date and time (YYYY-MM-DD HH:MM).';
    } else {
      data.event_date = eventDate;
    }
  }

  if (wanted('location')) {
    const location = trimText(body.location);
    if (location.length === 0) {
      errors.location = 'The event location is required.';
    } else if (location.length > 160) {
      errors.location = 'The location cannot be longer than 160 characters.';
    } else {
      data.location = location;
    }
  }

  ['latitude', 'longitude'].forEach(function (field) {
    if (body[field] !== undefined && body[field] !== '') {
      if (isNumber(body[field]) === false) {
        errors[field] = 'The ' + field + ' must be a number.';
      } else {
        const value = Number(body[field]);
        const limit = field === 'latitude' ? 90 : 180;
        if (value < -limit || value > limit) {
          errors[field] = 'The ' + field + ' must be between -' + limit + ' and ' + limit + '.';
        } else {
          data[field] = value;
        }
      }
    } else if (!partial) {
      data[field] = 0;
    }
  });

  if (wanted('purpose')) {
    const purpose = trimText(body.purpose);
    if (purpose.length === 0) {
      errors.purpose = 'Please write what the event is raising money for.';
    } else if (purpose.length > 255) {
      errors.purpose = 'The purpose cannot be longer than 255 characters.';
    } else {
      data.purpose = purpose;
    }
  }

  if (wanted('description')) {
    const description = trimText(body.description);
    if (description.length === 0) {
      errors.description = 'The event description is required.';
    } else {
      data.description = description;
    }
  }

  if (wanted('ticket_price')) {
    if (isNumber(body.ticket_price) === false || Number(body.ticket_price) < 0) {
      errors.ticket_price = 'The ticket price must be 0 or more (0 means a free event).';
    } else {
      data.ticket_price = Number(body.ticket_price);
    }
  }

  if (wanted('fundraising_goal')) {
    if (isNumber(body.fundraising_goal) === false || Number(body.fundraising_goal) <= 0) {
      errors.fundraising_goal = 'The fundraising goal must be more than 0.';
    } else {
      data.fundraising_goal = Number(body.fundraising_goal);
    }
  }

  if (body.amount_raised !== undefined && body.amount_raised !== '') {
    if (isNumber(body.amount_raised) === false || Number(body.amount_raised) < 0) {
      errors.amount_raised = 'The amount raised must be 0 or more.';
    } else {
      data.amount_raised = Number(body.amount_raised);
    }
  } else if (!partial) {
    data.amount_raised = 0;
  }

  if (body.status !== undefined && body.status !== '') {
    if (body.status === 'active' || body.status === 'suspended') {
      data.status = body.status;
    } else {
      errors.status = "The status must be either 'active' or 'suspended'.";
    }
  } else if (!partial) {
    data.status = 'active';
  }

  if (body.image_url !== undefined && body.image_url !== null && trimText(body.image_url) !== '') {
    const imageUrl = trimText(body.image_url);
    if (imageUrl.length > 500) {
      errors.image_url = 'The image path cannot be longer than 500 characters.';
    } else {
      data.image_url = imageUrl;
    }
  } else if (!partial) {
    data.image_url = 'assets/images/event-placeholder.jpg';
  }

  return { data: data, errors: errors };
}

/**
 * Validates a registration, as sent by the registration page.
 *
 * @function validateRegistration
 * @param {object} body - The raw JSON body of `POST /api/events/:id/registrations`.
 * @returns {ValidationOutcome} `data` with `first_name`, `last_name`, `email`, `phone`, `tickets` and optionally `notes`; `errors` keyed by field name.
 * @remarks
 * The rules: first and last name and a contact number are required (names stop
 * at 80 characters); the email must match the same pattern the database CHECK
 * constraint uses and is lower-cased, so `Amelia@Example.com` and
 * `amelia@example.com` cannot register twice for one event; the phone number
 * only allows digits, spaces, `+`, `-` and brackets, which is enough for the
 * case study; and the brief says "web users may decide how many tickets", so the
 * count must be a whole number between 1 and 10. The note is optional and stops
 * at 255 characters.
 *
 * The total is deliberately not accepted here - the server prices the
 * registration in {@link module:event_model~createRegistration}.
 * @see module:event_model~findRegistration
 * @see module:event_model~createRegistration
 * @example
 * const checked = validateRegistration({ first_name: '', email: 'not-an-email', tickets: 99 });
 * // checked.errors -> { first_name: 'Your first name is required.',
 * //                     email: 'Please enter a valid email address.',
 * //                     tickets: 'You can buy between 1 and 10 tickets.', ... }
 */
function validateRegistration(body) {
  const errors = {};
  const data = {};

  const firstName = trimText(body.first_name);
  if (firstName.length === 0) {
    errors.first_name = 'Your first name is required.';
  } else if (firstName.length > 80) {
    errors.first_name = 'Your first name cannot be longer than 80 characters.';
  } else {
    data.first_name = firstName;
  }

  const lastName = trimText(body.last_name);
  if (lastName.length === 0) {
    errors.last_name = 'Your last name is required.';
  } else if (lastName.length > 80) {
    errors.last_name = 'Your last name cannot be longer than 80 characters.';
  } else {
    data.last_name = lastName;
  }

  const email = trimText(body.email).toLowerCase();
  if (email.length === 0) {
    errors.email = 'Your email address is required.';
  } else if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) === false) {
    errors.email = 'Please enter a valid email address.';
  } else if (email.length > 160) {
    errors.email = 'The email address cannot be longer than 160 characters.';
  } else {
    data.email = email;
  }

  const phone = trimText(body.phone);
  if (phone.length === 0) {
    errors.phone = 'A contact number is required.';
  } else if (/^[0-9+\-() ]{6,40}$/.test(phone) === false) {
    errors.phone = 'Please enter a contact number using digits, spaces, +, - or ( ).';
  } else {
    data.phone = phone;
  }

  const tickets = Number(body.tickets);
  if (isNumber(body.tickets) === false || Number.isInteger(tickets) === false) {
    errors.tickets = 'Please enter a whole number of tickets.';
  } else if (tickets < 1 || tickets > 10) {
    errors.tickets = 'You can buy between 1 and 10 tickets.';
  } else {
    data.tickets = tickets;
  }

  if (body.notes !== undefined && body.notes !== null) {
    const notes = trimText(body.notes);
    if (notes.length > 255) {
      errors.notes = 'The note cannot be longer than 255 characters.';
    } else if (notes.length > 0) {
      data.notes = notes;
    }
  }

  return { data: data, errors: errors };
}

/**
 * The public surface of this module.
 *
 * @type {object}
 * @property {function(*): boolean} isNumber - Number-or-numeric-string test.
 * @property {function(*): (string|null)} normaliseDateTime - Form date and time to `DATETIME` text.
 * @property {function(*): (string|null)} normaliseDate - Query string to `YYYY-MM-DD`.
 * @property {function(object, boolean=): ValidationOutcome} validateEvent - The admin event rules.
 * @property {function(object): ValidationOutcome} validateRegistration - The public registration rules.
 */
module.exports = {
  isNumber: isNumber,
  normaliseDateTime: normaliseDateTime,
  normaliseDate: normaliseDate,
  validateEvent: validateEvent,
  validateRegistration: validateRegistration
};
