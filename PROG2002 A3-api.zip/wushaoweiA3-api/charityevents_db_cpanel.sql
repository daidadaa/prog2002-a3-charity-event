-- ============================================================================
-- PROG2002 Web Development II - Assessment 3
-- WU Shao Wei
-- charityevents_db_cpanel.sql
--
-- *** THIS FILE IS FOR IMPORTING INTO A SCU cPANEL DATABASE ***
--
-- Use charityevents_db.sql when you are working locally (MySQL Workbench): it
-- creates the database itself and is what the marker runs.
--
-- Use THIS file on cPanel, because a cPanel account is not allowed to run
-- CREATE DATABASE or DROP DATABASE from phpMyAdmin. The database itself is
-- created in the cPanel panel first, and its name has your account prefix
-- (for example wus1_charityevents). This file therefore contains only the
-- tables and the data, and it goes into whichever database is selected in
-- phpMyAdmin when you press Import.
--
-- STEPS
--   1. cPanel -> MySQL(R) Databases -> create a database, e.g. wus1_charityevents
--   2. On the same page create a user and "Add User To Database" with ALL PRIVILEGES
--   3. cPanel -> phpMyAdmin -> click the database in the left list
--   4. Import tab -> choose this file -> Go
--   5. Put the same names into the API's .env on cPanel:
--          DB_HOST=localhost
--          DB_USER=wus1_charityuser
--          DB_PASSWORD=the password you set
--          DB_NAME=wus1_charityevents
--
-- It is safe to run more than once: every CREATE TABLE uses IF NOT EXISTS, and
-- re-importing simply reports that the tables already exist.
-- ============================================================================

-- ============================================================================
-- PROG2002 Web Development II - Assessment 3
-- WU Shao Wei
-- Database: charityevents_db
--
-- Assignment 2 had three tables (organisations, categories, events) and the
-- website could only read them. Assessment 3 adds the "register for an event"
-- feature, so this file adds:
--   * a new registrations table that links a person to one event,
--   * latitude / longitude on events (needed by the Open-Meteo weather API),
--   * 12 sample registrations so the marker has a realistic dataset.
--
-- Import this whole file in MySQL Workbench (or `mysql < charityevents_db.sql`).
-- It drops and recreates the database, so it is safe to run more than once.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- charity organisations
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS organisations (
  organisation_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  mission TEXT NOT NULL,
  email VARCHAR(120) NOT NULL,
  phone VARCHAR(40) NOT NULL,
  website VARCHAR(255)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- event categories
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS categories (
  category_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL UNIQUE,
  description VARCHAR(255)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- main table
--
-- latitude and longitude were added in Assessment 3 because the Open-Meteo
-- weather API needs the coordinates of the event location.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS events (
  event_id INT AUTO_INCREMENT PRIMARY KEY,
  organisation_id INT NOT NULL,
  category_id INT NOT NULL,
  name VARCHAR(160) NOT NULL,
  event_date DATETIME NOT NULL,
  location VARCHAR(160) NOT NULL,
  latitude DECIMAL(9, 6) NOT NULL DEFAULT 0.000000,
  longitude DECIMAL(9, 6) NOT NULL DEFAULT 0.000000,
  purpose VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  ticket_price DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
  fundraising_goal DECIMAL(12, 2) NOT NULL,
  amount_raised DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
  status ENUM('active', 'suspended') NOT NULL DEFAULT 'active',
  image_url VARCHAR(500),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_events_organisation FOREIGN KEY (organisation_id)
    REFERENCES organisations(organisation_id),
  CONSTRAINT fk_events_category FOREIGN KEY (category_id)
    REFERENCES categories(category_id),
  -- Every listing the two websites ask for filters on the status and sorts or
  -- filters by the date: the home page wants "active from today onwards", the
  -- search page adds "active, this date or later". Without this index both
  -- queries fall back to a full table scan of `events`, which EXPLAIN shows as
  -- type ALL / key NULL. The two foreign keys above already have their own
  -- indexes, so this is the only missing one on this table.
  --
  -- It is declared inside CREATE TABLE rather than as a separate CREATE INDEX so
  -- this file stays safe to import twice: the table is skipped when it already
  -- exists, and no bare CREATE INDEX is ever re-run.
  --
  -- `location` is deliberately NOT indexed: the search matches it with
  -- LIKE '%text%', and a leading wildcard cannot use a B-tree index.
  INDEX idx_events_status_date (status, event_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- registrations  (NEW IN ASSESSMENT 3)
--
-- Business rules taken from the assessment brief:
--   * one registration belongs to exactly one event
--     -> event_id is a foreign key to events(event_id)
--   * one person may register for many events, but only once for the same event
--     -> UNIQUE KEY on (event_id, email)
--   * an event that already has registrations must not be deleted
--     -> ON DELETE RESTRICT, and the API checks this first and answers with 409
--
-- The brief does not require a USER table, so the person's details are stored
-- directly on the registration row.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS registrations (
  registration_id INT AUTO_INCREMENT PRIMARY KEY,
  event_id INT NOT NULL,
  first_name VARCHAR(80) NOT NULL,
  last_name VARCHAR(80) NOT NULL,
  email VARCHAR(160) NOT NULL,
  phone VARCHAR(40) NOT NULL,
  tickets INT NOT NULL DEFAULT 1,
  registration_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  total_amount DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
  notes VARCHAR(255),
  CONSTRAINT fk_registrations_event FOREIGN KEY (event_id)
    REFERENCES events(event_id)
    ON DELETE RESTRICT
    ON UPDATE CASCADE,
  -- "one user may register for multiple events and can only register for an
  --  event once"
  CONSTRAINT uq_registration_event_email UNIQUE (event_id, email),
  CONSTRAINT chk_registration_tickets CHECK (tickets >= 1 AND tickets <= 10),
  CONSTRAINT chk_registration_email CHECK (email LIKE '%_@_%._%')
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- an index for the detail page, which lists the registrations of one event
-- newest first
CREATE INDEX idx_registrations_event_date
  ON registrations (event_id, registration_date DESC);

-- ============================================================================
-- sample data
-- ============================================================================
INSERT INTO organisations (name, mission, email, phone, website) VALUES
('Kind', 'We bring neighbours together to fund practical support and brighter futures.', 'hello@kind.org', '(02) 6600 2000', 'https://kind.org');

INSERT INTO categories (name, description) VALUES
('Fun Run', 'Community runs and walks for a cause.'),
('Gala Dinner', 'Formal evenings celebrating generosity.'),
('Auction', 'Fundraising auctions and creative showcases.'),
('Concert', 'Live music events supporting local programs.');

-- 8 sample events. The dates are relative to today, so one of them is already
-- in the past (so the admin list can show a "Past" row) and one is suspended.
INSERT INTO events (organisation_id, category_id, name, event_date, location, latitude, longitude, purpose, description, ticket_price, fundraising_goal, amount_raised, status, image_url) VALUES
(1, 1, 'Coastal Sunrise Fun Run', TIMESTAMP(DATE_ADD(CURDATE(), INTERVAL 13 DAY), '06:30:00'), 'Lismore Riverside Park', -28.813500, 153.277300, 'Fund youth mental health outreach.', 'Choose a 5 km or 10 km riverside course and help local young people access timely mental health support.', 25.00, 18000.00, 7450.00, 'active', 'assets/images/coastal-sunrise-fun-run.jpg'),
(1, 2, 'Light the Way Gala', TIMESTAMP(DATE_ADD(CURDATE(), INTERVAL 26 DAY), '18:30:00'), 'Ballina Heritage Hall', -28.864000, 153.565600, 'Fund safe accommodation for families.', 'An evening of shared stories, a three-course dinner and a quiet auction in support of emergency family accommodation.', 120.00, 35000.00, 18400.00, 'active', 'assets/images/light-the-way-gala.jpg'),
(1, 3, 'Art for Tomorrow Auction', TIMESTAMP(DATE_ADD(CURDATE(), INTERVAL 40 DAY), '17:00:00'), 'Byron Arts Precinct', -28.643400, 153.612200, 'Fund creative learning resources.', 'Bid on work donated by local artists and help equip community learning spaces with materials and mentoring.', 0.00, 12000.00, 5100.00, 'active', 'assets/images/art-for-tomorrow-auction.jpg'),
(1, 4, 'Songs for Shelter', TIMESTAMP(DATE_ADD(CURDATE(), INTERVAL 54 DAY), '19:00:00'), 'Tweed Civic Theatre', -28.178000, 153.539000, 'Fund warm meals and essential supplies.', 'A night of live music featuring regional performers, with every ticket supporting the Shelter Table program.', 45.00, 22000.00, 9800.00, 'active', 'assets/images/songs-for-shelter.jpg'),
(1, 1, 'Steps for Safe Water', TIMESTAMP(DATE_ADD(CURDATE(), INTERVAL 69 DAY), '08:00:00'), 'Kingscliff Foreshore', -28.256800, 153.573600, 'Fund clean water equipment.', 'Walk, run or cheer from the sidelines while raising funds for portable clean water systems.', 15.00, 15000.00, 2250.00, 'active', 'assets/images/steps-for-safe-water.jpg'),
(1, 2, 'Community Table Dinner', TIMESTAMP(DATE_ADD(CURDATE(), INTERVAL 81 DAY), '18:00:00'), 'Murwillumbah Community Centre', -28.327400, 153.395000, 'Fund food relief during summer.', 'A welcoming shared dinner that turns each place at the table into a week of groceries for a neighbour.', 65.00, 10000.00, 3400.00, 'active', 'assets/images/community-table-dinner.jpg'),
(1, 3, 'Winter Makers Auction', TIMESTAMP(DATE_SUB(CURDATE(), INTERVAL 78 DAY), '16:00:00'), 'Lismore Makers Hall', -28.810000, 153.280000, 'Fund repair workshops.', 'A completed winter auction that helped support practical repair skills and tools for local residents.', 0.00, 9000.00, 9000.00, 'active', 'assets/images/winter-makers-auction.jpg'),
(1, 4, 'Harbour Voices Concert', TIMESTAMP(DATE_ADD(CURDATE(), INTERVAL 5 DAY), '18:30:00'), 'Ballina Wharf Stage', -28.867000, 153.558000, 'Fund inclusive arts programs.', 'This event is temporarily unavailable while its program is reviewed.', 35.00, 16000.00, 1200.00, 'suspended', 'assets/images/harbour-voices-concert.jpg');

-- 12 sample registrations (the brief asks for at least 10).
--   * event 1 (Coastal Sunrise Fun Run)  -> 5 registrations
--   * event 2 (Light the Way Gala)       -> 4 registrations
--   * event 3 (Art for Tomorrow Auction) -> 3 registrations
--   * events 4 to 8 have no registrations, so the admin "Delete" button can be
--     demonstrated both ways: blocked for events 1-3, successful afterwards.
-- The same email appears on more than one event on purpose: that shows one
-- person may register for several events, while the UNIQUE key still stops a
-- second registration for the same event.
-- registration_date is spread over the past weeks, so "newest first" is visible.
INSERT INTO registrations (event_id, first_name, last_name, email, phone, tickets, registration_date, total_amount, notes) VALUES
(1, 'Amelia',  'Nguyen',   'amelia.nguyen@example.com',  '0400 111 201', 2, DATE_SUB(NOW(), INTERVAL 21 DAY),  50.00, 'Running with a friend.'),
(1, 'Ben',     'Carter',   'ben.carter@example.com',     '0400 111 202', 1, DATE_SUB(NOW(), INTERVAL 17 DAY),  25.00, NULL),
(1, 'Chloe',   'Watson',   'chloe.watson@example.com',   '0400 111 203', 4, DATE_SUB(NOW(), INTERVAL 12 DAY), 100.00, 'Family entry.'),
(1, 'Daniel',  'Okafor',   'daniel.okafor@example.com',  '0400 111 204', 1, DATE_SUB(NOW(), INTERVAL  6 DAY),  25.00, NULL),
(1, 'Emma',    'Rossi',    'emma.rossi@example.com',     '0400 111 205', 3, DATE_SUB(NOW(), INTERVAL  2 DAY),  75.00, 'Work team.'),
(2, 'Amelia',  'Nguyen',   'amelia.nguyen@example.com',  '0400 111 201', 2, DATE_SUB(NOW(), INTERVAL 19 DAY), 240.00, 'Table for two.'),
(2, 'Farid',   'Hassan',   'farid.hassan@example.com',   '0400 111 206', 1, DATE_SUB(NOW(), INTERVAL 14 DAY), 120.00, 'Vegetarian meal.'),
(2, 'Grace',   'Liu',      'grace.liu@example.com',      '0400 111 207', 4, DATE_SUB(NOW(), INTERVAL  9 DAY), 480.00, 'Company table.'),
(2, 'Henry',   'Brooks',   'henry.brooks@example.com',   '0400 111 208', 2, DATE_SUB(NOW(), INTERVAL  3 DAY), 240.00, NULL),
(3, 'Isla',    'Fernandez','isla.fernandez@example.com', '0400 111 209', 2, DATE_SUB(NOW(), INTERVAL 11 DAY),   0.00, 'Free entry, will bid.'),
(3, 'Jack',    'Turner',   'jack.turner@example.com',    '0400 111 210', 1, DATE_SUB(NOW(), INTERVAL  8 DAY),   0.00, NULL),
(3, 'Grace',   'Liu',      'grace.liu@example.com',      '0400 111 207', 1, DATE_SUB(NOW(), INTERVAL  1 DAY),   0.00, 'Interested in the prints.');

-- ---------------------------------------------------------------------------
-- quick check after importing
-- ---------------------------------------------------------------------------
SELECT 'events' AS table_name, COUNT(*) AS rows_inserted FROM events
UNION ALL SELECT 'registrations', COUNT(*) FROM registrations
UNION ALL SELECT 'categories', COUNT(*) FROM categories
UNION ALL SELECT 'organisations', COUNT(*) FROM organisations;

-- ---------------------------------------------------------------------------
-- If the sample rows were already imported, this file will report duplicate
-- key errors for the events and registrations and the counts below will be
-- higher than 8 and 12. That is harmless (nothing is corrupted), but the
-- cleanest way to start over is to drop the four tables in phpMyAdmin and
-- import this file once.
-- ---------------------------------------------------------------------------
