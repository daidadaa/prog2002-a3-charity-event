﻿PROG2002 Web Development II - Assessment 3
WU Shaowei (202300408011 / 24832850) and team member

WHAT IS IN THIS FOLDER (the code deliverables)
----------------------------------------------
  wushaoweiA3-clientside.zip   the Angular 22 public website
  wushaoweiA3-adminside.zip    the Angular 22 staff/admin website
  wushaoweiA3-api.zip          the Node.js + Express + MySQL API
                               (contains charityevents_db.sql - import that first)

HOW TO RUN WHAT IS IN THE ZIPS
------------------------------
1. Import the database
     wushaoweiA3-api\charityevents_db.sql   -> run the whole file in MySQL Workbench
     (on the SCU cPanel use charityevents_db_cpanel.sql instead, because a shared
      cPanel account may not run CREATE DATABASE)

2. Start the API
     cd wushaoweiA3-api
     npm install
     copy .env.example to .env and put your MySQL password in it
     npm start                     -> http://localhost:3000

3. Start the websites (Angular 22 needs Node v22.22.3+, v24.15.0+ or v26.0.0+)
     cd wushaoweiA3-clientside ; npm install ; npx ng serve         -> :4200
     cd wushaoweiA3-adminside  ; npm install ; npx ng serve --port 4300

NOT INCLUDED IN THE ZIPS (on purpose)
-------------------------------------
  node_modules\   - 235 MB each, rebuilt with npm install
  dist\           - build output, rebuilt with ng build
  .env            - holds the MySQL password, must never be published
                    (.env.example IS included, listing the keys needed)
  generated docs  - rebuilt with "npm run docs" from the autodoc comments

STILL TO ADD BEFORE SUBMITTING (not code)
-----------------------------------------
  [ ] PROG2002_A3_Report.docx     the report (ERD, Angular extra work, AI use)
  [ ] GitHub repository link      private, with the marker and the teammate added
  [ ] Demo video link             max 15 minutes, SCU OneDrive, shareable
  [ ] Peer evaluation form        emailed to the TUTOR (not the UA), subject:
                                  PROG2002_A3_[Team_ID]_[Member_name]

Built with: Angular 22.2.2 + TypeScript 6.0.3, Node.js 24, Express 5.3.0,
MySQL 8.4, and the Open-Meteo weather API.
