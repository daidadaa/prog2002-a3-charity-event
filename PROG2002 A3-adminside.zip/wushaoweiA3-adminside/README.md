# wushaoweiA3-adminside — Kind Charity Events (staff administration)

Angular 22 administrative front end for the PROG2002 Web Development II
Assessment 3 charity-events project. It is the **staff** application: it manages
the events that the separate public (`wushaoweiA3-clientside`) site displays.

Back end: `../wushaoweiA3-api` (Express + MySQL), base URL
`http://localhost:3000`. The complete request/response contract is in
`../API-CONTRACT.md`.

## What it does

| View | Route | Feature |
|---|---|---|
| Dashboard | `/` | Totals, quick actions and the next active events |
| Event list | `/events` | **List** every event whatever its status, filter by status/text, **Delete** |
| New event | `/events/new` | **New** — reactive form, validated before `POST /api/events` |
| Edit event | `/events/:id/edit` | **Update** — pre-filled from `GET /api/admin/events/:id`, shows that event's registrations, saves with `PUT /api/events/:id` |

Authentication is not required (per the brief).

The navigation menu lives in the shell component (`src/app/app.ts`), so it is
present on every page.

### The 409 rule

`DELETE /api/events/:id` returns **409** when the event still has registrations:

```json
{ "error": "This event cannot be deleted because it already has 5 registration(s).",
  "registration_count": 5 }
```

That `error` sentence is rendered verbatim in a prominent red `role="alert"`
banner on the list page — the API is the authority and the UI never pretends the
delete worked. See `src/app/pages/event-list/event-list.ts` (`confirmDelete`).

## Architecture

```
Component (signals)  ->  EventApiService (typed HttpClient)  ->  Express  ->  MySQL
```

- `src/environments/environment.ts` — the API base URL (the service reads it; no
  URL is hard-coded in a component).
- `src/app/core/models.ts` — interfaces for every API shape.
- `src/app/core/event-api.service.ts` — one typed method per endpoint, plus
  normalisation of every `HttpErrorResponse` into an `ApiError`.
- `src/app/core/format.ts` — pure display helpers (`event_date` is sliced, never
  parsed with `new Date()`).
- Standalone components, **signals** (`signal` / `computed`), the new
  `@if` / `@for` / `@switch` control flow, and `ReactiveFormsModule`.

## Running it

The API must be started first:

```bash
cd ../wushaoweiA3-api
npm start
```

### This machine: Angular 22 needs the bundled Node

The system Node (v24) is too old for the Angular CLI here, so use the bundled
one:

```powershell
$node="C:\Users\ROG\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\node\bin\node.exe"
$ngjs="C:\Users\ROG\AppData\Roaming\npm\node_modules\@angular\cli\bin\ng.js"
Set-Location "D:\deepseek\PROG2002-A3\wushaoweiA3-adminside"
& $node $ngjs serve                  # http://localhost:4300  (client site uses 4200)
& $node $ngjs build                  # dist/wushaoweiA3-adminside/browser
& $node $ngjs test --watch=false     # 41 Vitest unit tests
```

`npm install` is not needed; `node_modules` is already present.

## Tests

`ng test` runs 24 Vitest tests (`src/app/**/*.spec.ts`). They cover the service's
URLs/methods and its 409 and 400 normalisation, the list page's status/text
filters, and — importantly — that the API's 409 sentence appears in a visible
alert in the DOM, and that the form refuses to send an invalid request.
