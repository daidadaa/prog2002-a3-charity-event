/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * @file app/app.ts
 */

import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { AdminFooter } from './shared/layout/admin-footer/admin-footer';
import { AdminHeader } from './shared/layout/admin-header/admin-header';
import { AdminNav } from './shared/layout/admin-nav/admin-nav';

/**
 * App - the shell component (`<app-root>`), i.e. the page FRAME.
 *
 * RESPONSIBILITY
 * Composes the four shared page segments in a fixed order and nothing else:
 *
 *   1. `<app-admin-header />`  - the Header segment
 *   2. `<app-admin-nav />`     - the Nav segment (the main menu)
 *   3. `<main id="main">`      - the Body segment, holding `<router-outlet />`
 *   4. `<app-admin-footer />`  - the Footer segment
 *
 * Each segment is a standalone component under `src/app/shared/layout/`, created
 * once and reused by every page, which is what the brief's "break your pages
 * into Header / Nav / Body / Footer" requirement asks for. Because the header,
 * the nav and the footer live here and not inside a page component, they are
 * present on every admin page automatically - the brief requires exactly that.
 *
 * DATA FLOW
 * This component holds no state and calls no API. Each page that the router
 * loads owns its own signals and its own EventApiService calls:
 *
 *   App (header | nav | body | footer)
 *        ->  `<router-outlet />`  ->  Dashboard | EventList | EventForm
 *                                          |
 *                                   EventApiService  ->  HttpClient
 *                                          |
 *                                Express  ->  MySQL
 *
 * @remarks
 * The shell is deliberately empty of logic: all of its behaviour used to be the
 * markup that now lives in the four segment components. Keeping it this small
 * means a page can be added (a new `loadComponent` route) without the shell
 * changing at all.
 *
 * @see {@link AdminHeader} for segment 1, {@link AdminNav} for segment 2 and
 * {@link AdminFooter} for segment 4.
 */
@Component({
  selector: 'app-root',
  imports: [RouterOutlet, AdminHeader, AdminNav, AdminFooter],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {}
