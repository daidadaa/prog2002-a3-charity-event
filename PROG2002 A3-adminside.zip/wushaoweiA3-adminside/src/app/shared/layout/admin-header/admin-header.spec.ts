import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { AdminHeader } from './admin-header';

/**
 * Tests for SEGMENT 1 OF 4 (the shared Header).
 *
 * The point of these tests is the graded claim that the header is a separate,
 * reusable component: the brand, the home link and the public-site link must be
 * rendered by THIS component on its own, without any page wrapping it.
 */
describe('AdminHeader (shared Header segment)', () => {
  let fixture: ComponentFixture<AdminHeader>;
  let host: HTMLElement;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdminHeader],
      providers: [provideRouter([])],
    }).compileComponents();

    fixture = TestBed.createComponent(AdminHeader);
    await fixture.whenStable();
    fixture.detectChanges();
    host = fixture.nativeElement as HTMLElement;
  });

  it('renders a real <header> landmark', () => {
    expect(host.querySelector('header')).toBeTruthy();
  });

  it('shows the brand block', () => {
    expect(host.textContent).toContain('Kind Charity Events');
    expect(host.textContent).toContain('Staff Administration');
  });

  it('links the brand back to the dashboard', () => {
    const brand = host.querySelector('a.brand') as HTMLAnchorElement;

    expect(brand.getAttribute('href')).toBe('/');
    expect(brand.getAttribute('aria-label')).toBe('Kind Charity Events admin home');
  });

  it('links out to the separate public site', () => {
    const link = host.querySelector('a.public-link') as HTMLAnchorElement;

    expect(link.getAttribute('href')).toBe('http://localhost:4200/');
    expect(link.getAttribute('target')).toBe('_blank');
    expect(link.getAttribute('rel')).toBe('noopener');
  });
});
