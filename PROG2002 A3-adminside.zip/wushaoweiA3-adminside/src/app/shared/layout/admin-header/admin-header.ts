/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * @file app/shared/layout/admin-header/admin-header.ts
 */

import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { environment } from '../../../../environments/environment';

/**
 * AdminHeader - SEGMENT 1 OF 4 of every admin page: the shared HEADER.
 *
 * This is one of the four page segments (Header, Nav, Body, Footer). It is
 * created ONCE here and shared by every page, because `<app-root>` renders it
 * once outside `<router-outlet />` - no page template contains a header of its
 * own. Editing this file therefore changes the header on the dashboard, the
 * event list and the create/edit form at the same time.
 *
 * Responsibility: the brand block ("Kind Charity Events" / "Staff
 * Administration"), which doubles as the home link, plus the link out to the
 * separate public (donor-facing) Angular site.
 */
@Component({
  selector: 'app-admin-header',
  imports: [RouterLink],
  templateUrl: './admin-header.html',
  styleUrl: './admin-header.css',
})
export class AdminHeader {
  /**
   * Base URL of the public donation site that the "View public site" link opens.
   *
   * @remarks
   * The public site is a separate Angular application, and after deployment the
   * two applications sit in different folders on the cPanel host. The address
   * therefore comes from `environment.clientSiteUrl` rather than being written
   * out here, otherwise the link would still point at localhost:4200 and be
   * broken for anyone using the deployed site.
   */
  protected readonly clientSiteUrl = environment.clientSiteUrl;
}
