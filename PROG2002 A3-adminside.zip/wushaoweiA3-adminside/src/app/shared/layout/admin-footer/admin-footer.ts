/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * @file app/shared/layout/admin-footer/admin-footer.ts
 */

import { Component } from '@angular/core';
import { environment } from '../../../../environments/environment';

/**
 * AdminFooter - SEGMENT 4 OF 4 of every admin page: the shared FOOTER.
 *
 * This is one of the four page segments (Header, Nav, Body, Footer). It is
 * created ONCE here and shared by every page, because `<app-root>` renders it
 * once outside `<router-outlet />` - no page template contains a footer of its
 * own.
 *
 * Responsibility: the ownership / assessment credit line and the reminder of
 * which API the staff actions are sent to. It calls no API itself; the Express
 * base URL is shown as text so staff can see what the site is talking to when
 * something fails.
 */
@Component({
  selector: 'app-admin-footer',
  templateUrl: './admin-footer.html',
  styleUrl: './admin-footer.css',
})
export class AdminFooter {
  /**
   * The Express API base URL, shown in the hint line.
   *
   * @remarks
   * Read from `environment.apiBaseUrl` instead of being typed into the template.
   * The address written into the markup used to be `http://localhost:3000`, which
   * was still displayed to staff after the site was deployed on the cPanel host
   * and pointed them at the wrong server.
   */
  protected readonly apiBaseUrl = environment.apiBaseUrl;
}
