import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AdminFooter } from './admin-footer';

/**
 * Tests for SEGMENT 4 OF 4 (the shared Footer).
 *
 * The footer is graded as a shared segment, so these tests assert that the
 * component renders the credit line and the API reminder by itself.
 */
describe('AdminFooter (shared Footer segment)', () => {
  let fixture: ComponentFixture<AdminFooter>;
  let host: HTMLElement;

  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [AdminFooter] }).compileComponents();

    fixture = TestBed.createComponent(AdminFooter);
    await fixture.whenStable();
    fixture.detectChanges();
    host = fixture.nativeElement as HTMLElement;
  });

  it('renders a real <footer> landmark', () => {
    expect(host.querySelector('footer')).toBeTruthy();
  });

  it('shows the assessment credit line', () => {
    expect(host.textContent).toContain('Kind Charity Events');
    expect(host.textContent).toContain('PROG2002 Web Development II, Assessment 3');
  });

  it('names the Express API the staff actions call', () => {
    expect(host.textContent).toContain('http://localhost:3000');
  });
});
