/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * @file app/shared/layout/admin-nav/admin-nav.ts
 */

import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';

/**
 * AdminNav - SEGMENT 2 OF 4 of every admin page: the shared NAV (main menu).
 *
 * This is one of the four page segments (Header, Nav, Body, Footer). It is
 * created ONCE here and shared by every page: `<app-root>` renders it once
 * outside `<router-outlet />`, so the menu is guaranteed to be present on the
 * dashboard, the event list and the create/edit form without any page template
 * repeating it. That is a graded requirement of the brief.
 *
 * Responsibility: the three top-level admin destinations and the "which one am
 * I on?" highlighting, which is delegated to Angular's `routerLinkActive`
 * directive rather than hand-rolled URL comparison.
 *
 * @remarks
 * Highlighting rules, which are easy to get subtly wrong:
 * - `routerLinkActive="active"` adds the `active` class to the link whose route
 *   is currently loaded, which is what the stylesheet colours.
 * - `[routerLinkActiveOptions]="{ exact: true }"` is set on the Dashboard and on
 *   "All events". Without it, "All events" (`/events`) would ALSO light up on
 *   `/events/new` and `/events/3/edit`, because those URLs start with `/events`.
 *   "New event" needs the default (prefix) match, which is a superset of its own
 *   route, so it stays correct either way.
 */
@Component({
  selector: 'app-admin-nav',
  imports: [RouterLink, RouterLinkActive],
  templateUrl: './admin-nav.html',
  styleUrl: './admin-nav.css',
})
export class AdminNav {}
