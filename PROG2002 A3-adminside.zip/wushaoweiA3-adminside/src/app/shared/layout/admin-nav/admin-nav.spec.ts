import { Component } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router, RouterOutlet, provideRouter } from '@angular/router';
import { AdminNav } from './admin-nav';

/** Placeholder page so the router has something to render in the outlet. */
@Component({ selector: 'app-blank-page', template: '' })
class BlankPage {}

/** Minimal host so the nav renders with a real router attached to it. */
@Component({
  selector: 'app-nav-host',
  imports: [AdminNav, RouterOutlet],
  template: '<app-admin-nav /><router-outlet />',
})
class NavHost {}

/**
 * Tests for SEGMENT 2 OF 4 (the shared Nav / main menu).
 *
 * Three things are graded here and each gets its own test:
 *   1. the menu links to every view, inside a real <nav> with an aria-label;
 *   2. the menu is a stand-alone component, so any page that renders it gets the
 *      full menu without repeating the markup;
 *   3. `routerLinkActiveOptions: { exact: true }` really does stop "All events"
 *      from staying highlighted on the child route `/events/new`.
 */
describe('AdminNav (shared Nav segment)', () => {
  let fixture: ComponentFixture<NavHost>;
  let host: HTMLElement;
  let router: Router;

  /**
   * Labels of the links the router currently considers active.
   *
   * @returns The trimmed text of every `.admin-nav a.active` element.
   */
  function activeLabels(): string[] {
    return Array.from(host.querySelectorAll('.admin-nav a.active')).map((link) =>
      (link.textContent ?? '').trim(),
    );
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [NavHost],
      providers: [
        provideRouter([
          { path: '', component: BlankPage },
          { path: 'events', component: BlankPage },
          { path: 'events/new', component: BlankPage },
          { path: 'events/:id/edit', component: BlankPage },
        ]),
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(NavHost);
    await fixture.whenStable();
    fixture.detectChanges();
    host = fixture.nativeElement as HTMLElement;
    router = TestBed.inject(Router);
  });

  it('renders a real <nav> landmark with an accessible name', () => {
    const nav = host.querySelector('nav');

    expect(nav).toBeTruthy();
    expect(nav?.getAttribute('aria-label')).toBe('Main menu');
  });

  it('offers Dashboard, All events and New event', () => {
    const links = Array.from(host.querySelectorAll('.admin-nav a'));

    expect(links.map((link) => (link.textContent ?? '').trim())).toEqual([
      'Dashboard',
      'All events',
      'New event',
    ]);
    expect(links.map((link) => link.getAttribute('href'))).toEqual(['/', '/events', '/events/new']);
  });

  it('highlights only the current page', async () => {
    await router.navigateByUrl('/events');
    await fixture.whenStable();
    fixture.detectChanges();

    expect(activeLabels()).toEqual(['All events']);
  });

  it('does NOT keep "All events" highlighted on /events/new (exact match)', async () => {
    await router.navigateByUrl('/events/new');
    await fixture.whenStable();
    fixture.detectChanges();

    expect(activeLabels()).toEqual(['New event']);
  });

  it('does NOT keep "All events" highlighted on the edit route either', async () => {
    await router.navigateByUrl('/events/3/edit');
    await fixture.whenStable();
    fixture.detectChanges();

    expect(activeLabels()).toEqual([]);
  });

  it('highlights Dashboard only on the dashboard', async () => {
    await router.navigateByUrl('/');
    await fixture.whenStable();
    fixture.detectChanges();

    expect(activeLabels()).toEqual(['Dashboard']);
  });
});
