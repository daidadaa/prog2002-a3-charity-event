/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * @file app/pages/dashboard/dashboard.ts
 */

import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { finalize } from 'rxjs';
import { EventApiService } from '../../core/event-api.service';
import { formatDateTime, money, percent } from '../../core/format';
import { ApiError, ApiEvent } from '../../core/models';

/**
 * Dashboard - the landing page (route '').
 *
 * WHY IT EXISTS
 * The brief says the admin interface must give staff "full control over the
 * event management" and be intuitive. Opening straight into a long table is
 * workable but unhelpful, so this page answers the three questions staff ask
 * first: how many events do we have, which ones need attention, and what is
 * coming up next. It then links into the three real screens.
 *
 * DATA SOURCE: `GET /api/admin/events` on the Express API, through
 * {@link EventApiService.getAdminEvents}.
 *
 * @remarks
 * DATA FLOW - exactly the same path as the list page (there is no separate
 * "stats" endpoint to invent):
 *
 * Deriving totals in a `computed()` rather than storing them in separate
 * signals means they can never disagree with the rows on screen - one source of
 * truth, several read-only projections.
 */
@Component({
  selector: 'app-dashboard',
  imports: [RouterLink],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css',
})
export class Dashboard implements OnInit {
  /** The API gateway used to load the events this page summarises. */
  private readonly api = inject(EventApiService);

  /** Raw rows from the API - the one source of truth for every tile on screen. */
  protected readonly events = signal<ApiEvent[]>([]);

  /** True while the initial (or retried) request is in flight. */
  protected readonly loading = signal(false);

  /** Friendly message when the load fails (typically "is the server running?"). */
  protected readonly loadError = signal('');

  /**
   * Headline numbers for the stat tiles.
   *
   * @returns Totals for the whole catalogue: row count, the three status counts,
   * registrations, tickets sold, the combined fundraising goal and the combined
   * amount raised.
   */
  protected readonly stats = computed(() => {
    const rows = this.events();
    const count = (status: string) => rows.filter((event) => event.display_status === status).length;
    return {
      total: rows.length,
      active: count('active'),
      past: count('past'),
      suspended: count('suspended'),
      registrations: rows.reduce((sum, event) => sum + (event.registration_count ?? 0), 0),
      tickets: rows.reduce((sum, event) => sum + (event.tickets_sold ?? 0), 0),
      goal: rows.reduce((sum, event) => sum + Number(event.fundraising_goal ?? 0), 0),
      raised: rows.reduce((sum, event) => sum + Number(event.amount_raised ?? 0), 0),
    };
  });

  /**
   * The next five events by date. Only Active ones matter here - a suspended
   * event is not "coming up", and Past ones are already over.
   *
   * @returns At most five {@link ApiEvent}s, earliest first.
   *
   * @remarks
   * `localeCompare` works on "YYYY-MM-DD HH:mm:ss" strings because that format
   * sorts lexicographically in the same order as chronologically (another
   * reason the API's string format is convenient - no Date maths needed).
   */
  protected readonly nextEvents = computed(() =>
    [...this.events()]
      .filter((event) => event.display_status === 'active')
      .sort((a, b) => a.event_date.localeCompare(b.event_date))
      .slice(0, 5),
  );

  /**
   * Overall progress towards every event's goal combined.
   *
   * @returns A whole number 0-100 for the summary progress bar.
   */
  protected readonly overallPercent = computed(() => percent(this.stats().raised, this.stats().goal));

  /** Loads the catalogue once, when the router first activates this page. */
  ngOnInit(): void {
    this.loading.set(true);
    this.api
      .getAdminEvents()
      .pipe(finalize(() => this.loading.set(false)))
      .subscribe({
        next: (rows) => this.events.set(rows),
        error: (err: ApiError) => this.loadError.set(err.message),
      });
  }

  /**
   * Template helper: pretty-prints an API timestamp.
   *
   * @param value - API date-time string, "YYYY-MM-DD HH:mm:ss".
   * @returns The friendly form produced by `formatDateTime`, e.g.
   * "Tue 27 Oct 2026, 6:30 am".
   */
  protected formatWhen(value: string): string {
    return formatDateTime(value);
  }

  /**
   * Template helper: formats money for an event row.
   *
   * @param value - Amount in AUD, or `null`/`undefined` when the API omitted it.
   * @returns The amount as Australian currency, e.g. "$18,000.00".
   */
  protected formatMoney(value: number | null | undefined): string {
    return money(value);
  }

  /**
   * Template helper: how far one event is towards its goal.
   *
   * @param event - The event whose progress bar is being drawn.
   * @returns A whole number 0-100, capped at 100 when the goal is met or beaten.
   */
  protected progress(event: ApiEvent): number {
    return percent(event.amount_raised, event.fundraising_goal);
  }
}
