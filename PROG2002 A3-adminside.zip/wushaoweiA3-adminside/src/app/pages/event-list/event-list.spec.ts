import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { Observable, of, throwError } from 'rxjs';
import { EventApiService } from '../../core/event-api.service';
import { ApiError, ApiEvent, MutationResult } from '../../core/models';
import { EventList } from './event-list';

/**
 * Tests for the listing page.
 *
 * The service is replaced with a hand-written double, so these tests describe
 * BEHAVIOUR (what the staff member sees) rather than HTTP plumbing:
 *   - all events are shown, whatever their display_status
 *   - the filters narrow the list
 *   - a successful delete confirms and refreshes
 *   - the 409 delete conflict prints the API's own sentence on screen
 *
 * That last one is the graded requirement, so it is asserted against the
 * rendered DOM (`nativeElement.textContent`), not against a component field:
 * if the banner were removed from the template, the test would fail.
 */

const EVENT_FIXTURE: ApiEvent[] = [
  {
    event_id: 1,
    name: 'Coastal Sunrise Fun Run',
    event_date: '2026-10-27 06:30:00',
    location: 'Lismore Riverside Park',
    latitude: -28.8135,
    longitude: 153.2773,
    purpose: 'Fund youth mental health outreach.',
    description: 'Choose a 5 km or 10 km riverside course.',
    ticket_price: 25,
    fundraising_goal: 18000,
    amount_raised: 7450,
    status: 'active',
    image_url: 'assets/images/coastal-sunrise-fun-run.jpg',
    organisation_id: 1,
    category_id: 1,
    category_name: 'Fun Run',
    organisation_name: 'Kind',
    organisation_mission: 'We bring neighbours together.',
    organisation_email: 'hello@kind.org',
    organisation_phone: '(02) 6600 2000',
    display_status: 'active',
    registration_count: 5,
    tickets_sold: 11,
  },
  {
    event_id: 7,
    name: 'Winter Makers Auction',
    event_date: '2025-07-01 10:00:00',
    location: 'Lismore Makers Hall',
    latitude: null,
    longitude: null,
    purpose: 'Fund repair workshops.',
    description: 'An auction of donated goods.',
    ticket_price: 0,
    fundraising_goal: 9000,
    amount_raised: 9000,
    status: 'active',
    image_url: 'assets/images/winter-makers-auction.jpg',
    organisation_id: 1,
    category_id: 3,
    category_name: 'Auction',
    organisation_name: 'Kind',
    organisation_mission: 'We bring neighbours together.',
    organisation_email: 'hello@kind.org',
    organisation_phone: '(02) 6600 2000',
    display_status: 'past',
    registration_count: 0,
    tickets_sold: 0,
  },
  {
    event_id: 8,
    name: 'Harbour Voices Concert',
    event_date: '2026-11-14 19:00:00',
    location: 'Yamba Community Hall',
    latitude: null,
    longitude: null,
    purpose: 'Fund shelter repairs.',
    description: 'A night of local choirs.',
    ticket_price: 35,
    fundraising_goal: 12000,
    amount_raised: 1200,
    status: 'suspended',
    image_url: 'assets/images/harbour-voices-concert.jpg',
    organisation_id: 1,
    category_id: 4,
    category_name: 'Concert',
    organisation_name: 'Kind',
    organisation_mission: 'We bring neighbours together.',
    organisation_email: 'hello@kind.org',
    organisation_phone: '(02) 6600 2000',
    display_status: 'suspended',
    registration_count: 0,
    tickets_sold: 0,
  },
];

/**
 * Minimal stand-in for {@link EventApiService}; each test can override one
 * method with `vi.spyOn` to describe a failure that the real API could return.
 */
class ApiDouble {
  /**
   * @returns Every fixture row, i.e. all three display statuses.
   */
  getAdminEvents(): Observable<ApiEvent[]> {
    return of(EVENT_FIXTURE);
  }

  /**
   * @param id - `event_id` the component asked to delete.
   * @returns A successful DELETE response naming that id.
   */
  deleteEvent(id: number): Observable<MutationResult> {
    return of({ message: `Event ${id} was deleted.`, event_id: id });
  }
}

describe('EventList', () => {
  let fixture: ComponentFixture<EventList>;
  let api: ApiDouble;

  /**
   * Creates the component with the API double injected and waits for the first
   * load to settle, so each test starts from a rendered list.
   */
  async function build(): Promise<void> {
    await TestBed.configureTestingModule({
      imports: [EventList],
      providers: [{ provide: EventApiService, useValue: api }, provideRouter([])],
    }).compileComponents();

    fixture = TestBed.createComponent(EventList);
    fixture.detectChanges(); // triggers ngOnInit -> load()
    await fixture.whenStable();
    fixture.detectChanges();
  }

  beforeEach(() => {
    api = new ApiDouble();
  });

  it('lists every event whatever its status', async () => {
    await build();
    const text = fixture.nativeElement.textContent as string;

    expect(text).toContain('Coastal Sunrise Fun Run');
    expect(text).toContain('Winter Makers Auction'); // past
    expect(text).toContain('Harbour Voices Concert'); // suspended
  });

  it('renders a coloured status badge for each display_status', async () => {
    await build();
    const badges = fixture.nativeElement.querySelectorAll('.badge') as NodeListOf<HTMLElement>;
    const classes = Array.from(badges).map((badge) => badge.className);

    expect(classes).toContain('badge badge-active');
    expect(classes).toContain('badge badge-past');
    expect(classes).toContain('badge badge-suspended');
  });

  it('filters by status', async () => {
    await build();
    fixture.componentInstance['setStatusFilter']('suspended');
    fixture.detectChanges();

    const text = fixture.nativeElement.textContent as string;
    expect(text).toContain('Harbour Voices Concert');
    expect(text).not.toContain('Coastal Sunrise Fun Run');
  });

  it('filters by free text across name, location and purpose', async () => {
    await build();
    fixture.componentInstance['onSearch']('makers hall');
    fixture.detectChanges();

    expect(fixture.nativeElement.textContent).toContain('Winter Makers Auction');
    expect(fixture.nativeElement.textContent).not.toContain('Coastal Sunrise Fun Run');
  });

  it('confirms a successful delete and reloads the list', async () => {
    await build();
    const reload = vi.spyOn(api, 'getAdminEvents');

    fixture.componentInstance['askDelete'](EVENT_FIXTURE[1]);
    fixture.detectChanges();
    fixture.componentInstance['confirmDelete']();
    fixture.detectChanges();

    expect(fixture.nativeElement.textContent).toContain('Event 7 was deleted.');
    expect(reload).toHaveBeenCalledTimes(1); // once for ngOnInit, once for the refresh
  });

  it('SHOWS THE API 409 MESSAGE IN A VISIBLE ALERT when a delete is refused', async () => {
    // This is the graded data-integrity behaviour.
    const conflict: ApiError = {
      status: 409,
      message: 'This event cannot be deleted because it already has 5 registration(s).',
      fields: {},
      registrationCount: 5,
    };
    vi.spyOn(api, 'deleteEvent').mockReturnValue(throwError(() => conflict));

    await build();
    fixture.componentInstance['askDelete'](EVENT_FIXTURE[0]);
    fixture.detectChanges();
    fixture.componentInstance['confirmDelete']();
    fixture.detectChanges();

    const host: HTMLElement = fixture.nativeElement;
    const alert = host.querySelector('.alert-error');

    // 1. a real, prominent alert element exists
    expect(alert).toBeTruthy();
    expect(alert?.getAttribute('role')).toBe('alert');

    // 2. it contains the server's exact sentence, verbatim
    expect(alert?.textContent).toContain(
      'This event cannot be deleted because it already has 5 registration(s).',
    );

    // 3. it explains the consequence, and the row is still in the table
    expect(alert?.textContent).toContain('5 registration record(s)');
    expect(host.textContent).toContain('Coastal Sunrise Fun Run');
  });

  it('shows a load error with a retry action when the API is down', async () => {
    vi.spyOn(api, 'getAdminEvents').mockReturnValue(
      throwError(() => ({
        status: 0,
        message: 'Cannot reach the API at http://localhost:3000. Is the server running?',
        fields: {},
      })),
    );
    await build();

    const text = fixture.nativeElement.textContent as string;
    expect(text).toContain('Could not load events');
    expect(text).toContain('Is the server running?');
  });
});
