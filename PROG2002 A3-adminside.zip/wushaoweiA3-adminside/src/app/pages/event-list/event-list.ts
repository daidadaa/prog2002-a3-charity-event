/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * @file app/pages/event-list/event-list.ts
 */

import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { finalize } from 'rxjs';
import { EventApiService } from '../../core/event-api.service';
import { formatDateTime, money, percent } from '../../core/format';
import { ApiError, ApiEvent, DisplayStatus } from '../../core/models';

/**
 * EventList - the main admin listing (the "List" requirement).
 *
 * WHAT IT DOES
 *  1. Loads EVERY event whatever its status from `GET /api/admin/events`.
 *  2. Shows the key admin columns: name, category, date/time, location, ticket
 *     price, fundraising progress, registrations and tickets sold.
 *  3. Renders `display_status` (active / past / suspended) as a coloured badge.
 *  4. Filters the loaded rows client-side by status and free text. Filtering is
 *     done in memory because the admin endpoint already returns the whole
 *     catalogue (8 rows): a `computed()` re-filters instantly on every
 *     keystroke with no network round trip, and no event can be hidden from
 *     staff by a server-side default.
 *  5. Deletes an event after a confirmation, and - the graded behaviour -
 *     displays the 409 "cannot delete because it has N registrations" message
 *     from the server in a loud red banner.
 *
 * DATA SOURCE: `GET /api/admin/events` and `DELETE /api/events/:id` on the
 * Express API, through {@link EventApiService}.
 *
 * @remarks
 * DATA FLOW:
 *
 * The server is the authority on whether a row may be deleted; this component
 * only reports what the API decided, so the UI can never claim a delete
 * succeeded when MySQL refused it.
 */
@Component({
  selector: 'app-event-list',
  imports: [RouterLink, FormsModule],
  templateUrl: './event-list.html',
  styleUrl: './event-list.css',
})
export class EventList implements OnInit {
  /** The API gateway for both loading the list and deleting a row. */
  private readonly api = inject(EventApiService);

  /** The raw API rows - the single source of truth for everything on screen. */
  protected readonly events = signal<ApiEvent[]>([]);

  /** True while the list is being (re)loaded from the API. */
  protected readonly loading = signal(false);

  /** Friendly message shown when the list could not be loaded at all. */
  protected readonly loadError = signal('');

  /**
   * Status chip / `<select>` state: 'all' | 'active' | 'past' | 'suspended'.
   *
   * @remarks `'all'` is not an {@link DisplayStatus}: it means "no status filter".
   */
  protected readonly statusFilter = signal<'all' | DisplayStatus>('all');

  /** Free-text search box state; matched case-insensitively against several fields. */
  protected readonly textFilter = signal('');

  /** The event the staff member clicked Delete on, pending confirmation. */
  protected readonly pendingDelete = signal<ApiEvent | null>(null);

  /** The event currently being deleted (drives the "Deleting..." label). */
  protected readonly deleting = signal<ApiEvent | null>(null);

  /**
   * The loud, persistent error banner. Holds the server's own `error` string for
   * a refused delete, or a generic message for other failures.
   */
  protected readonly errorMessage = signal('');

  /** A second line of context under the error banner (why the delete was blocked). */
  protected readonly errorHint = signal('');

  /** The success banner ("... has been deleted."). */
  protected readonly successMessage = signal('');

  /**
   * Counters shown on the status chips.
   *
   * @returns How many loaded rows are in each display status, plus the total.
   */
  protected readonly counts = computed(() => {
    const rows = this.events();
    return {
      all: rows.length,
      active: rows.filter((e) => e.display_status === 'active').length,
      past: rows.filter((e) => e.display_status === 'past').length,
      suspended: rows.filter((e) => e.display_status === 'suspended').length,
    };
  });

  /**
   * The rows actually rendered: status filter AND text filter applied.
   *
   * @returns The subset of `events` that matches both controls.
   *
   * @remarks
   * A `computed()` is a cached derived signal - Angular recalculates it only
   * when `events`, `statusFilter` or `textFilter` change.
   */
  protected readonly visibleEvents = computed(() => {
    const status = this.statusFilter();
    const needle = this.textFilter().trim().toLowerCase();

    return this.events().filter((event) => {
      if (status !== 'all' && event.display_status !== status) {
        return false;
      }
      if (!needle) {
        return true;
      }
      // Free-text search across the fields staff would realistically search by.
      const haystack = [
        event.name,
        event.category_name,
        event.location,
        event.purpose,
        event.description,
      ]
        .join(' ')
        .toLowerCase();
      return haystack.includes(needle);
    });
  });

  /** Loads the list as soon as the router activates this page. */
  ngOnInit(): void {
    // A brand-new event or a save redirects back here with ?created=1 / ?saved=1
    // so the staff member gets confirmation that the write succeeded.
    this.showFlashFromUrl();
    this.load();
  }

  /**
   * GET /api/admin/events -> the `events` signal.
   *
   * @remarks Used for the first load, for the retry button and after a
   * successful delete, so the table always shows what MySQL holds rather than
   * what this component guessed.
   */
  protected load(): void {
    this.loading.set(true);
    this.loadError.set('');
    this.api
      .getAdminEvents()
      .pipe(finalize(() => this.loading.set(false)))
      .subscribe({
        next: (rows) => this.events.set(rows),
        error: (err: ApiError) => this.loadError.set(err.message),
      });
  }

  /**
   * Clicking a status chip.
   *
   * @param status - The chip that was clicked: a display status, or `'all'`.
   *
   * @remarks Kept as a method so the template stays declarative and the chips,
   * the `<select>` and the counts all share one state value.
   */
  protected setStatusFilter(status: 'all' | DisplayStatus): void {
    this.statusFilter.set(status);
  }

  /**
   * Bound to the search box.
   *
   * @param value - Current text of the search input, on every keystroke.
   */
  protected onSearch(value: string): void {
    this.textFilter.set(value);
  }

  /**
   * Bound to the status `<select>`.
   *
   * @param value - The `<option>` value as a plain string; narrowed to the
   * filter union before it reaches the signal.
   */
  protected onStatusChange(value: string): void {
    this.statusFilter.set(value as 'all' | DisplayStatus);
  }

  /** Resets the search box and the status filter back to "everything". */
  protected clearFilters(): void {
    this.statusFilter.set('all');
    this.textFilter.set('');
  }

  /**
   * Step 1 of deleting: ask for confirmation (never delete straight from a click).
   *
   * @param event - The row whose Delete button was pressed.
   *
   * @remarks Also clears the previous banners, so a stale error cannot sit next
   * to a fresh confirmation prompt.
   */
  protected askDelete(event: ApiEvent): void {
    this.successMessage.set('');
    this.errorMessage.set('');
    this.errorHint.set('');
    this.pendingDelete.set(event);
  }

  /** Dismisses the confirmation prompt without calling the API. */
  protected cancelDelete(): void {
    this.pendingDelete.set(null);
  }

  /**
   * Step 2 of deleting: actually DELETE the selected event.
   *
   * The server is the authority here. It checks (in SQL) whether the event has
   * registrations and answers 409 if it does; only then do we know the delete
   * is genuinely refused:
   *
   *   200 -> `{ message, event_id }`  : removed, so reload the list.
   *   409 -> `{ error, registration_count }`: refused. We surface `error`
   *          verbatim in the red banner. We do NOT pretend it worked, and we do
   *          not offer to force it - the FK/registration rows must stay intact.
   *   404 -> already gone: tell the user and reload so the table is honest.
   *
   * @remarks No-op when no row is pending confirmation, which also protects
   * against a double click firing two DELETEs.
   */
  protected confirmDelete(): void {
    const target = this.pendingDelete();
    if (!target) {
      return;
    }

    this.deleting.set(target);
    this.errorMessage.set('');
    this.errorHint.set('');

    this.api
      .deleteEvent(target.event_id)
      .pipe(finalize(() => this.deleting.set(null)))
      .subscribe({
        next: (result) => {
          this.pendingDelete.set(null);
          this.successMessage.set(result.message || `"${target.name}" was deleted.`);
          // Refresh so the table reflects the database, not our guess.
          this.load();
        },
        error: (err: ApiError) => {
          this.pendingDelete.set(null);
          // `err.message` IS the API's own text, e.g.
          // "This event cannot be deleted because it already has 5 registration(s)."
          this.errorMessage.set(err.message);
          if (err.status === 409) {
            // Extra context, still based on the server's data.
            const count = err.registrationCount ?? target.registration_count ?? 0;
            this.errorHint.set(
              `Blocked by the API to protect the ${count} registration record(s) already linked to this event. ` +
                'Suspend the event instead of deleting it, or remove the registrations first.',
            );
          } else if (err.status === 404) {
            this.errorHint.set('The list has been refreshed.');
            this.load();
          }
        },
      });
  }

  /**
   * Progress towards the fundraising goal, 0-100, for the inline bar.
   *
   * @param event - The row being drawn.
   * @returns A whole number 0-100, capped when the goal is met or beaten.
   */
  protected progress(event: ApiEvent): number {
    return percent(event.amount_raised, event.fundraising_goal);
  }

  /**
   * CSS class for a display_status badge.
   *
   * @param status - The row's derived status.
   * @returns The `badge badge-<status>` class string the stylesheet colours.
   */
  protected badgeClass(status: DisplayStatus): string {
    return `badge badge-${status}`;
  }

  /**
   * Template helper: pretty-prints an API timestamp.
   *
   * @param value - API date-time string, "YYYY-MM-DD HH:mm:ss".
   * @returns The friendly form, e.g. "Tue 27 Oct 2026, 6:30 am".
   */
  protected formatWhen(value: string): string {
    return formatDateTime(value);
  }

  /**
   * Template helper: formats money for a row.
   *
   * @param value - Amount in AUD.
   * @returns The amount as Australian currency, e.g. "$25.00".
   */
  protected formatMoney(value: number): string {
    return money(value);
  }

  /**
   * Reads ?created=1 / ?saved=1 / ?deleted=1, then cleans the URL so a refresh
   * does not repeat the message.
   *
   * @remarks
   * The create/edit form navigates here with a query flag instead of pushing a
   * message into this component's state, which keeps the two pages independent.
   * `history.replaceState` removes the flag once it has been consumed.
   */
  private showFlashFromUrl(): void {
    if (typeof window === 'undefined') {
      return;
    }
    const params = new URLSearchParams(window.location.search);
    const created = params.get('created') === '1';
    const saved = params.get('saved') === '1';
    const deleted = params.get('deleted') === '1';

    if (created) {
      this.successMessage.set('New event created successfully.');
    } else if (saved) {
      this.successMessage.set('Event updated successfully.');
    } else if (deleted) {
      this.successMessage.set('Event deleted.');
    }

    if (created || saved || deleted) {
      window.history.replaceState({}, '', window.location.pathname);
    }
  }
}
