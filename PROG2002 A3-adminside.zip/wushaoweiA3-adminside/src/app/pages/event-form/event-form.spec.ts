import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { Observable, of, throwError } from 'rxjs';
import { EventApiService } from '../../core/event-api.service';
import {
  ApiError,
  ApiEvent,
  Category,
  EventDetail,
  EventPayload,
  MutationResult,
} from '../../core/models';
import { EventForm } from './event-form';

/**
 * Tests for the create/edit form ({@link EventForm}).
 *
 * They cover the two things the brief marks: validation happening BEFORE the
 * request is sent, and the server's 400 `fields` map being shown next to the
 * matching inputs. The API is doubled, so no server is needed.
 */

const CATEGORIES: Category[] = [
  { category_id: 1, name: 'Fun Run', description: 'Runs and walks' },
  { category_id: 2, name: 'Gala Dinner', description: 'Formal dinners' },
];

const EVENT: ApiEvent = {
  event_id: 2,
  name: 'Light the Way Gala',
  event_date: '2026-11-21 18:30:00',
  location: 'Lismore City Hall',
  latitude: -28.81,
  longitude: 153.28,
  purpose: 'Fund solar lighting for rural clinics.',
  description: 'A black-tie dinner with a live auction.',
  ticket_price: 120,
  fundraising_goal: 30000,
  amount_raised: 18400,
  status: 'active',
  image_url: 'assets/images/light-the-way-gala.jpg',
  organisation_id: 1,
  category_id: 2,
  category_name: 'Gala Dinner',
  organisation_name: 'Kind',
  organisation_mission: 'We bring neighbours together.',
  organisation_email: 'hello@kind.org',
  organisation_phone: '(02) 6600 2000',
  display_status: 'active',
  registration_count: 4,
  tickets_sold: 9,
};

const DETAIL: EventDetail = {
  event: EVENT,
  registrations: [
    {
      registration_id: 5,
      first_name: 'Emma',
      last_name: 'Rossi',
      email: 'emma.rossi@example.com',
      phone: '0400 111 205',
      tickets: 3,
      registration_date: '2026-10-19 18:18:47',
      total_amount: 360,
      notes: 'Work team.',
    },
  ],
  summary: {
    registration_count: 4,
    tickets_sold: 9,
    amount_registered: 1080,
    latest_registration: '2026-10-19 18:18:47',
  },
};

/**
 * Hand-written double for {@link EventApiService}.
 *
 * It answers with the fixtures above so the tests can describe form behaviour
 * without an HTTP layer; individual tests override one method when they need a
 * failure response.
 */
class ApiDouble {
  /**
   * @returns The two fixture categories, as `GET /api/categories` would.
   */
  getCategories(): Observable<Category[]> {
    return of(CATEGORIES);
  }

  /**
   * @param id - `event_id` from the route; echoed back so the test can prove the
   * component asked for the event it is editing.
   * @returns The fixture detail, with the event re-stamped to that id.
   */
  getAdminEvent(id: number): Observable<EventDetail> {
    return of({ ...DETAIL, event: { ...EVENT, event_id: id } });
  }

  /**
   * @param payload - Body the component built; ignored by the double.
   * @returns A 201-style success body.
   */
  createEvent(payload: EventPayload): Observable<MutationResult> {
    return of({ message: 'The event was created.', event_id: 9 });
  }

  /**
   * @param id - Id of the event being updated.
   * @param payload - Body the component built; asserted through `vi.spyOn`.
   * @returns A 200-style success body naming that id.
   */
  updateEvent(id: number, payload: EventPayload): Observable<MutationResult> {
    return of({ message: 'The event was updated.', event_id: id });
  }
}

/**
 * The component's protected members are reached through a cast - tests are
 * allowed to inspect internals; the template only ever sees public API.
 *
 * @remarks
 * `build()` returns this narrow view instead of the component type so that the
 * casts are declared once, here, rather than repeated in every test.
 */
type FormInternals = {
  id?: string;
  form: { patchValue(value: Record<string, unknown>): void; get(path: string): any };
  submit(): void;
  serverFieldErrors(): Record<string, string>;
};

describe('EventForm', () => {
  let fixture: ComponentFixture<EventForm>;
  let api: ApiDouble;

  /**
   * Creates the form and waits for its first load to settle.
   *
   * @param id - Route parameter to set on the component; omit it to render the
   * create screen (`/events/new`), pass `'2'` for edit mode.
   * @returns A cast view of the component exposing the members the tests drive.
   */
  async function build(id?: string): Promise<FormInternals> {
    await TestBed.configureTestingModule({
      imports: [EventForm],
      providers: [{ provide: EventApiService, useValue: api }, provideRouter([])],
    }).compileComponents();

    fixture = TestBed.createComponent(EventForm);
    if (id !== undefined) {
      fixture.componentRef.setInput('id', id);
    }
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    return fixture.componentInstance as unknown as FormInternals;
  }

  beforeEach(() => {
    api = new ApiDouble();
  });

  it('populates the category select from GET /api/categories', async () => {
    await build();
    const options = fixture.nativeElement.querySelectorAll('#category_id option') as NodeListOf<HTMLOptionElement>;
    const labels = Array.from(options).map((option) => option.textContent?.trim());

    expect(labels).toContain('Fun Run');
    expect(labels).toContain('Gala Dinner');
  });

  it('does NOT send a request when required fields are missing', async () => {
    const create = vi.spyOn(api, 'createEvent');
    const component = await build();

    component.submit();
    fixture.detectChanges();

    expect(create).not.toHaveBeenCalled();
    // and the user is told why, inline
    expect(fixture.nativeElement.textContent).toContain('This field is required.');
  });

  it('pre-fills the form and shows the registrations in edit mode', async () => {
    await build('2');
    const text = fixture.nativeElement.textContent as string;
    const nameInput = fixture.nativeElement.querySelector('#name') as HTMLInputElement;

    expect(nameInput.value).toBe('Light the Way Gala');
    // datetime-local needs "YYYY-MM-DDTHH:mm" - the API sends a space
    const dateInput = fixture.nativeElement.querySelector('#event_date') as HTMLInputElement;
    expect(dateInput.value).toBe('2026-11-21T18:30');

    // the explicit brief requirement: staff can see who registered
    expect(text).toContain('Emma Rossi');
    expect(text).toContain('emma.rossi@example.com');
    expect(text).toContain('Registrations');
  });

  it('warns that an event with registrations cannot be deleted', async () => {
    await build('2');
    expect(fixture.nativeElement.textContent).toContain('This event cannot be deleted');
  });

  it('sends a valid payload through PUT in edit mode', async () => {
    const update = vi.spyOn(api, 'updateEvent');
    const component = await build('2');

    component.submit();
    fixture.detectChanges();

    expect(update).toHaveBeenCalledTimes(1);
    const [id, payload] = update.mock.calls[0];
    expect(id).toBe(2);
    expect(payload.name).toBe('Light the Way Gala');
    expect(payload.amount_raised).toBe(18400); // preserved from the loaded event
    expect(payload.image_url).toBe('assets/images/light-the-way-gala.jpg');
  });

  it('renders the server 400 fields map next to the inputs', async () => {
    const badRequest: ApiError = {
      status: 400,
      message: 'Please correct the highlighted fields.',
      fields: { name: 'The event name is required.' },
    };
    vi.spyOn(api, 'createEvent').mockReturnValue(throwError(() => badRequest));

    const component = await build();
    // Make the form valid so the request is actually attempted, then let the
    // server reject it - the point is that a server error is displayed.
    component.form.patchValue({
      category_id: 1,
      name: 'Something',
      event_date: '2027-03-15T07:00',
      location: 'Lismore Makers Hall',
      purpose: 'Fund repair workshops.',
      description: 'A community market of local makers.',
      ticket_price: 20,
      fundraising_goal: 5000,
      status: 'active',
      image_url: '',
    });

    component.submit();
    fixture.detectChanges();

    expect(component.serverFieldErrors()['name']).toBe('The event name is required.');
    const text = fixture.nativeElement.textContent as string;
    expect(text).toContain('The server rejected this form');
    expect(text).toContain('The event name is required.');
    expect(text).toContain('Server: The event name is required.');
  });
});
