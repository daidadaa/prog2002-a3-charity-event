/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * @file app/pages/event-form/event-form.ts
 */

import { Component, Input, OnInit, computed, inject, signal } from '@angular/core';
import {
  AbstractControl,
  FormBuilder,
  ReactiveFormsModule,
  ValidationErrors,
  Validators,
} from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { finalize } from 'rxjs';
import { EventApiService } from '../../core/event-api.service';
import { formatDateTime, money, toDateTimeLocal } from '../../core/format';
import {
  ApiError,
  ApiEvent,
  ApiRegistration,
  Category,
  EventDetail,
  EventPayload,
  RegistrationSummary,
  StoredStatus,
} from '../../core/models';

/**
 * Fallback image already shipped in public/assets/images (per the contract).
 *
 * @remarks
 * Stored in the database as a path, not a file, so the browser can request it
 * straight from the `public/` folder that Angular copies into the build.
 */
const PLACEHOLDER_IMAGE = 'assets/images/event-placeholder.jpg';

/**
 * Custom validator for the `<input type="datetime-local">` value.
 *
 * The control's value is "YYYY-MM-DDTHH:mm" or an empty string (a browser gives
 * an empty string for anything it cannot parse), so the format check is simple.
 *
 * @param control - The Angular control being validated.
 * @returns `null` when the value is empty (handled by `Validators.required`) or
 * matches "YYYY-MM-DDTHH:mm"; otherwise `{ datetimeFormat: true }`.
 *
 * @remarks
 * This lives here rather than inside the builder because the same rule is used
 * by the create form and the edit form - this component is both.
 */
function datetimeLocalFormat(control: AbstractControl): ValidationErrors | null {
  const value = String(control.value ?? '');
  if (!value) {
    return null; // Validators.required handles "empty"
  }
  return /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(value) ? null : { datetimeFormat: true };
}

/**
 * Builds a validator that accepts an empty value, but otherwise requires a
 * number inside an inclusive range. Coordinates are optional, but if one is
 * typed it must be a sane number.
 *
 * @param min - Smallest acceptable value, inclusive (e.g. -90 for latitude).
 * @param max - Largest acceptable value, inclusive (e.g. 90 for latitude).
 * @param key - Error key to report, so the template's `MESSAGES` lookup can find
 * the right sentence (e.g. `'latitudeRange'`).
 * @returns An Angular validator function for one control: `null` when it passes,
 * `{ [key]: true }` when it does not.
 *
 * @example
 */
function optionalRange(min: number, max: number, key: string) {
  /**
   * The generated validator for one control.
   *
   * @param control - The Angular control being validated.
   * @returns `null` for a blank value or a number inside `[min, max]`; otherwise
   * `{ [key]: true }` so the matching human message can be shown.
   */
  const validator = (control: AbstractControl): ValidationErrors | null => {
    const raw = control.value;
    if (raw === null || raw === undefined || raw === '') {
      return null;
    }
    const parsed = Number(raw);
    if (Number.isNaN(parsed)) {
      return { [key]: true };
    }
    return parsed >= min && parsed <= max ? null : { [key]: true };
  };
  return validator;
}

/**
 * Human text for each built-in / custom validation error, shown under the input.
 *
 * @remarks
 * The keys are the error keys Angular puts in `control.errors`, so
 * `clientError()` can take the first key it finds and read the sentence from
 * here - the wording lives in one place instead of being repeated in the
 * template for every field.
 */
const MESSAGES: Record<string, string> = {
  required: 'This field is required.',
  min: 'The value is too small.',
  max: 'The value is too large.',
  minlength: 'This is too short.',
  maxlength: 'This is too long.',
  pattern: 'Please check the format of this value.',
  datetimeFormat: 'Enter a valid date and time.',
  latitudeRange: 'Latitude must be a number between -90 and 90.',
  longitudeRange: 'Longitude must be a number between -180 and 180.',
};

/**
 * EventForm - ONE component serving both the "New" and the "Update" screen,
 * because the fields, the rules and the payload are the same:
 *
 *   /events/new        -> `id` undefined -> create mode -> POST /api/events
 *   /events/:id/edit   -> `id` set       -> edit mode   -> PUT  /api/events/:id
 *
 * @remarks
 * The `isEditMode` computed signal drives the small differences: the heading, the
 * button label, whether an existing event is loaded, and whether the registrations
 * panel appears. Duplicating the form would mean fixing every future rule twice.
 *
 * Validation has two layers on purpose: Angular validators give instant inline
 * feedback, then the server re-validates and answers 400 with `{ error, fields }`.
 * The browser is never trusted, so on a 400 each message is printed under its own
 * input. After a successful create the component navigates to `/events?created=1`
 * rather than editing the list's state directly.
 *
 * @see {@link EventPayload} for the exact body this component sends.
 */
@Component({
  selector: 'app-event-form',
  imports: [ReactiveFormsModule, RouterLink],
  templateUrl: './event-form.html',
  styleUrl: './event-form.css',
})
export class EventForm implements OnInit {
  /** The API gateway for loading the event/categories and for saving. */
  private readonly api = inject(EventApiService);

  /** Used to leave the form after a successful create (and to reach the list). */
  private readonly router = inject(Router);

  /** Reactive Forms builder; every control and rule is declared once, below. */
  private readonly fb = inject(FormBuilder);

  /**
   * Route parameter injected by the router thanks to
   * `withComponentInputBinding()` in app.config.ts. It is a STRING for the
   * parameterised route and `undefined` for /events/new.
   */
  @Input() id?: string;

  /** Categories from `GET /api/categories`, used to fill the `<select>`. */
  protected readonly categories = signal<Category[]>([]);

  /** People registered for the event being edited (empty in create mode). */
  protected readonly registrations = signal<ApiRegistration[]>([]);

  /** Server-computed roll-ups for the registrations panel; `null` until loaded. */
  protected readonly summary = signal<RegistrationSummary | null>(null);

  /** The event as the API last returned it; also used to preserve `amount_raised`. */
  protected readonly loadedEvent = signal<ApiEvent | null>(null);

  /** True while the existing event is being fetched (edit mode only). */
  protected readonly loading = signal(false);

  /** True while a POST/PUT is in flight; disables the Save button. */
  protected readonly saving = signal(false);

  /** Message shown when the event could not be loaded. */
  protected readonly loadError = signal('');

  /** Form-level message from a 400 (`error`), or any other failure. */
  protected readonly serverError = signal('');

  /** Per-field messages from a 400 (`fields`) - keyed by control name. */
  protected readonly serverFieldErrors = signal<Record<string, string>>({});

  /** Shown briefly at the top of the form after a successful save (edit mode). */
  protected readonly successMessage = signal('');

  /**
   * True when the route supplied a real `event_id`.
   *
   * @returns `false` for `/events/new` (and for the literal string 'new'), `true`
   * for `/events/:id/edit`.
   */
  protected readonly isEditMode = computed(() => Boolean(this.id && this.id !== 'new'));

  /** True once Save has been pressed at least once (shows every inline error at once). */
  protected readonly submitted = signal(false);

  /**
   * The route parameter as a number, for the service calls.
   *
   * @returns The numeric event id (`NaN` in create mode, which is never used).
   */
  protected readonly eventId = computed(() => Number(this.id));

  /**
   * The typed Reactive Form.
   *
   * Reactive (model-driven) rather than template-driven because the rubric
   * values testable, explicitly declared validation: every rule is readable in
   * one place, the component owns the `FormGroup`, and a unit test can inspect
   * `form.valid` / `form.controls['name'].errors` without touching the DOM.
   *
   * @remarks
   * The control names match the HTML `id`s so that `document.getElementById()`
   * can focus the first invalid input after a failed submit.
   */
  protected readonly form = this.fb.group({
    category_id: [0, [Validators.required, Validators.min(1)]],
    name: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(120)]],
    event_date: ['', [Validators.required, datetimeLocalFormat]],
    location: ['', [Validators.required, Validators.maxLength(160)]],
    latitude: [null as number | null, [optionalRange(-90, 90, 'latitudeRange')]],
    longitude: [null as number | null, [optionalRange(-180, 180, 'longitudeRange')]],
    purpose: ['', [Validators.required, Validators.maxLength(300)]],
    description: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(2000)]],
    ticket_price: [0, [Validators.required, Validators.min(0), Validators.max(100000)]],
    fundraising_goal: [0, [Validators.required, Validators.min(0), Validators.max(100000000)]],
    status: ['active' as StoredStatus, [Validators.required]],
    image_url: ['', [Validators.maxLength(255)]],
  });

  /**
   * Loads the category list, and in edit mode the event itself.
   *
   * @remarks The two requests are independent, so they are not chained; the
   * template shows their progress separately.
   */
  ngOnInit(): void {
    this.loadCategories();
    if (this.isEditMode()) {
      this.loadEvent(this.eventId());
    }
  }

  /**
   * GET /api/categories - fills the `<select>` so ids can never be wrong.
   *
   * @remarks On failure the message is put in `serverError` rather than
   * `loadError`, because the form itself is still usable (the category list is
   * supporting data, not the page's subject).
   */
  private loadCategories(): void {
    this.api.getCategories().subscribe({
      next: (rows) => this.categories.set(rows),
      error: (err: ApiError) => this.serverError.set(err.message),
    });
  }

  /**
   * GET /api/admin/events/:id - loads the event AND its registrations.
   *
   * @param id - Numeric `event_id` from the route.
   *
   * @remarks
   * `patchValue` copies only the fields we name, so the API's extra columns
   * (organisation_*, amount_raised, display_status) cannot accidentally become
   * form controls.
   */
  private loadEvent(id: number): void {
    this.loading.set(true);
    this.loadError.set('');
    this.api
      .getAdminEvent(id)
      .pipe(finalize(() => this.loading.set(false)))
      .subscribe({
        next: (detail: EventDetail) => {
          this.loadedEvent.set(detail.event);
          this.registrations.set(detail.registrations ?? []);
          this.summary.set(detail.summary ?? null);
          this.form.patchValue({
            category_id: detail.event.category_id,
            name: detail.event.name,
            // The API sends "YYYY-MM-DD HH:mm:ss"; a datetime-local input needs
            // "YYYY-MM-DDTHH:mm" - toDateTimeLocal() converts without using
            // new Date(), so no time zone can shift the value.
            event_date: toDateTimeLocal(detail.event.event_date),
            location: detail.event.location,
            latitude: detail.event.latitude,
            longitude: detail.event.longitude,
            purpose: detail.event.purpose,
            description: detail.event.description,
            ticket_price: Number(detail.event.ticket_price),
            fundraising_goal: Number(detail.event.fundraising_goal),
            status: detail.event.status,
            image_url: detail.event.image_url ?? '',
          });
        },
        error: (err: ApiError) => this.loadError.set(err.message),
      });
  }

  /**
   * True when the control is invalid AND the user should already be told about it.
   *
   * @param name - Control name, matching its HTML `id`.
   * @returns `true` when the control is invalid and has been touched, edited or
   * the form has been submitted; `false` for an unknown control.
   *
   * @remarks
   * Not showing errors before the user has touched a field is what stops a blank
   * form from opening covered in red.
   */
  protected showError(name: string): boolean {
    const control = this.form.get(name);
    if (!control) {
      return false;
    }
    return control.invalid && (control.touched || control.dirty || this.submitted());
  }

  /**
   * Message for a control's FIRST Angular validation error.
   *
   * @param name - Control name, matching its HTML `id`.
   * @returns The sentence from `MESSAGES` for the first failing rule, a generic
   * sentence for an unknown rule, or `''` when the control is valid.
   */
  protected clientError(name: string): string {
    const errors = this.form.get(name)?.errors;
    if (!errors) {
      return '';
    }
    const key = Object.keys(errors)[0];
    return MESSAGES[key] ?? 'Please check this value.';
  }

  /**
   * Message the SERVER returned for this field (400 `fields` map), if any.
   *
   * @param name - Control name, matching the key the API used.
   * @returns The server's sentence, or `''` when the API did not complain about
   * this field.
   */
  protected serverErrorFor(name: string): string {
    return this.serverFieldErrors()[name] ?? '';
  }

  /**
   * The 400 `fields` map flattened into a list.
   *
   * @returns One `{ name, message }` entry per rejected field, ready to loop over
   * with `@for` + `track`.
   *
   * @remarks
   * Flattened because objects have no stable iteration order to `track` by, and
   * the summary needs to list several messages at once.
   */
  protected readonly serverFieldErrorList = computed(() =>
    Object.entries(this.serverFieldErrors()).map(([name, message]) => ({ name, message })),
  );

  /**
   * Marks every control as touched so all inline errors appear at once when the
   * user presses Save with an incomplete form.
   */
  private markAllTouched(): void {
    Object.values(this.form.controls).forEach((control) => control.markAsTouched());
  }

  /**
   * Called by both the form's `(ngSubmit)` and the submit button's click.
   *
   * The client check happens FIRST: if the form is invalid we show the inline
   * errors and return without any network activity, which is the brief's
   * "validate before submitting" requirement.
   *
   * @remarks
   * On success the two modes deliberately behave differently: create navigates to
   * the list with `?created=1` (proof the row exists), while edit stays on the
   * page and re-reads the event so staff can carry on with the registrations.
   */
  protected submit(): void {
    this.submitted.set(true);
    this.serverError.set('');
    this.serverFieldErrors.set({});
    this.successMessage.set('');

    if (this.form.invalid) {
      this.markAllTouched();
      this.serverError.set('Please fix the highlighted fields before saving.');
      // Focus the first offending control so keyboard users are taken to it.
      const firstInvalid = Object.keys(this.form.controls).find((name) =>
        this.form.get(name)?.invalid,
      );
      if (firstInvalid) {
        document.getElementById(firstInvalid)?.focus();
      }
      return;
    }

    this.saving.set(true);
    const payload = this.buildPayload();

    const request$ = this.isEditMode()
      ? this.api.updateEvent(this.eventId(), payload)
      : this.api.createEvent(payload);

    request$.pipe(finalize(() => this.saving.set(false))).subscribe({
      next: (result) => {
        const message =
          result.message ||
          (this.isEditMode() ? 'Event updated successfully.' : 'Event created successfully.');

        if (this.isEditMode()) {
          // Stay on the page so staff can carry on working with the
          // registrations list, but confirm the write happened.
          this.successMessage.set(message);
          // Re-read from the server so the form shows exactly what MySQL holds.
          this.loadEvent(this.eventId());
        } else {
          // Create: the new event's id comes back from the API. Jumping to the
          // list (with a flash flag) proves the row really exists now.
          this.router.navigate(['/events'], { queryParams: { created: '1' } });
        }
      },
      error: (err: ApiError) => {
        // 400 -> surface the server's per-field map next to the inputs.
        this.serverFieldErrors.set(err.fields ?? {});
        this.serverError.set(err.message);
        // Re-run validation display so the server messages are visible.
        this.markAllTouched();
      },
    });
  }

  /**
   * The `<form>` element's ngSubmit handler.
   *
   * @param event - The submit event Angular passes in; prevented so the browser
   * does not do a full page reload.
   *
   * @remarks Guards double submits: a second Enter press while `saving()` is true
   * is ignored.
   */
  protected onSubmit(event: Event): void {
    event.preventDefault();
    if (this.saving()) {
      return;
    }
    this.submit();
  }

  /**
   * Builds the exact JSON body the contract expects.
   *
   * @returns An {@link EventPayload} ready for POST/PUT.
   *
   * @remarks
   * - `event_date` is sent as `YYYY-MM-DDTHH:mm` (what the input holds); the
   *   server normalises it.
   * - numbers are coerced from the input's string values, and rounded to 2dp so
   *   the price/goal cannot carry floating point noise into MySQL DECIMAL.
   * - `amount_raised` is NOT a form field (money raised arrives through
   *   registrations). On edit we echo the value the API gave us so the PUT does
   *   not wipe it; on create it starts at 0.
   * - `status` can only be active or suspended: "past" is computed by the API
   *   from the date, never stored, so it is not offered in the dropdown.
   */
  private buildPayload(): EventPayload {
    const value = this.form.getRawValue();
    const toNumber = (input: unknown, fallback = 0): number => {
      const parsed = Number(input);
      return Number.isFinite(parsed) ? Math.round(parsed * 100) / 100 : fallback;
    };
    const toNullableNumber = (input: unknown): number | null => {
      if (input === null || input === undefined || input === '') {
        return null;
      }
      const parsed = Number(input);
      return Number.isFinite(parsed) ? parsed : null;
    };

    return {
      category_id: toNumber(value.category_id),
      name: String(value.name ?? '').trim(),
      event_date: String(value.event_date ?? ''),
      location: String(value.location ?? '').trim(),
      latitude: toNullableNumber(value.latitude),
      longitude: toNullableNumber(value.longitude),
      purpose: String(value.purpose ?? '').trim(),
      description: String(value.description ?? '').trim(),
      ticket_price: toNumber(value.ticket_price),
      fundraising_goal: toNumber(value.fundraising_goal),
      amount_raised: this.loadedEvent()?.amount_raised ?? 0,
      status: (value.status ?? 'active') as StoredStatus,
      image_url: String(value.image_url ?? '').trim() || PLACEHOLDER_IMAGE,
    };
  }

  /**
   * Puts the form back to the values the API last gave us (edit) or empties it.
   *
   * @remarks In edit mode this re-fetches rather than using `patchValue` again,
   * so the reset also clears any server field errors against fresh data.
   */
  protected resetForm(): void {
    this.serverError.set('');
    this.serverFieldErrors.set({});
    if (this.isEditMode() && this.loadedEvent()) {
      this.loadEvent(this.eventId());
    } else {
      this.form.reset({
        category_id: 0,
        name: '',
        event_date: '',
        location: '',
        latitude: null,
        longitude: null,
        purpose: '',
        description: '',
        ticket_price: 0,
        fundraising_goal: 0,
        status: 'active',
        image_url: '',
      });
    }
  }

  /**
   * "Fill with sample data" - handy during the demo, exercises the validators.
   *
   * @remarks Deliberately does NOT set `category_id` from thin air: it picks the
   * first category the API supplied, because the foreign key must point at a row
   * that actually exists.
   */
  protected fillSample(): void {
    this.form.patchValue({
      name: 'Winter Makers Market',
      event_date: '2027-03-15T07:00',
      location: 'Lismore Makers Hall',
      latitude: -28.81,
      longitude: 153.28,
      purpose: 'Fund repair workshops.',
      description:
        'A community market of local makers raising money for free repair workshops across the Northern Rivers.',
      ticket_price: 20,
      fundraising_goal: 5000,
      status: 'active',
      image_url: PLACEHOLDER_IMAGE,
    });
    if (!this.form.get('category_id')?.value) {
      const first = this.categories()[0];
      if (first) {
        this.form.patchValue({ category_id: first.category_id });
      }
    }
  }

  /**
   * Full name of a registered person for the registrations table.
   *
   * @param registration - One row from `GET /api/admin/events/:id`.
   * @returns "First Last", trimmed so a missing name does not leave a gap.
   */
  protected registrantName(registration: ApiRegistration): string {
    return `${registration.first_name} ${registration.last_name}`.trim();
  }

  /**
   * Template helper: pretty-prints an API timestamp.
   *
   * @param value - API date-time string, "YYYY-MM-DD HH:mm:ss".
   * @returns The friendly form, e.g. "Tue 27 Oct 2026, 6:30 am".
   */
  protected formatWhen(value: string): string {
    return formatDateTime(value);
  }

  /**
   * Template helper: formats money in the registrations table.
   *
   * @param value - Amount in AUD, or `null`/`undefined` when the API omitted it.
   * @returns The amount as Australian currency, e.g. "$50.00".
   */
  protected formatMoney(value: number | null | undefined): string {
    return money(value);
  }
}
