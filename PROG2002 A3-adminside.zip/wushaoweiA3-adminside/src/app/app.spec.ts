import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { App } from './app';

/**
 * Shell tests: they prove the pieces of the brief that live in app.html - the
 * shell is built from the four shared segments (Header, Nav, Body, Footer), the
 * menu is rendered by the shell (so it is present on every routed page), and the
 * shared landmark elements exist exactly once.
 */
describe('App (admin shell)', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [App],
      providers: [provideRouter([])],
    }).compileComponents();
  });

  /**
   * Creates the shell, waits for the child segment components to render and
   * returns the host element.
   *
   * @returns The `<app-root>` host element, with header, nav, body and footer
   * already in the DOM.
   */
  async function build(): Promise<HTMLElement> {
    const fixture = TestBed.createComponent(App);
    await fixture.whenStable();
    fixture.detectChanges();
    return fixture.nativeElement as HTMLElement;
  }

  it('should create the app', () => {
    const fixture = TestBed.createComponent(App);
    expect(fixture.componentInstance).toBeTruthy();
  });

  it('composes the four shared page segments in order', async () => {
    const host = await build();
    const selector = 'app-admin-header, app-admin-nav, main#main.page-body, app-admin-footer';
    const segments = Array.from(host.querySelectorAll(selector));

    expect(segments.map((segment) => segment.tagName.toLowerCase())).toEqual([
      'app-admin-header',
      'app-admin-nav',
      'main',
      'app-admin-footer',
    ]);
  });

  it('renders each shared landmark exactly once', async () => {
    const host = await build();

    expect(host.querySelectorAll('header').length).toBe(1);
    expect(host.querySelectorAll('nav').length).toBe(1);
    expect(host.querySelectorAll('footer').length).toBe(1);
    expect(host.querySelectorAll('main').length).toBe(1);
  });

  it('renders the navigation menu with a link to every view', async () => {
    const host = await build();
    const links = Array.from(host.querySelectorAll('.admin-nav a')).map((link) =>
      (link as HTMLAnchorElement).getAttribute('href'),
    );

    expect(links).toEqual(['/', '/events', '/events/new']);
  });

  it('shows the shared header brand on the shell', async () => {
    const host = await build();

    expect(host.textContent).toContain('Kind Charity Events');
    expect(host.textContent).toContain('Staff Administration');
  });

  it('shows the admin footer credit on the shell', async () => {
    const host = await build();

    expect(host.textContent).toContain('PROG2002 Web Development II, Assessment 3');
  });

  it('renders the routed page inside the Body segment', async () => {
    const host = await build();
    const body = host.querySelector('main#main');

    expect(body?.querySelector('router-outlet')).toBeTruthy();
  });
});
