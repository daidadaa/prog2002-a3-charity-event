/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * @file app/app.config.ts
 */

import {
  ApplicationConfig,
  provideBrowserGlobalErrorListeners,
  provideZonelessChangeDetection,
} from '@angular/core';
import { provideHttpClient, withFetch } from '@angular/common/http';
import { provideRouter, withComponentInputBinding } from '@angular/router';
import { routes } from './app.routes';

/**
 * appConfig.ts - the providers that make this standalone Angular app work.
 *
 * This object is the "boot wiring" of the application. It is passed to
 * `bootstrapApplication()` in `src/main.ts`, which builds the root injector from
 * it; anything listed here is available to every component and service.
 *
 * @remarks
 * Each provider earns its place:
 * - `provideZonelessChangeDetection()`: this project is zoneless. Nothing
 *   patches `setTimeout`/XHR any more; Angular re-renders when a *signal* read by
 *   a template changes. That is why every page stores its data in `signal()`s
 *   and why `computed()` is used for derived values.
 * - `provideRouter(routes)`: client-side routing for the admin pages, matching
 *   the route table in {@link routes}.
 * - `withComponentInputBinding()`: lets a component receive the `:id` route
 *   parameter as a plain `@Input() id` - no `ActivatedRoute` boilerplate, and the
 *   route stays the single source of truth for "which event am I editing".
 * - `provideHttpClient()`: REQUIRED for `HttpClient` to exist. Without it,
 *   injecting HttpClient throws `NullInjectorError`. `withFetch()` makes Angular
 *   use the modern fetch API instead of the legacy XHR backend.
 * - `provideBrowserGlobalErrorListeners()`: forwards uncaught errors to Angular's
 *   `ErrorHandler` so a runtime failure is reported instead of vanishing.
 *
 * @example
 *
 * @see {@link routes} for the admin route table.
 */
export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideZonelessChangeDetection(),
    provideHttpClient(withFetch()),
    provideRouter(routes, withComponentInputBinding()),
  ],
};
