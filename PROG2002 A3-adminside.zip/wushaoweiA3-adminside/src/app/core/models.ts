/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * TypeScript interfaces describing every JSON shape this admin application
 * receives from, or sends to, the Express API.
 *
 * @file app/core/models.ts
 * @file app/core/models.ts
 */

/**
 * The three states the ADMIN list is allowed to show.
 *
 * `active` and `suspended` are stored in MySQL; `past` is derived by the API
 * from the event date (see {@link ApiEvent.display_status}).
 */
export type DisplayStatus = 'active' | 'past' | 'suspended';

/** The only two statuses the database actually stores (`past` is computed). */
export type StoredStatus = 'active' | 'suspended';

/**
 * An event record.
 *
 * `display_status` is NOT stored in MySQL - the API derives it on every
 * request: `suspended` if status = 'suspended', else `past` if the event date
 * has already gone by, else `active`. Computing it server-side is deliberate:
 * a single source of truth means the list page, the edit page and the client
 * website can never disagree about whether an event is over, and it keeps the
 * clock (which the client machine might have wrong) on the server.
 *
 * @remarks
 * Returned by `GET /api/admin/events` (an array) and nested as `event` inside
 * the envelope of `GET /api/admin/events/:id` ({@link EventDetail}).
 *
 * @see {@link EventPayload} for the shape sent back on create/update.
 */
export interface ApiEvent {
  /** Primary key from MySQL (`event.event_id`). Used in every admin URL. */
  event_id: number;

  /** Event title, e.g. "Coastal Sunrise Fun Run". Required, 3-120 characters. */
  name: string;

  /** Plain string "YYYY-MM-DD HH:mm:ss" - NOT a JS Date. See formatDate() helpers. */
  event_date: string;

  /** Venue / suburb shown in the list, e.g. "Lismore Riverside Park". */
  location: string;

  /** Optional map latitude; `null` when staff have not supplied a point. */
  latitude: number | null;

  /** Optional map longitude; `null` when staff have not supplied a point. */
  longitude: number | null;

  /** Short reason the event exists, e.g. "Fund youth mental health outreach." */
  purpose: string;

  /** Long description shown on the public event page (10-2000 characters). */
  description: string;

  /** Price per ticket in AUD; `0` means the event is free. */
  ticket_price: number;

  /** Amount the organisers hope to raise, in AUD. Drives the progress bar. */
  fundraising_goal: number;

  /** Amount raised so far, in AUD. Read-only here: it grows via registrations. */
  amount_raised: number;

  /** Status as STORED, i.e. only `active` or `suspended`. See {@link StoredStatus}. */
  status: StoredStatus;

  /** Web path such as "assets/images/coastal-sunrise-fun-run.jpg" - bind directly. */
  image_url: string;

  /** FK to the owning organisation (this assessment has one, id 1). */
  organisation_id: number;

  /** FK to the category row; the form's `<select>` is built from `/api/categories`. */
  category_id: number;

  /** Category name joined by SQL, e.g. "Fun Run" - display only. */
  category_name: string;

  /** Organisation name joined by SQL, e.g. "Kind". */
  organisation_name: string;

  /** Organisation mission statement joined by SQL - shown on public pages. */
  organisation_mission: string;

  /** Contact email joined by SQL; real address on the admin endpoint. */
  organisation_email: string;

  /** Contact phone joined by SQL. */
  organisation_phone: string;

  /** Derived by the API (never stored): active / past / suspended. */
  display_status: DisplayStatus;

  /** Only present on GET /api/admin/events (the list endpoint). */
  registration_count?: number;

  /** Only present on GET /api/admin/events (the list endpoint). */
  tickets_sold?: number;
}

/** A person registered for an event (admin view - personal data NOT masked). */
export interface ApiRegistration {
  /** Primary key of the registration row. */
  registration_id: number;

  /** Registrant's given name, as typed on the public form. */
  first_name: string;

  /** Registrant's family name, as typed on the public form. */
  last_name: string;

  /** Real address on the admin endpoint; masked ("e***i@example.com") on public ones. */
  email: string;

  /** Contact phone number supplied by the registrant. */
  phone: string;

  /** How many tickets this registration bought (contributes to tickets_sold). */
  tickets: number;

  /** When the registration was made, as "YYYY-MM-DD HH:mm:ss". */
  registration_date: string;

  /** Money this registration contributed, in AUD. */
  total_amount: number;

  /** Free-text note from the registrant; `null` when they left it blank. */
  notes: string | null;
}

/** Roll-up numbers the API calculates for one event. */
export interface RegistrationSummary {
  /** Number of registration rows linked to the event. */
  registration_count: number;

  /** Total tickets across those rows. */
  tickets_sold: number;

  /** Total money across those rows, in AUD. */
  amount_registered: number;

  /** Date of the newest registration, or `null` when there are none. */
  latest_registration: string | null;
}

/** GET /api/admin/events/:id and GET /api/events/:id both return this envelope. */
export interface EventDetail {
  /** The event itself, with every joined organisation/category column. */
  event: ApiEvent;

  /** Everyone registered for the event, newest first. */
  registrations: ApiRegistration[];

  /** Pre-calculated roll-ups so the edit screen needs no second request. */
  summary: RegistrationSummary;
}

/** GET /api/categories - used to populate the form's category `<select>`. */
export interface Category {
  /** Primary key sent back as `category_id` on create/update. */
  category_id: number;

  /** Display name, e.g. "Fun Run". */
  name: string;

  /** Short explanation of the category, shown as supporting text. */
  description: string;
}

/**
 * Body sent to POST /api/events and PUT /api/events/:id.
 * `event_date` is "YYYY-MM-DDTHH:mm" straight out of `<input type="datetime-local">`.
 *
 * @remarks
 * Deliberately narrower than {@link ApiEvent}: it contains only the columns
 * staff are allowed to write. `amount_raised` and the joined
 * organisation/category names are server-owned and therefore absent.
 *
 * @see {@link EventForm.buildPayload} for the code that fills this in.
 */
export interface EventPayload {
  /** Chosen category id; must be an existing row (server re-validates). */
  category_id: number;

  /** Event title. */
  name: string;

  /** "YYYY-MM-DDTHH:mm" - the server normalises it to MySQL DATETIME. */
  event_date: string;

  /** Venue / suburb. */
  location: string;

  /** Optional latitude, or `null`. */
  latitude: number | null;

  /** Optional longitude, or `null`. */
  longitude: number | null;

  /** Why the event is being run. */
  purpose: string;

  /** Full description for the public page. */
  description: string;

  /** Price per ticket in AUD. */
  ticket_price: number;

  /** Target amount in AUD. */
  fundraising_goal: number;

  /** Current raised total: echoed back on edit so a PUT cannot wipe it. */
  amount_raised: number;

  /** Stored status - `past` is refused because the API computes it from the date. */
  status: StoredStatus;

  /** Image path; falls back to the bundled placeholder when blank. */
  image_url: string;
}

/** Every 2xx response body (POST 201, PUT 200, DELETE 200). */
export interface MutationResult {
  /** Human-readable confirmation from the server, shown in a banner. */
  message: string;

  /** Id of the row that was created/updated/deleted. */
  event_id: number;
}

/**
 * The body of a 400 from POST/PUT: `fields` maps an input name
 * (e.g. "name", "ticket_price") to the human-readable problem with it.
 */
export interface FieldErrorResponse {
  /** Form-level summary message from the server. */
  error: string;

  /** Optional per-input messages, keyed by the HTML control name. */
  fields?: Record<string, string>;
}

/**
 * The body of the all-important 409 from DELETE /api/events/:id: the event
 * still has registrations and the server refused to delete it.
 */
export interface DeleteConflictResponse {
  /** The server's own explanation, printed verbatim in the red banner. */
  error: string;

  /** How many registration rows are blocking the delete. */
  registration_count: number;
}

/**
 * Normalised error object the service hands to components.
 *
 * Angular's HttpErrorResponse body is `any`, so the service narrows it once
 * here and components can then work with a predictable object instead of
 * poking at `err.error?.fields` in three different places.
 *
 * @see {@link EventApiService.toApiError} where the narrowing happens.
 */
export interface ApiError {
  /** HTTP status: 0 (network/CORS), 400, 404, 409, 500 ... */
  status: number;

  /** Server-provided human message, or a friendly fallback. */
  message: string;

  /** Per-field messages from a 400, ready to display next to inputs. */
  fields: Record<string, string>;

  /** Present on a DELETE 409 so the UI can say how many registrations block it. */
  registrationCount?: number;
}
