import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { EventApiService } from './event-api.service';
import { environment } from '../../environments/environment';

/**
 * Unit tests for {@link EventApiService}.
 *
 * `provideHttpClientTesting()` swaps Angular's real network backend for one we
 * control, so we can assert the exact URL, HTTP method and body of every call
 * the admin pages make, and feed back canned API responses (including the
 * important 409 delete conflict) without a server running.
 *
 * These tests document the contract: if somebody changes a URL or stops
 * normalising the 409 body, a test fails instead of the UI silently breaking.
 *
 * @remarks
 * `httpMock.verify()` in `afterEach` is what makes them meaningful: a test fails
 * if a request was expected but never handled (or vice versa), so the suite
 * cannot pass by simply not exercising a code path.
 */
describe('EventApiService', () => {
  let service: EventApiService;
  let httpMock: HttpTestingController;

  const base = `${environment.apiBaseUrl}/api`;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()],
    });
    service = TestBed.inject(EventApiService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    // Fails the test if any request was expected but never handled.
    httpMock.verify();
  });

  it('GETs all events (every status) from the admin endpoint', () => {
    const rows = [{ event_id: 1, name: 'Coastal Sunrise Fun Run', display_status: 'active' }];

    service.getAdminEvents().subscribe((events) => {
      expect(events.length).toBe(1);
      expect(events[0].display_status).toBe('active');
    });

    const request = httpMock.expectOne(`${base}/admin/events`);
    expect(request.request.method).toBe('GET');
    request.flush(rows);
  });

  it('GETs one event with its registrations and summary', () => {
    const detail = {
      event: { event_id: 2, name: 'Light the Way Gala' },
      registrations: [{ registration_id: 9, first_name: 'Emma', last_name: 'Rossi' }],
      summary: { registration_count: 4, tickets_sold: 9 },
    };

    service.getAdminEvent(2).subscribe((result) => {
      expect(result.registrations[0].first_name).toBe('Emma');
      expect(result.summary.registration_count).toBe(4);
    });

    const request = httpMock.expectOne(`${base}/admin/events/2`);
    expect(request.request.method).toBe('GET');
    request.flush(detail);
  });

  it('GETs the categories used by the form select', () => {
    service.getCategories().subscribe((categories) => expect(categories.length).toBe(2));
    const request = httpMock.expectOne(`${base}/categories`);
    expect(request.request.method).toBe('GET');
    request.flush([
      { category_id: 1, name: 'Fun Run', description: '' },
      { category_id: 2, name: 'Gala Dinner', description: '' },
    ]);
  });

  it('POSTs a new event', () => {
    const payload = { name: 'Winter Makers Market', category_id: 1 } as never;

    service.createEvent(payload).subscribe((result) => expect(result.event_id).toBe(9));

    const request = httpMock.expectOne(`${base}/events`);
    expect(request.request.method).toBe('POST');
    expect(request.request.body.name).toBe('Winter Makers Market');
    request.flush({ message: 'The event was created.', event_id: 9 });
  });

  it('PUTs an update to the right event id', () => {
    service.updateEvent(3, { name: 'Art for Tomorrow Auction' } as never).subscribe();

    const request = httpMock.expectOne(`${base}/events/3`);
    expect(request.request.method).toBe('PUT');
    request.flush({ message: 'The event was updated.', event_id: 3 });
  });

  it('surfaces the 409 delete conflict WITH the registration count', () => {
    let captured: { status: number; message: string; registrationCount?: number } | undefined;

    service.deleteEvent(1).subscribe({
      next: () => { throw new Error('the delete should not have succeeded'); },
      error: (error) => (captured = error),
    });

    const request = httpMock.expectOne(`${base}/events/1`);
    expect(request.request.method).toBe('DELETE');
    request.flush(
      {
        error: 'This event cannot be deleted because it already has 5 registration(s).',
        registration_count: 5,
      },
      { status: 409, statusText: 'Conflict' },
    );

    // The service must pass the server's own sentence through untouched and
    // keep registration_count so the UI can explain why it was blocked.
    expect(captured?.status).toBe(409);
    expect(captured?.message).toBe(
      'This event cannot be deleted because it already has 5 registration(s).',
    );
    expect(captured?.registrationCount).toBe(5);
  });

  it('normalises a 400 into the fields map', () => {
    let captured: { status: number; fields: Record<string, string>; message: string } | undefined;

    service.createEvent({} as never).subscribe({
      next: () => { throw new Error('the request should have failed'); },
      error: (error) => (captured = error),
    });

    httpMock
      .expectOne(`${base}/events`)
      .flush(
        { error: 'Please correct the highlighted fields.', fields: { name: 'The event name is required.' } },
        { status: 400, statusText: 'Bad Request' },
      );

    expect(captured?.status).toBe(400);
    expect(captured?.message).toBe('Please correct the highlighted fields.');
    expect(captured?.fields['name']).toBe('The event name is required.');
  });

  it('reports an unreachable API (status 0) with a helpful message', () => {
    let captured: { status: number; message: string } | undefined;

    service.getAdminEvents().subscribe({
      next: () => { throw new Error('the request should have failed'); },
      error: (error) => (captured = error),
    });

    httpMock.expectOne(`${base}/admin/events`).error(new ProgressEvent('error'));

    expect(captured?.status).toBe(0);
    expect(captured?.message).toContain('Cannot reach the API');
  });
});
