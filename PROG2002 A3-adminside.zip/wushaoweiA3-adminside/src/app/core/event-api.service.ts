/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * @file app/core/event-api.service.ts
 */

import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, TimeoutError, catchError, throwError, timeout } from 'rxjs';
import { environment } from '../../environments/environment';
import {
  ApiError,
  ApiEvent,
  Category,
  DeleteConflictResponse,
  EventDetail,
  EventPayload,
  FieldErrorResponse,
  MutationResult,
} from './models';

/**
 * How long any request may wait before the page reports it, in ms.
 *
 * `HttpClient` has no default timeout, so a hung API would leave the admin table
 * and form spinners turning forever. Every call below pipes through `timeout(...)`,
 * and the resulting {@link TimeoutError} is turned into a friendly `ApiError` by
 * {@link EventApiService.toApiError}.
 */
const REQUEST_TIMEOUT_MS = 10000;

/**
 * EventApiService - the ONLY place in the admin application that knows the
 * back-end URLs.
 *
 * It is the single gateway between the Angular components and the Express API
 * that fronts MySQL. Every method returns the JSON mapped onto the interfaces in
 * `models.ts`, so a component never touches a raw `HttpErrorResponse` or guesses
 * at a field name.
 *
 * DATA SOURCE: the Express API at {@link environment.apiBaseUrl}, i.e.
 * `GET/POST/PUT/DELETE http://localhost:3000/api/...`.
 *
 * @remarks
 * DATA FLOW (memorise this for the report / demo):
 *
 * WHY A SERVICE AT ALL (rather than HttpClient inside each component)?
 * - Single source of truth for URLs: `environment.apiBaseUrl` is used once.
 * - Reusable + testable: a unit test can inject this service with
 *   `provideHttpClientTesting()` and assert the exact URLs/methods.
 * - Consistent error handling: every failure is turned into the same
 *   `ApiError` shape, so no component has to reason about HttpErrorResponse.
 *
 * Every method returns a COLD Observable (HttpClient does not fire until
 * somebody subscribes), so the component decides when the request happens.
 *
 * @see {@link models.ApiEvent} for the response shape, {@link models.ApiError}
 * for the normalised failure shape.
 */
@Injectable({ providedIn: 'root' })
export class EventApiService {
  /** Injected HTTP client; the only outbound channel in the application. */
  private readonly http = inject(HttpClient);

  /** e.g. "http://localhost:3000/api" - no trailing slash. */
  private readonly api = `${environment.apiBaseUrl}/api`;

  /**
   * GET /api/admin/events
   *
   * The ADMIN list endpoint: it returns ALL events whatever their status,
   * unlike the public `/api/events` which hides suspended ones. Each row also
   * carries `registration_count` and `tickets_sold` computed with SQL
   * aggregates, so the table can show them without an extra request per event.
   *
   * @returns A cold Observable that emits the full event list, newest data on
   * every subscribe. Errors are re-thrown as {@link ApiError}.
   * @throws {ApiError} Delivered through the Observable's error channel (status
   * 0 when the API is unreachable, otherwise the server's status).
   */
  getAdminEvents(): Observable<ApiEvent[]> {
    return this.http
      .get<ApiEvent[]>(`${this.api}/admin/events`)
      .pipe(
        timeout(REQUEST_TIMEOUT_MS),
        catchError((error) => throwError(() => this.toApiError(error))),
      );
  }

  /**
   * GET /api/admin/events/:id
   *
   * One event PLUS everything registered for it. Same envelope as the public
   * detail endpoint (`{ event, registrations, summary }`) but the admin version
   * is not restricted by status and returns real emails/phones instead of the
   * masked ones, because staff are allowed to see the people who registered.
   *
   * @param id - `event_id` of the event to load, taken from the `:id` route
   * parameter.
   * @returns A cold Observable emitting `{ event, registrations, summary }`.
   * @throws {ApiError} Status 404 when the event no longer exists.
   */
  getAdminEvent(id: number): Observable<EventDetail> {
    return this.http
      .get<EventDetail>(`${this.api}/admin/events/${id}`)
      .pipe(
        timeout(REQUEST_TIMEOUT_MS),
        catchError((error) => throwError(() => this.toApiError(error))),
      );
  }

  /**
   * GET /api/categories - fills the category `<select>` on the create/edit form.
   *
   * @returns A cold Observable emitting every category, so the form's options
   * come from the database instead of a hard-coded list.
   * @throws {ApiError} Delivered through the Observable's error channel.
   */
  getCategories(): Observable<Category[]> {
    return this.http
      .get<Category[]>(`${this.api}/categories`)
      .pipe(
        timeout(REQUEST_TIMEOUT_MS),
        catchError((error) => throwError(() => this.toApiError(error))),
      );
  }

  /**
   * POST /api/events - create a new event.
   * 201 -> `{ message, event_id }`; 400 -> `{ error, fields }`.
   *
   * @param payload - The validated form value, shaped as {@link EventPayload}.
   * @returns A cold Observable emitting the mutation result (its `event_id` is
   * the row MySQL just created).
   * @throws {ApiError} Status 400 with `fields` when the server rejects a value
   * the browser's validators did not catch.
   */
  createEvent(payload: EventPayload): Observable<MutationResult> {
    return this.http
      .post<MutationResult>(`${this.api}/events`, payload)
      .pipe(
        timeout(REQUEST_TIMEOUT_MS),
        catchError((error) => throwError(() => this.toApiError(error))),
      );
  }

  /**
   * PUT /api/events/:id - update an existing event.
   * 200 -> `{ message, event_id }`; 400 -> `{ error, fields }`; 404 -> `{ error }`.
   *
   * @param id - `event_id` of the row to update.
   * @param payload - The complete new value, shaped as {@link EventPayload}; a
   * PUT replaces the writable columns, so the form must send every field.
   * @returns A cold Observable emitting the mutation result.
   * @throws {ApiError} Status 400 (invalid field) or 404 (row deleted in another
   * tab).
   */
  updateEvent(id: number, payload: EventPayload): Observable<MutationResult> {
    return this.http
      .put<MutationResult>(`${this.api}/events/${id}`, payload)
      .pipe(
        timeout(REQUEST_TIMEOUT_MS),
        catchError((error) => throwError(() => this.toApiError(error))),
      );
  }

  /**
   * DELETE /api/events/:id
   *
   * 200 -> deleted. 409 -> REFUSED, `{ error, registration_count }`, because
   * the event still has registrations (the data-integrity rule). A 404 is also
   * possible if the row vanished in another tab.
   *
   * @param id - `event_id` of the row the staff member asked to delete.
   * @returns A cold Observable emitting `{ message, event_id }` on success.
   * @throws {ApiError} Status 409 with `registrationCount` set when the delete is
   * refused, or 404 when the row is already gone.
   *
   * @remarks
   * NOTE: the service deliberately does NOT swallow the 409. It converts it to
   * a normal `ApiError` (keeping `registrationCount`) and lets the *component*
   * decide how loudly to show it - the brief requires that text on screen, not
   * in the console.
   */
  deleteEvent(id: number): Observable<MutationResult> {
    return this.http
      .delete<MutationResult>(`${this.api}/events/${id}`)
      .pipe(
        timeout(REQUEST_TIMEOUT_MS),
        catchError((error) => throwError(() => this.toApiError(error))),
      );
  }

  /**
   * Turns an `HttpErrorResponse` into our own `ApiError`.
   *
   * The Express API answers failures with `{ error, fields?, registration_count? }`,
   * so we lift those straight out when they exist and fall back to a generic
   * message when they do not (status 0 = server down / CORS, or an HTML 500 page).
   *
   * @param error - Whatever `catchError` received; usually an
   * `HttpErrorResponse`, but typed `unknown` because RxJS makes no promise about
   * it.
   * @returns A predictable {@link ApiError} - never `undefined` - so components
   * can read `err.message` and `err.fields` without guarding.
   *
   * @remarks
   * The status-specific `fallback` wording is only used when the server sent no
   * `error` string of its own; the server's wording always wins because it knows
   * what actually went wrong.
   */
  private toApiError(error: unknown): ApiError {
    // `timeout(...)` fires a TimeoutError when nothing arrived in time. Like a
    // refused connection it is reported as status 0, but with wording that says
    // what actually happened: the request hung rather than the server being down.
    if (error instanceof TimeoutError) {
      return { status: 0, message: 'The server is taking too long to respond. Please try again.', fields: {} };
    }

    if (!(error instanceof HttpErrorResponse)) {
      return { status: 0, message: 'Unexpected error. Please try again.', fields: {} };
    }

    const body = (error.error ?? {}) as Partial<FieldErrorResponse & DeleteConflictResponse>;

    // Fallback wording per status, used only when the server sent no `error`.
    let fallback: string;
    switch (error.status) {
      case 0:
        fallback = `Cannot reach the API at ${environment.apiBaseUrl}. Is the server running?`;
        break;
      case 404:
        fallback = 'The requested event no longer exists.';
        break;
      case 409:
        fallback = 'The server refused this change because of related data.';
        break;
      case 400:
        fallback = 'Some fields are invalid. Please correct them and try again.';
        break;
      default:
        fallback = `The server returned an error (HTTP ${error.status}).`;
    }

    return {
      status: error.status,
      message: typeof body.error === 'string' && body.error ? body.error : fallback,
      fields: body.fields ?? {},
      registrationCount: body.registration_count,
    };
  }
}
