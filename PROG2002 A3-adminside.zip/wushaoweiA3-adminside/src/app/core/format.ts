/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * small PURE helper functions used by more than one component.
 *
 * @file app/core/format.ts
 * @file app/core/format.ts
 */

/**
 * Extracts just the calendar day from an API timestamp.
 *
 * @param value - API date-time string, "YYYY-MM-DD HH:mm:ss", or `''`.
 * @returns The first ten characters, "YYYY-MM-DD"; `''` for empty input.
 * @example
 */
export function datePart(value: string): string {
  return value ? value.slice(0, 10) : '';
}

/**
 * Extracts just the 24-hour time from an API timestamp.
 *
 * @param value - API date-time string, "YYYY-MM-DD HH:mm:ss", or `''`.
 * @returns The clock part, "HH:mm"; `''` for empty input.
 * @example
 */
export function timePart(value: string): string {
  return value ? value.slice(11, 16) : '';
}

/**
 * Friendly display form of an API timestamp: "Tue 27 Oct 2026, 6:30 am".
 *
 * @param value - API date-time string, "YYYY-MM-DD HH:mm:ss", or `''`.
 * @returns A human sentence-case date and 12-hour time, or `''` when the input
 * is empty.
 *
 * @remarks
 * The weekday is the only part that needs arithmetic, and it is worked out with
 * `Date.UTC` so the answer cannot depend on the browser's time zone. The date
 * that is *displayed* is still sliced straight out of the input string.
 *
 * @example
 */
export function formatDateTime(value: string): string {
  if (!value) {
    return '';
  }
  const year = value.slice(0, 4);
  const monthIndex = Number(value.slice(5, 7)) - 1;
  const day = Number(value.slice(8, 10));
  const hours = Number(value.slice(11, 13));
  const minutes = value.slice(14, 16);

  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const weekdays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  // Date.UTC keeps the arithmetic deterministic (no local-time shifting) and is
  // only used to work out the weekday, never to display the date itself.
  const weekday = weekdays[new Date(Date.UTC(Number(year), monthIndex, day)).getUTCDay()];

  const hour12 = hours % 12 === 0 ? 12 : hours % 12;
  const meridiem = hours < 12 ? 'am' : 'pm';

  return `${weekday} ${day} ${months[monthIndex]} ${year}, ${hour12}:${minutes} ${meridiem}`;
}

/**
 * "2026-10-27 06:30:00" -> "2026-10-27T06:30", the exact format
 * `<input type="datetime-local">` needs, so the edit form pre-fills correctly.
 *
 * @param value - API date-time string, "YYYY-MM-DD HH:mm:ss", or `''`.
 * @returns A value suitable for `[value]` on a `datetime-local` input; `''` for
 * empty input (which the browser renders as a blank field).
 * @example
 */
export function toDateTimeLocal(value: string): string {
  return value ? `${value.slice(0, 10)}T${value.slice(11, 16)}` : '';
}

/** $1,234.50 - `Intl.NumberFormat` is cached because templates call this often. */
const currencyFormatter = new Intl.NumberFormat('en-AU', {
  style: 'currency',
  currency: 'AUD',
  minimumFractionDigits: 2,
});

/**
 * Formats an amount as Australian currency.
 *
 * @param value - Amount in AUD; `null`/`undefined` is treated as `0` so a
 * missing column can never print "NaN" in a table cell.
 * @returns The amount as "$1,234.50".
 * @example
 */
export function money(value: number | null | undefined): string {
  return currencyFormatter.format(Number(value ?? 0));
}

/**
 * Percentage of a fundraising goal that has been raised, capped at 100.
 *
 * @param raised - Amount raised so far, in AUD.
 * @param goal - Target amount in AUD; `0`, `null` or negative means "no goal",
 * which returns `0` instead of dividing by zero.
 * @returns A whole number from 0 to 100, ready for a progress bar's width.
 * @example
 */
export function percent(raised: number, goal: number): number {
  if (!goal || goal <= 0) {
    return 0;
  }
  return Math.min(100, Math.round((raised / goal) * 100));
}

/**
 * Human label for a display status, e.g. "suspended" -> "Suspended".
 *
 * @param status - Raw status string from the API (`active` / `past` /
 * `suspended`).
 * @returns The same word with its first letter capitalised.
 * @example
 */
export function statusLabel(status: string): string {
  return status.charAt(0).toUpperCase() + status.slice(1);
}
