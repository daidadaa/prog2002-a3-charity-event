/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * @file app/app.routes.ts
 */

import { Routes } from '@angular/router';

/**
 * app.routes.ts - the four admin views.
 *
 * The brief allows either one dashboard page or several; splitting them keeps
 * each screen small and makes the URL meaningful (and refreshes safe, since a
 * deep link to /events/3/edit reloads the same view).
 *
 * `loadComponent` is used so each page is a lazily loaded chunk: the list page
 * does not have to download the big create/edit form until staff open it.
 *
 *   ''                 -> Dashboard: at-a-glance totals + the most recent events
 *   'events'           -> Event list: all statuses, search + status filter, Delete
 *   'events/new'       -> Create form (Reactive Forms, validation, POST)
 *   'events/:id/edit'  -> Edit form, pre-filled, plus the registration table (GET/PUT)
 *
 * NOTE the ORDER of the last two: the literal 'events/new' must be declared
 * BEFORE 'events/:id/edit' so it is not swallowed by the parameterised route.
 *
 * @remarks
 * Every page is rendered into the Body segment of the shell
 * (`<main id="main"><router-outlet /></main>` in `app.html`), so the Header, Nav
 * and Footer are never part of a route's template - they are provided once by
 * `App`.
 *
 * The `title` on each route writes the browser tab title through Angular's
 * `TitleStrategy`, which helps staff tell several open admin tabs apart.
 *
 * @example
 */
export const routes: Routes = [
  {
    path: '',
    title: 'Dashboard — Kind Charity Events Admin',
    loadComponent: () => import('./pages/dashboard/dashboard').then((m) => m.Dashboard),
  },
  {
    path: 'events',
    title: 'Manage events — Kind Charity Events Admin',
    loadComponent: () => import('./pages/event-list/event-list').then((m) => m.EventList),
  },
  {
    path: 'events/new',
    title: 'New event — Kind Charity Events Admin',
    loadComponent: () => import('./pages/event-form/event-form').then((m) => m.EventForm),
  },
  {
    path: 'events/:id/edit',
    title: 'Edit event — Kind Charity Events Admin',
    loadComponent: () => import('./pages/event-form/event-form').then((m) => m.EventForm),
  },
  // Anything else (typo, stale bookmark) goes back to the dashboard instead of
  // showing a blank page.
  { path: '**', redirectTo: '' },
];
