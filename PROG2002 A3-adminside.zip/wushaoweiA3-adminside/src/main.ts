/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * @file main.ts
 */

import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { App } from './app/app';

/**
 * main.ts - the entry point Angular looks for (`browser: "src/main.ts"` in
 * angular.json), and the only imperative line in the whole application.
 *
 * It hands the root component and the provider list to `bootstrapApplication`,
 * which creates the application injector, instantiates `<app-root>` and starts
 * change detection. Everything else - routing, HTTP, zoneless change detection -
 * is declared in `appConfig`, which keeps this file free of wiring detail.
 *
 * @remarks
 * The trailing `.catch()` is deliberately not allowed to die silently: a
 * bootstrap failure (a missing provider, a broken template) would otherwise
 * leave a blank page with nothing in the console to explain it.
 */
bootstrapApplication(App, appConfig)
  .catch((err) => console.error(err));
