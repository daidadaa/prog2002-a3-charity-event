/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * Environment settings for the DEPLOYED admin application.
 *
 * @file environments/environment.production.ts
 * @file environments/environment.production.ts
 */
export const environment = {
  /**
   * Base URL of the Express API on the SCU cPanel, with NO trailing slash - the
   * service appends `/api/...` itself.
   *
   * @example 'https://24832850.it.scu.edu.au/a3api'
   */
  apiBaseUrl: 'https://24832850.it.scu.edu.au/a3api',

  /**
   * Address of the deployed public (client-side) website, used by the
   * "View public site" link in the admin header.
   *
   * @example 'https://24832850.it.scu.edu.au/client/'
   */
  clientSiteUrl: 'https://24832850.it.scu.edu.au/client/',
};
