/**
 * PROG2002 Assessment 3 - WU Shaowei and Li Haolin.
 * Environment settings for the ADMIN-SIDE (staff) application.
 *
 * @file environments/environment.ts
 * @file environments/environment.ts
 */
export const environment = {
  /**
   * Base URL of the Express/MySQL back end (see API-CONTRACT.md), with NO
   * trailing slash - the service appends `/api/...` itself.
   *
   * @example 'http://localhost:3000'
   */
  apiBaseUrl: 'http://localhost:3000',

  /**
   * Address of the public (client-side) website, used by the "View public site"
   * link in the admin header.
   *
   * It lives here rather than in the component for the same reason as
   * `apiBaseUrl`: after deployment the two sites sit in different folders on the
   * cPanel host, and a link written into the component would still point at
   * localhost:4200 and be broken for the marker.
   *
   * @example 'http://localhost:4200/'
   */
  clientSiteUrl: 'http://localhost:4200/',
};
